# Frostbite ❄️

> **A frosty calculator you can use this for personal use no ads, no bad UI all designed by me.**

---

## 🌟 Overview

**Frostbite** is a high-performance, single-page client-side web application crafted with precision, zero bloat, and an elite visual dark interface. Built from the ground up to offer a seamless, ad-free environment, Frostbite combines aesthetic design with rapid responsiveness.

---

## 🎨 Key Features & Design Philosophy

- **Zero Advertisements & Pure Focus**: Completely free of pop-ups, tracking banners, or intrusive ad networks.
- **Elite Custom UI**: Designed with custom ice typography (`Iceberg`, `Orbitron`, `Plus Jakarta Sans`), deep dark glassmorphism backdrops, and responsive layout scaling.
- **Client-Side Engine**: Operates 100% in the user's browser with instant response times and offline local persistence.
- **Responsive Layout Architecture**: Fully optimized for desktop displays, tablets, and handheld devices.
- **Custom Asset Pipeline**: Custom image assets and localized data state management.

---

## 🛠️ Technology Stack

| Component | Technology |
| :--- | :--- |
| **Framework** | React 19 (TypeScript) |
| **Build Tooling** | Vite 6 |
| **Styling Engine** | Tailwind CSS v4 |
| **Icon Library** | Lucide React |
| **State Persistence** | Client Browser `localStorage` |
| **Hosting Target** | Static Client-Side SPA (GitHub Pages Ready) |

---

## 🚀 Quick Start & Local Setup

### Prerequisites
- **Node.js**: `v18.0.0` or higher
- **npm**: `v9.0.0` or higher

### 1. Installation
Clone your private repository and install the dependencies:
```bash
npm install
```

### 2. Development Server
Run the development environment on `http://localhost:3000`:
```bash
npm run dev
```

### 3. Production Build
Compile the application into static files ready for deployment:
```bash
npm run build
```
The output directory will be generated in `./dist`.

---

## 🌐 Deploying to GitHub Pages

Frostbite is pre-configured with relative asset paths (`base: './'` in `vite.config.ts`), making it 100% compatible with GitHub Pages hosting.

### Deployment Steps:
1. Build the production output:
   ```bash
   npm run build
   ```
2. Push your code to your GitHub repository.
3. In your GitHub repository settings:
   - Go to **Settings** -> **Pages**.
   - Under **Build and deployment**, select **Deploy from a branch**.
   - Set the branch to `main` (or `gh-pages`) and select the build root directory (`/dist` or `/docs`).
   - Click **Save**.

---

## 🔒 License & Usage Restrictions

This repository and its codebase are protected under a **Strict Proprietary & Non-Distribution License**. 

- **No Public Forking or Cloning**: Users are strictly forbidden from copying, publicizing, or forking this codebase for third-party hosting.
- **Personal Reference Only**: Access is permitted strictly for private personal use via the official deployment.
- **All Rights Reserved**: No commercial reuse, sublicensing, modification, or rebranding permitted.

See the full [`LICENSE`](./LICENSE) file for complete details.

---

*Designed with pride. Built for personal privacy, performance, and elite user experience.*
