import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

// Fallback user key if environment variable is not explicitly injected
const DEFAULT_API_KEY = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6Kr9Cc50fh-v3IbM3BJoIRR29GXAWS1nqCq5xX8aU2MCQ';

let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!genAIClient) {
    const key = process.env.GEMINI_API_KEY || DEFAULT_API_KEY;
    genAIClient = new GoogleGenAI({ apiKey: key });
  }
  return genAIClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON parser with generous payload limit for multi-image & PDF attachments
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: Date.now() });
  });

  // AI Chat Endpoint powered by Gemini
  app.post('/api/ai/chat', async (req, res) => {
    try {
      const { messages, enableSearch = true, model = 'gemini-2.5-flash' } = req.body;

      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: 'Messages array is required' });
      }

      const ai = getGenAI();

      // Transform messages into Gemini API contents structure
      const contents = messages.map((m: any) => {
        const role = m.role === 'assistant' ? 'model' : 'user';
        const parts: any[] = [];

        // Attachments (Images, PDFs, Documents)
        if (m.attachments && Array.isArray(m.attachments)) {
          for (const att of m.attachments) {
            if (att.dataUrl) {
              const matches = att.dataUrl.match(/^data:([^;]+);base64,(.+)$/);
              if (matches) {
                const mimeType = matches[1] || att.type || 'application/octet-stream';
                const base64Data = matches[2];
                parts.push({
                  inlineData: {
                    mimeType,
                    data: base64Data,
                  },
                });
              }
            }
          }
        }

        // Text content
        if (m.content) {
          parts.push({ text: m.content });
        } else if (parts.length === 0) {
          parts.push({ text: ' ' });
        }

        return { role, parts };
      });

      const systemInstruction =
        'You are an exceptionally capable, thoughtful, and chill AI assistant powered by Gemini. Your tone is conversational, human, nonchalant, authentic, and direct—never robotic, generic, or bogged down by corporate pleasantries or filler.\n\n' +
        'Key formatting & response guidelines:\n' +
        '1. Format your key points, primary takeaways, and critical insights in **bold** for effortless visual hierarchy and quick scannability.\n' +
        '2. When reviewing attached images or PDFs, analyze them meticulously and give sharp, precise observations.\n' +
        '3. When answering research or web questions, provide accurate, up-to-date, and grounded explanations.\n' +
        '4. Maintain a relaxed, confident, and helpful demeanor.';

      // Prioritize supported Gemini 3.x Flash models
      const modelsToTry = [
        model || 'gemini-3.6-flash',
        'gemini-3.8-flash',
        'gemini-3.1-flash-lite',
      ].filter((v, i, a) => a.indexOf(v) === i && v !== 'gemini-2.5-flash');

      let response: any = null;
      let lastError: any = null;

      // First attempt: with Search Grounding if explicitly enabled
      if (enableSearch) {
        for (const targetModel of modelsToTry) {
          try {
            response = await ai.models.generateContent({
              model: targetModel,
              contents,
              config: {
                systemInstruction,
                tools: [{ googleSearch: {} }],
              },
            });
            if (response && response.text !== undefined) {
              break;
            }
          } catch (err: any) {
            lastError = err;
            // Silent fallback to standard generation when search tool has tier quota
          }
        }
      }

      // Standard generation (if search was disabled, or if search encountered quota restrictions)
      if (!response) {
        for (const targetModel of modelsToTry) {
          try {
            response = await ai.models.generateContent({
              model: targetModel,
              contents,
              config: {
                systemInstruction,
              },
            });
            if (response && response.text !== undefined) {
              break;
            }
          } catch (err: any) {
            lastError = err;
          }
        }
      }

      if (!response) {
        const isQuota = lastError?.status === 429 || lastError?.message?.includes('RESOURCE_EXHAUSTED') || lastError?.message?.includes('quota');
        if (isQuota) {
          return res.status(429).json({
            error: 'Gemini API rate limit or quota exceeded for this key. Please wait a few moments before sending another message.',
          });
        }
        throw lastError || new Error('All model endpoints failed to generate a response');
      }

      const replyText = response?.text || '';

      // Extract search sources if present in grounding metadata
      const sources: Array<{ title: string; url: string }> = [];
      const chunks = response?.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (Array.isArray(chunks)) {
        for (const chunk of chunks) {
          if (chunk.web?.uri) {
            sources.push({
              title: chunk.web.title || chunk.web.uri,
              url: chunk.web.uri,
            });
          }
        }
      }

      return res.json({
        reply: replyText,
        sources,
      });
    } catch (error: any) {
      console.error('Gemini API Error:', error);
      return res.status(500).json({
        error: error?.message || 'Failed to generate response from Gemini API',
      });
    }
  });

  // Vite development middleware or static production serve
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Frostbite full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
