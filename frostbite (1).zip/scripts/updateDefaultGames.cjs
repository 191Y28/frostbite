const fs = require('fs');

let content = fs.readFileSync('src/data/defaultGames.ts', 'utf8');

// 1. Add cover image imports
const coverImports = `import johnnyUpgradeCover from '../assets/johnny-upgrade.jpeg';
import tagCover from '../assets/tag.jpeg';
import duckLife7BattleCover from '../assets/duck-life-7-battle.jpeg';
`;

content = content.replace("import { GTA_VICE_CITY_HTML }", coverImports + "import { JOHNNY_UPGRADE_HTML } from './johnnyUpgradeHtml';\nimport { TAG_HTML } from './tagHtml';\nimport { DUCK_LIFE_7_BATTLE_HTML } from './duckLife7BattleHtml';\nimport { GTA_VICE_CITY_HTML }");

// 2. Replace Subway Surfers New York entry
const oldSubwayNy = `  {
    id: 'subway-surfers-new-york',
    name: 'Subway Surfers: New York',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/newyork.html',
    coverUrl: subwaySurfersNewYorkCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089800000,
  },`;

const newSubwayNy = `  {
    id: 'subway-surfers-new-york',
    name: 'Subway Surfers: New York',
    iframeSrc: SUBWAY_SURFERS_NEW_YORK_HTML,
    isHtmlDoc: true,
    coverUrl: subwaySurfersNewYorkCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089800000,
  },`;

content = content.replace(oldSubwayNy, newSubwayNy);

// 3. Add the three new games near top of DEFAULT_GAMES
const newGames = `  {
    id: 'johnny-upgrade',
    name: 'Johnny Upgrade',
    iframeSrc: JOHNNY_UPGRADE_HTML,
    isHtmlDoc: true,
    coverUrl: johnnyUpgradeCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123000000,
  },
  {
    id: 'tag',
    name: 'Tag',
    iframeSrc: TAG_HTML,
    isHtmlDoc: true,
    coverUrl: tagCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726122900000,
  },
  {
    id: 'duck-life-7-battle',
    name: 'Duck Life 7: Battle',
    iframeSrc: DUCK_LIFE_7_BATTLE_HTML,
    isHtmlDoc: true,
    coverUrl: duckLife7BattleCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726122800000,
  },
`;

content = content.replace("export const DEFAULT_GAMES: GameItem[] = [\n", "export const DEFAULT_GAMES: GameItem[] = [\n" + newGames);

fs.writeFileSync('src/data/defaultGames.ts', content, 'utf8');
console.log('Updated src/data/defaultGames.ts successfully!');
