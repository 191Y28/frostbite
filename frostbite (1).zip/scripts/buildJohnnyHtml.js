const fs = require('fs');

const css = `<style type="text/css">
  html, body {
    margin: 0 !important;
    padding: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    background: #000 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    overflow: hidden !important;
  }
  canvas {
    margin: 0 !important;
    max-width: 100vw !important;
    max-height: 100vh !important;
    object-fit: contain !important;
  }
</style>`;

// We will construct the full HTML string for Johnny Upgrade
// The prompt contained the complete inline Phaser 2.6.2 and game code
