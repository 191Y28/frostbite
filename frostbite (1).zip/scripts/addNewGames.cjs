const fs = require('fs');

let content = fs.readFileSync('src/data/defaultGames.ts', 'utf8');

// 1. Add cover image imports
const newCoverImports = `import templeRun2FrozenShadowsCover from '../assets/temple-run-2-frozen-shadows.jpeg';
import ragdollHitCover from '../assets/ragdoll-hit.webp';
`;

content = content.replace("import templeRun2HoliFestivalCover from '../assets/temple-run-2-holi-festival.jpeg';", "import templeRun2HoliFestivalCover from '../assets/temple-run-2-holi-festival.jpeg';\n" + newCoverImports);

// 2. Add game definitions at top of DEFAULT_GAMES array
const newGamesEntries = `  {
    id: 'temple-run-2-frozen-shadows',
    name: 'Temple Run 2: Frozen Shadows',
    iframeSrc: 'https://tataedu23.github.io/g8/class-134',
    coverUrl: templeRun2FrozenShadowsCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123600000,
  },
  {
    id: 'ragdoll-hit',
    name: 'Ragdoll Hit',
    iframeSrc: 'https://tataedu23.github.io/g50/class-12',
    coverUrl: ragdollHitCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123500000,
  },
`;

content = content.replace("export const DEFAULT_GAMES: GameItem[] = [\n", "export const DEFAULT_GAMES: GameItem[] = [\n" + newGamesEntries);

fs.writeFileSync('src/data/defaultGames.ts', content, 'utf8');
console.log('Successfully updated src/data/defaultGames.ts with Temple Run 2 Frozen Shadows and Ragdoll Hit!');
