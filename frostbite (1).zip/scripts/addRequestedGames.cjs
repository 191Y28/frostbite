const fs = require('fs');

let content = fs.readFileSync('src/data/defaultGames.ts', 'utf8');

// 1. Add cover image imports
const coverImports = `import achievementUnlocked1Cover from '../assets/achievement-unlocked-1.jpeg';
import achievementUnlocked2Cover from '../assets/achievement-unlocked-2.jpeg';
import achievementUnlocked3Cover from '../assets/achievement-unlocked-3.jpeg';
import bobTheRobber4Cover from '../assets/bob-the-robber-4.jpeg';
`;

// Insert cover imports before the first HTML import
content = content.replace("import { JOHNNY_UPGRADE_HTML }", coverImports + "import { ACHIEVEMENT_UNLOCKED_1_HTML, ACHIEVEMENT_UNLOCKED_2_HTML, ACHIEVEMENT_UNLOCKED_3_HTML } from './achievementUnlockedHtml';\nimport { BOB_THE_ROBBER_4_HTML } from './bobTheRobber4Html';\nimport { INFINITE_CRAFT_HTML } from './infiniteCraftHtml';\nimport { JOHNNY_UPGRADE_HTML }");

// 2. Update Infinite Craft
const oldInfiniteCraft = `  {
    id: 'infinite-craft',
    name: 'Infinite Craft',
    iframeSrc: 'https://hfmanor.com/infinite-craft',
    coverUrl: infiniteCraftCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151400000,
  },`;

const newInfiniteCraft = `  {
    id: 'infinite-craft',
    name: 'Infinite Craft',
    iframeSrc: INFINITE_CRAFT_HTML,
    isHtmlDoc: true,
    coverUrl: infiniteCraftCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151400000,
  },`;

if (content.includes(oldInfiniteCraft)) {
  content = content.replace(oldInfiniteCraft, newInfiniteCraft);
} else {
  console.log("Warning: oldInfiniteCraft pattern not matched exactly, checking regex");
  content = content.replace(/id:\s*'infinite-craft',[\s\S]*?createdAt:\s*1726151400000,\s*\},/, `id: 'infinite-craft',
    name: 'Infinite Craft',
    iframeSrc: INFINITE_CRAFT_HTML,
    isHtmlDoc: true,
    coverUrl: infiniteCraftCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151400000,
  },`);
}

// 3. Add Achievement Unlocked 1, 2, 3 and Bob the Robber 4 near top of DEFAULT_GAMES
const newGamesList = `  {
    id: 'achievement-unlocked',
    name: 'Achievement Unlocked',
    iframeSrc: ACHIEVEMENT_UNLOCKED_1_HTML,
    isHtmlDoc: true,
    coverUrl: achievementUnlocked1Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123400000,
  },
  {
    id: 'achievement-unlocked-2',
    name: 'Achievement Unlocked 2',
    iframeSrc: ACHIEVEMENT_UNLOCKED_2_HTML,
    isHtmlDoc: true,
    coverUrl: achievementUnlocked2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123300000,
  },
  {
    id: 'achievement-unlocked-3',
    name: 'Achievement Unlocked 3',
    iframeSrc: ACHIEVEMENT_UNLOCKED_3_HTML,
    isHtmlDoc: true,
    coverUrl: achievementUnlocked3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123200000,
  },
  {
    id: 'bob-the-robber-4',
    name: 'Bob the Robber 4',
    iframeSrc: BOB_THE_ROBBER_4_HTML,
    isHtmlDoc: true,
    coverUrl: bobTheRobber4Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123100000,
  },
`;

content = content.replace("export const DEFAULT_GAMES: GameItem[] = [\n", "export const DEFAULT_GAMES: GameItem[] = [\n" + newGamesList);

fs.writeFileSync('src/data/defaultGames.ts', content, 'utf8');
console.log('Successfully updated src/data/defaultGames.ts!');
