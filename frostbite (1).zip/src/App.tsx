/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { ActiveView, CoverTransform, GameItem } from './types';
import { HomeView } from './components/HomeView';
import { GamesView } from './components/GamesView';
import { YouTubeView } from './components/YouTubeView';
import { AIView } from './components/AIView';
import { CalculatorCloak } from './components/CalculatorCloak';
import { ImageCropModal } from './components/ImageCropModal';
import { GameDirectoryModal } from './components/GameDirectoryModal';
import { DEFAULT_GAMES } from './data/defaultGames';

const STORAGE_KEY = 'frostbite_games_v23';
const UNLOCK_STORAGE_KEY = 'frostbite_unlocked';

export default function App() {
  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => {
    try {
      return localStorage.getItem(UNLOCK_STORAGE_KEY) === 'true';
    } catch {
      return false;
    }
  });

  const [activeView, setActiveView] = useState<ActiveView>('home');
  const [games, setGames] = useState<GameItem[]>(DEFAULT_GAMES);
  const [isGlobalAddOpen, setIsGlobalAddOpen] = useState(false);
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);
  const [isGameDirectoryOpen, setIsGameDirectoryOpen] = useState(false);
  const [gameToLaunch, setGameToLaunch] = useState<GameItem | null>(null);

  const handleUnlock = () => {
    try {
      localStorage.setItem(UNLOCK_STORAGE_KEY, 'true');
    } catch (e) {
      console.error(e);
    }
    setIsUnlocked(true);
  };

  // Global hidden shortcuts:
  // - Ctrl+Shift+J / Cmd+Shift+J (also Alt+Shift+J): Opens Alphabetical Game Directory & AI Prompt Exporter
  // - Ctrl+Shift+Y / Cmd+Shift+Y (also Alt+Shift+Y / Ctrl+Alt+Y): Opens Image Crop & Position Studio
  // - Ctrl+Alt+J (or Cmd+Alt+J on Mac): Opens Add Game modal
  // - Ctrl+Alt+L (or Cmd+Alt+L on Mac): Quick re-lock calculator disguise
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isCtrlOrMeta = e.ctrlKey || e.metaKey;
      const isShift = e.shiftKey;
      const isAlt = e.altKey;
      const isY = e.key === 'y' || e.key === 'Y' || e.code === 'KeyY' || e.keyCode === 89;
      const isJ = e.key === 'j' || e.key === 'J' || e.code === 'KeyJ' || e.keyCode === 74;

      // 1. Game Directory & Claude AI Prompt Exporter (Ctrl+Shift+J / Cmd+Shift+J / Alt+Shift+J)
      if (isJ && ((isCtrlOrMeta && isShift) || (isAlt && isShift))) {
        e.preventDefault();
        e.stopPropagation();
        setIsGameDirectoryOpen((prev) => !prev);
        return;
      }

      // 2. Image Crop Studio Shortcut (Ctrl+Shift+Y / Cmd+Shift+Y / Alt+Shift+Y / Ctrl+Alt+Y)
      if (isY && ((isCtrlOrMeta && isShift) || (isAlt && isShift) || (isCtrlOrMeta && isAlt))) {
        e.preventDefault();
        e.stopPropagation();
        setIsCropModalOpen((prev) => !prev);
        return;
      }

      // 3. Quick re-lock calculator disguise (Ctrl+Alt+L or Cmd+Alt+L)
      const isAltModifier = isCtrlOrMeta && isAlt;
      if (!isAltModifier) return;

      if (e.key === 'l' || e.key === 'L' || e.code === 'KeyL') {
        // Disguise / lock back to calculator
        e.preventDefault();
        try {
          localStorage.removeItem(UNLOCK_STORAGE_KEY);
        } catch {}
        setIsUnlocked(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown, { capture: true });
    return () => {
      window.removeEventListener('keydown', handleKeyDown, { capture: true });
    };
  }, []);

  // Load user-saved games from localStorage on mount (merging DEFAULT_GAMES if not present)
  useEffect(() => {
    try {
      // Clear legacy storage keys
      localStorage.removeItem('frostbite_games_v1');
      localStorage.removeItem('frostbite_games_v2');
      localStorage.removeItem('frostbite_games_v3');
      localStorage.removeItem('frostbite_games_v4');
      localStorage.removeItem('frostbite_games_v5');
      localStorage.removeItem('frostbite_games_v6');
      localStorage.removeItem('frostbite_games_v7');
      localStorage.removeItem('frostbite_games_v8');
      localStorage.removeItem('frostbite_games_v9');
      localStorage.removeItem('frostbite_games_v10');
      localStorage.removeItem('frostbite_games_v11');
      localStorage.removeItem('frostbite_games_v12');
      localStorage.removeItem('frostbite_games_v13');
      localStorage.removeItem('frostbite_games_v14');
      localStorage.removeItem('frostbite_games_v15');
      localStorage.removeItem('frostbite_games_v16');

      const saved = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('frostbite_games_v17');
      localStorage.removeItem('frostbite_games_v17');
      if (saved) {
        let parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Purge removed / placeholder games
          parsed = parsed.filter(
            (g: GameItem) =>
              g.id !== 'terraria' &&
              !g.name.toLowerCase().includes('terraria') &&
              g.id !== 'boxing-stars' &&
              !g.name.toLowerCase().includes('boxing stars') &&
              g.id !== 'minecraft-26-3' &&
              !g.name.toLowerCase().includes('minecraft (26.3)')
          );

          // Merge any missing default games into saved list
          const existingIds = new Set(parsed.map((g: GameItem) => g.id));
          const toAdd = DEFAULT_GAMES.filter((def) => !existingIds.has(def.id));

          let merged = [...toAdd, ...parsed];

          // Ensure covers and default properties are synchronized
          merged = merged.map((g: GameItem) => {
            const defaultMatch = DEFAULT_GAMES.find((d) => d.id === g.id);
            if (defaultMatch) {
              const isResetCropGame = g.id === 'bitlife' || g.id === '1v1-lol';
              return {
                ...g,
                name: defaultMatch.name,
                iframeSrc: defaultMatch.iframeSrc || g.iframeSrc,
                isHtmlDoc: defaultMatch.isHtmlDoc,
                coverUrl: defaultMatch.coverUrl || g.coverUrl,
                coverTransform: isResetCropGame ? undefined : (g.coverTransform || defaultMatch.coverTransform),
                tag: defaultMatch.tag !== undefined ? defaultMatch.tag : g.tag,
                sandboxMode: defaultMatch.sandboxMode || g.sandboxMode,
              };
            }
            return g;
          });

          setGames(merged);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
          return;
        }
      }

      // Initialize with clean curated DEFAULT_GAMES
      setGames(DEFAULT_GAMES);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_GAMES));
    } catch (e) {
      console.error('Failed to load games from localStorage:', e);
      setGames(DEFAULT_GAMES);
    }
  }, []);

  // Save games to localStorage whenever updated
  const saveGames = (newGames: GameItem[]) => {
    setGames(newGames);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newGames));
    } catch (e) {
      console.error('Failed to save games to localStorage:', e);
    }
  };

  const handleAddGame = (newGame: GameItem) => {
    const updated = [newGame, ...games];
    saveGames(updated);
  };

  const handleUpdateCover = (gameId: string, coverDataUrl: string) => {
    const updated = games.map((g) =>
      g.id === gameId ? { ...g, coverUrl: coverDataUrl } : g
    );
    saveGames(updated);
  };

  const handleUpdateCoverTransform = (gameId: string, transform: CoverTransform) => {
    const updated = games.map((g) =>
      g.id === gameId ? { ...g, coverTransform: transform } : g
    );
    saveGames(updated);
  };

  const handleDeleteGame = (gameId: string) => {
    const updated = games.filter((g) => g.id !== gameId);
    saveGames(updated);
  };

  if (!isUnlocked) {
    return <CalculatorCloak onUnlock={handleUnlock} />;
  }

  return (
    <div id="frostbite-root" className="min-h-screen w-full bg-slate-950 font-['Plus_Jakarta_Sans',sans-serif]">
      {activeView === 'home' && (
        <HomeView
          onSelectGames={() => setActiveView('games')}
          onSelectYouTube={() => setActiveView('youtube')}
          onSelectAI={() => setActiveView('ai')}
        />
      )}

      {activeView === 'games' && (
        <GamesView
          games={games}
          onBackToHome={() => setActiveView('home')}
          onAddGame={handleAddGame}
          onUpdateCover={handleUpdateCover}
          onDeleteGame={handleDeleteGame}
          externalAddOpen={isGlobalAddOpen}
          onResetExternalAdd={() => setIsGlobalAddOpen(false)}
          externalLaunchGame={gameToLaunch}
          onResetExternalLaunch={() => setGameToLaunch(null)}
        />
      )}

      {activeView === 'youtube' && (
        <YouTubeView onBackToHome={() => setActiveView('home')} />
      )}

      {activeView === 'ai' && (
        <AIView onBackToHome={() => setActiveView('home')} />
      )}

      {/* Alphabetical Game Directory & Claude AI Prompt Modal */}
      <GameDirectoryModal
        isOpen={isGameDirectoryOpen}
        onClose={() => setIsGameDirectoryOpen(false)}
        games={games}
        onLaunchGame={(game) => {
          setIsGameDirectoryOpen(false);
          setActiveView('games');
          setGameToLaunch(game);
        }}
      />

      {/* Image Crop & Position Studio Modal */}
      <ImageCropModal
        isOpen={isCropModalOpen}
        onClose={() => setIsCropModalOpen(false)}
        games={games}
        onUpdateTransform={handleUpdateCoverTransform}
      />
    </div>
  );
}
