/**
 * Frostbite Iframe Engine v2 Parser
 * Intelligently parses and auto-resolves user inputs:
 * - Direct URLs (https://...)
 * - GitHub.com repositories and subdirectories -> auto-resolved to GitHub Pages static host
 * - GitHub.io URLs -> auto-normalized with trailing slash or index.html to prevent 404s
 * - HTML DevTools inspect dumps -> auto-extracts GitHub.io script hosts and index.html
 * - Complete <iframe> tags with attributes
 * - Raw HTML game embed snippets (<embed>, <script>, <canvas>, etc.)
 */

export interface ParsedGameInput {
  src: string;
  title?: string;
  coverUrl?: string;
  isHtmlDoc?: boolean;
  resolutionNote?: string;
}

/**
 * Resolves a GitHub repository or subpath URL to its corresponding GitHub Pages URL.
 * Examples:
 * https://github.com/user/repo -> https://user.github.io/repo/
 * https://github.com/user/repo/tree/main/game -> https://user.github.io/repo/game/
 * https://github.com/user/repo/blob/main/game/index.html -> https://user.github.io/repo/game/index.html
 */
export function resolveGithubToPages(url: string): string | null {
  const trimmed = url.trim();

  // 1. github.com blob
  const blobMatch = trimmed.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/[^/]+\/(.+)$/i);
  if (blobMatch) {
    const [, user, repo, subpath] = blobMatch;
    return `https://${user}.github.io/${repo}/${subpath}`;
  }

  // 2. github.com tree
  const treeMatch = trimmed.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/tree\/[^/]+\/(.+)$/i);
  if (treeMatch) {
    const [, user, repo, subpath] = treeMatch;
    const cleanSub = subpath.replace(/\/+$/, '');
    return `https://${user}.github.io/${repo}/${cleanSub}/`;
  }

  // 3. github.com root repo
  const repoMatch = trimmed.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)(?:\/.*)?$/i);
  if (repoMatch) {
    const [, user, repo] = repoMatch;
    // Exclude special GitHub subdomains or paths
    if (!['features', 'pricing', 'about', 'join', 'login', 'explore', 'topics', 'trending'].includes(user.toLowerCase())) {
      return `https://${user}.github.io/${repo}/`;
    }
  }

  return null;
}

/**
 * Normalizes GitHub.io URLs by ensuring proper trailing slashes so relative scripts don't 404.
 */
export function normalizeGithubIoUrl(urlStr: string): string {
  try {
    const url = new URL(urlStr);
    if (url.hostname.toLowerCase().endsWith('.github.io')) {
      const parts = url.pathname.split('/');
      const last = parts[parts.length - 1];
      // If there's no file extension (.html, .htm, .js, etc.) and no trailing slash, append /
      if (!last.includes('.') && !url.pathname.endsWith('/')) {
        url.pathname += '/';
        return url.toString();
      }
    }
  } catch {
    // If not a valid URL yet, return raw
  }
  return urlStr;
}

export function parseIframeInput(input: string): ParsedGameInput {
  const trimmed = input.trim();
  if (!trimmed) {
    return { src: '' };
  }

  // 1. Check if user pasted an entire <iframe>...</iframe> HTML tag
  const iframeSrcMatch = trimmed.match(/<iframe\b[^>]*?\bsrc=["']([^"']+)["'][^>]*?>/i);
  if (iframeSrcMatch && iframeSrcMatch[1]) {
    let src = iframeSrcMatch[1].trim();
    if (src.startsWith('//')) {
      src = `https:${src}`;
    }
    const titleMatch =
      trimmed.match(/<title>([^<]+)<\/title>/i) ||
      trimmed.match(/\btitle=["']([^"']+)["']/i);
    const title = titleMatch ? titleMatch[1].replace(/\|.*$/, '').trim() : undefined;
    return { src: normalizeGithubIoUrl(src), title, isHtmlDoc: false };
  }

  // 2. Special resolvers for known games
  if (
    trimmed.toLowerCase().includes('barcelona') ||
    trimmed.includes('subway-surfers-unity/barcelona')
  ) {
    return {
      src: 'https://unblokedgames.github.io/projects/subway-surfers-unity/barcelona.html',
      title: 'Subway Surfers: Barcelona',
      coverUrl: '/covers/subway-surfers-barcelona.jpg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.toLowerCase().includes('beijing') ||
    trimmed.toLowerCase().includes('beijin') ||
    trimmed.includes('subway-surfers-unity/beijing')
  ) {
    return {
      src: 'https://unblokedgames.github.io/projects/subway-surfers-unity/beijing.html',
      title: 'Subway Surfers: Beijing',
      coverUrl: '/covers/subway-surfers-beijing.jpeg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.toLowerCase().includes('berlin') ||
    trimmed.includes('subway-surfers-unity/berlin')
  ) {
    return {
      src: 'https://unblokedgames.github.io/projects/subway-surfers-unity/berlin.html',
      title: 'Subway Surfers: Berlin',
      coverUrl: '/covers/subway-surfers-berlin.jpeg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.toLowerCase().includes('houston') ||
    trimmed.includes('subway-surfers-unity/houston')
  ) {
    return {
      src: 'https://unblokedgames.github.io/projects/subway-surfers-unity/houston.html',
      title: 'Subway Surfers: Houston',
      coverUrl: '/covers/subway-surfers-houston.jpeg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.toLowerCase().includes('iceland') ||
    trimmed.includes('subway-surfers-unity/iceland')
  ) {
    return {
      src: 'https://unblokedgames.github.io/projects/subway-surfers-unity/iceland.html',
      title: 'Subway Surfers: Iceland',
      coverUrl: '/covers/subway-surfers-iceland.jpg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.toLowerCase().includes('mexico') ||
    trimmed.includes('subway-surfers-unity/mexico')
  ) {
    return {
      src: 'https://unblokedgames.github.io/projects/subway-surfers-unity/mexico.html',
      title: 'Subway Surfers: Mexico',
      coverUrl: '/covers/subway-surfers-mexico.jpeg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.toLowerCase().includes('miami') ||
    trimmed.includes('subway-surfers-unity/miami')
  ) {
    return {
      src: 'https://unblokedgames.github.io/projects/subway-surfers-unity/miami.html',
      title: 'Subway Surfers: Miami',
      coverUrl: '/covers/subway-surfers-miami.jpeg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.toLowerCase().includes('winterholiday') ||
    trimmed.toLowerCase().includes('winter holiday') ||
    trimmed.includes('subway-surfers-unity/winterholiday')
  ) {
    return {
      src: 'https://unblokedgames.github.io/projects/subway-surfers-unity/winterholiday.html',
      title: 'Subway Surfers: Winter Holiday',
      coverUrl: '/covers/subway-surfers-winter-holiday.jpeg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.includes('games/bitlife') ||
    trimmed.includes('bitlife') ||
    trimmed.toLowerCase().includes('bit life')
  ) {
    return {
      src: 'https://ijnfem.github.io/seraph/games/bitlife/index.html',
      title: 'BitLife',
      coverUrl: '/covers/bitlife.jpeg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.toLowerCase().includes('buenos') ||
    trimmed.includes('60iqc76rla56c0zz5n8c8563j6caguek') ||
    trimmed.includes('Subway Surfers v0.3.9')
  ) {
    return {
      src: 'https://html5.gamemonetize.games/60iqc76rla56c0zz5n8c8563j6caguek/',
      title: 'Subway Surfers: Buenos Aires',
      coverUrl: '/covers/subway-surfers-buenos.webp',
      isHtmlDoc: false,
      resolutionNote: 'Auto-resolved Subway Surfers: Buenos Aires unblocked embed',
    };
  }
  if (
    trimmed.toLowerCase().includes('zurich') ||
    trimmed.includes('ZurichNewPrivacy') ||
    trimmed.includes('SubwaySurfersZurich')
  ) {
    return {
      src: 'https://staticquasar931.github.io/SubwaySurfersZurich/',
      title: 'Subway Surfers: Zurich',
      coverUrl: '/covers/subway-surfers-zurich.avif',
      isHtmlDoc: false,
      resolutionNote: 'Auto-resolved Subway Surfers: Zurich Unity WebGL build',
    };
  }
  if (
    trimmed.includes('games/subwaysurfers') ||
    trimmed.includes('subwaysurfers') ||
    trimmed.toLowerCase().includes('subway surfers') ||
    trimmed.toLowerCase().includes('subway surfer')
  ) {
    return {
      src: 'https://ijnfem.github.io/seraph/games/subwaysurfers/index.html',
      title: 'Subway Surfers San Francisco',
      coverUrl: '/covers/subway-surfers.jpg',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.includes('games/retrobowl') ||
    trimmed.includes('retrobowl') ||
    trimmed.toLowerCase().includes('retro bowl')
  ) {
    return {
      src: 'https://ijnfem.github.io/seraph/games/retrobowl/index.html',
      title: 'Retro Bowl',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.includes('games/fruitninja') ||
    trimmed.includes('fruitninja') ||
    trimmed.toLowerCase().includes('fruit ninja')
  ) {
    return {
      src: 'https://ijnfem.github.io/seraph/games/fruitninja/index.html',
      title: 'Fruit Ninja',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.includes('games/sm64') ||
    trimmed.includes('sm64') ||
    trimmed.toLowerCase().includes('mario 64') ||
    trimmed.toLowerCase().includes('super mario 64')
  ) {
    return {
      src: 'https://ijnfem.github.io/seraph/games/sm64/index.html',
      title: 'Super Mario 64',
      isHtmlDoc: false,
    };
  }
  if (
    trimmed.includes('games/slope') ||
    trimmed.includes('slope_new.json') ||
    (trimmed.includes('Slope') && trimmed.includes('Seraph')) ||
    trimmed === 'slope'
  ) {
    return {
      src: 'https://ijnfem.github.io/seraph/games/slope/index.html',
      title: 'Slope',
      isHtmlDoc: false,
    };
  }
  if (trimmed.includes('1v1.lol') || trimmed.includes('1v1lol') || trimmed.includes('372_49986_1v1')) {
    return {
      src: 'https://ijnfem.github.io/seraph/games/1v1lol/index.html',
      title: '1v1.lol',
      isHtmlDoc: false,
    };
  }
  if (trimmed.includes('Boxing-Physics-2') || trimmed.includes('Boxing Physics 2')) {
    return {
      src: 'https://23azostore.github.io/s2/boxing-physics-2/',
      title: 'Boxing Physics 2',
      isHtmlDoc: false,
    };
  }
  if (trimmed.includes('boxingrandom') || trimmed.includes('Boxing Random')) {
    return {
      src: 'https://ijnfem.github.io/seraph/games/boxingrandom/index.html',
      title: 'Boxing Random',
      isHtmlDoc: false,
    };
  }

  // 3. Inspect-element DevTools HTML dumps: Auto-detect any github.io asset links!
  // E.g.: <script src="https://user.github.io/repo/games/mygame/scripts/main.js"></script>
  const ghIoAssetMatch = trimmed.match(
    /https?:\/\/([a-zA-Z0-9_-]+\.github\.io\/[^\s"'>\\]+?\.(?:js|css|json|wasm|png|jpg|jpeg|html))/i
  );
  if (ghIoAssetMatch && (trimmed.includes('<html') || trimmed.includes('<script') || trimmed.includes('<head') || trimmed.includes('<body'))) {
    const assetUrl = ghIoAssetMatch[0];
    // Strip common subdirectories to find the root game folder
    const gameBase = assetUrl.replace(/\/(scripts|project|js|build|Build|assets|css|style|dist|media|storage)\/.*$/i, '');
    const titleMatch = trimmed.match(/<title>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].replace(/\|.*$/, '').trim() : undefined;
    const finalSrc = gameBase.endsWith('/') ? `${gameBase}index.html` : `${gameBase}/index.html`;

    return {
      src: finalSrc,
      title,
      isHtmlDoc: false,
      resolutionNote: 'Auto-detected GitHub.io static host and index.html from script references',
    };
  }

  // 4. HTML with <base href="...">
  const baseMatch = trimmed.match(/<base\b[^>]*?\bhref=["']([^"']+)["']/i);
  if (baseMatch && baseMatch[1] && (trimmed.includes('<html') || trimmed.includes('<head'))) {
    const baseHref = baseMatch[1].trim();
    const titleMatch = trimmed.match(/<title>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].replace(/\|.*$/, '').trim() : undefined;
    return {
      src: baseHref.endsWith('/') ? `${baseHref}index.html` : baseHref,
      title,
      isHtmlDoc: false,
      resolutionNote: 'Extracted game URL from <base href> tag',
    };
  }

  // 5. Unquoted or loosely formatted iframe tag
  const iframeLooseMatch = trimmed.match(/<iframe\b[^>]*?\bsrc=([^\s>]+)/i);
  if (iframeLooseMatch && iframeLooseMatch[1]) {
    let rawSrc = iframeLooseMatch[1].replace(/["']/g, '').trim();
    if (rawSrc.startsWith('//')) {
      rawSrc = `https:${rawSrc}`;
    }
    return { src: normalizeGithubIoUrl(rawSrc), isHtmlDoc: false };
  }

  // 6. Direct GitHub.com repository or branch URL -> Auto-resolve to GitHub Pages
  const resolvedGhPages = resolveGithubToPages(trimmed);
  if (resolvedGhPages) {
    return {
      src: normalizeGithubIoUrl(resolvedGhPages),
      isHtmlDoc: false,
      resolutionNote: 'Auto-resolved GitHub repository to GitHub Pages static host',
    };
  }

  // 7. Direct GitHub.io URL -> Normalize with trailing slash/index.html
  if (/^https?:\/\/[a-zA-Z0-9_-]+\.github\.io/i.test(trimmed)) {
    return {
      src: normalizeGithubIoUrl(trimmed),
      isHtmlDoc: false,
    };
  }

  // 8. Raw HTML / script embed code (like itch.io embed snippets or flash/canvas emulators)
  if (
    trimmed.startsWith('<!DOCTYPE') ||
    trimmed.startsWith('<html') ||
    (trimmed.includes('<script') && !trimmed.startsWith('http')) ||
    (trimmed.includes('<embed') && !trimmed.startsWith('http'))
  ) {
    return { src: trimmed, isHtmlDoc: true };
  }

  // 9. Direct URL
  if (/^https?:\/\//i.test(trimmed)) {
    return { src: trimmed, isHtmlDoc: false };
  }

  // 10. Protocol-relative //example.com
  if (trimmed.startsWith('//')) {
    return { src: `https:${trimmed}`, isHtmlDoc: false };
  }

  // 11. Domain like 1v1.lol or unblocked-games.com
  if (trimmed.includes('.') && !trimmed.includes('<') && !trimmed.includes(' ')) {
    return { src: `https://${trimmed}`, isHtmlDoc: false };
  }

  return { src: trimmed, isHtmlDoc: false };
}

/**
 * Reads a File object and returns a base64 DataURL string.
 */
export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read image as string data url'));
      }
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

