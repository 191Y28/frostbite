/**
 * Ultra-High-Performance Image Preloader and Cache optimized for Chromebooks (2-core 4GB).
 * Preloads and decodes game cover images off the main thread directly into the browser's
 * GPU texture cache, eliminating lazy load latency, blank pop-ins, and scroll stutter.
 */

// Global in-memory set of image URLs that have been decoded into GPU memory
const loadedImageCache = new Set<string>();
const inFlightPromises = new Map<string, Promise<boolean>>();
let isGameActiveGlobal = false;

export function setGameActive(active: boolean): void {
  isGameActiveGlobal = active;
  if (typeof window !== 'undefined') {
    (window as any).__FROSTBITE_GAME_ACTIVE__ = active;
  }
}

/**
 * Check synchronously if an image URL is already in memory cache
 */
export function isImagePreloaded(url: string | undefined): boolean {
  if (!url) return true;
  return loadedImageCache.has(url);
}

/**
 * Preload and decode a single image into memory using off-thread HTMLImageElement.decode()
 */
export function preloadImage(url: string, priority: 'high' | 'low' = 'low'): Promise<boolean> {
  if (!url || loadedImageCache.has(url)) {
    return Promise.resolve(true);
  }

  // If a game is currently playing, abort preloading to preserve 100% CPU/GPU/network for the game
  if (isGameActiveGlobal || (typeof window !== 'undefined' && (window as any).__FROSTBITE_GAME_ACTIVE__)) {
    return Promise.resolve(false);
  }

  const existing = inFlightPromises.get(url);
  if (existing) return existing;

  const promise = new Promise<boolean>((resolve) => {
    const img = new Image();

    // Hint to the browser network & layout scheduler
    if ('fetchPriority' in img) {
      (img as any).fetchPriority = priority;
    }

    img.decoding = 'async';

    const onFinish = () => {
      // Decode off-thread into GPU texture memory
      if ('decode' in img) {
        img
          .decode()
          .then(() => {
            loadedImageCache.add(url);
            inFlightPromises.delete(url);
            resolve(true);
          })
          .catch(() => {
            // Even if decode fails, browser has downloaded the bitmap
            loadedImageCache.add(url);
            inFlightPromises.delete(url);
            resolve(true);
          });
      } else {
        loadedImageCache.add(url);
        inFlightPromises.delete(url);
        resolve(true);
      }
    };

    img.onload = onFinish;
    img.onerror = () => {
      inFlightPromises.delete(url);
      resolve(false);
    };

    img.src = url;

    // If image is already cached synchronously (e.g. data URI or HTTP cache hit)
    if (img.complete && img.naturalWidth > 0) {
      onFinish();
    }
  });

  inFlightPromises.set(url, promise);
  return promise;
}

/**
 * High-concurrency batch preloader.
 * Concurrently warms up images using parallel worker queues during idle frames
 * without blocking the JavaScript execution thread or starving game loops.
 */
export function preloadImagesBatch(urls: (string | undefined)[], urgentCount = 6): void {
  // If game is actively playing, do not run background batch loads
  if (isGameActiveGlobal || (typeof window !== 'undefined' && (window as any).__FROSTBITE_GAME_ACTIVE__)) {
    return;
  }

  const validUrls = urls.filter((u): u is string => Boolean(u && !loadedImageCache.has(u)));
  if (validUrls.length === 0) return;

  // 1. Immediately warm up first urgent items in parallel with high priority
  const urgent = validUrls.slice(0, urgentCount);
  const remaining = validUrls.slice(urgentCount);

  urgent.forEach((url) => {
    preloadImage(url, 'high');
  });

  if (remaining.length === 0) return;

  // 2. Process remaining items during browser idle time
  const scheduleIdle = typeof window !== 'undefined' && 'requestIdleCallback' in window
    ? (window as any).requestIdleCallback
    : (cb: () => void) => setTimeout(cb, 200);

  scheduleIdle(() => {
    if (isGameActiveGlobal || (typeof window !== 'undefined' && (window as any).__FROSTBITE_GAME_ACTIVE__)) {
      return;
    }

    const concurrency = 4;
    let cursor = 0;

    const runWorker = () => {
      if (cursor >= remaining.length) return;
      if (isGameActiveGlobal || (typeof window !== 'undefined' && (window as any).__FROSTBITE_GAME_ACTIVE__)) {
        return;
      }
      const url = remaining[cursor++];
      preloadImage(url, 'low').finally(() => {
        runWorker();
      });
    };

    const activeWorkers = Math.min(concurrency, remaining.length);
    for (let i = 0; i < activeWorkers; i++) {
      runWorker();
    }
  });
}
