import React, { useState, useEffect } from 'react';
import { GameItem, CoverTransform } from '../types';
import {
  X,
  ZoomIn,
  ZoomOut,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Maximize2,
  Minimize2,
  ChevronLeft,
  ChevronRight,
  Sliders,
  Check,
} from 'lucide-react';

interface ImageCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  games: GameItem[];
  onUpdateTransform: (gameId: string, transform: CoverTransform) => void;
}

export const ImageCropModal: React.FC<ImageCropModalProps> = ({
  isOpen,
  onClose,
  games,
  onUpdateTransform,
}) => {
  const [selectedGameId, setSelectedGameId] = useState<string>(
    games[0]?.id || ''
  );
  const [stepSize, setStepSize] = useState<number>(5); // 1%, 5%, 15%

  // Ensure selected game is valid when games change
  useEffect(() => {
    if (games.length > 0 && (!selectedGameId || !games.some((g) => g.id === selectedGameId))) {
      setSelectedGameId(games[0].id);
    }
  }, [games, selectedGameId]);

  if (!isOpen || games.length === 0) return null;

  const currentGame = games.find((g) => g.id === selectedGameId) || games[0];
  const currentIndex = games.findIndex((g) => g.id === currentGame.id);

  const currentTransform: CoverTransform = currentGame.coverTransform || {
    scale: 1,
    x: 0,
    y: 0,
  };

  const updateCurrent = (newValues: Partial<CoverTransform>) => {
    const updated: CoverTransform = {
      scale: Math.max(0.2, Math.min(3.0, Number((newValues.scale !== undefined ? newValues.scale : currentTransform.scale).toFixed(2)))),
      x: Math.max(-100, Math.min(100, Math.round(newValues.x !== undefined ? newValues.x : currentTransform.x))),
      y: Math.max(-100, Math.min(100, Math.round(newValues.y !== undefined ? newValues.y : currentTransform.y))),
    };
    onUpdateTransform(currentGame.id, updated);
  };

  const handlePrevGame = () => {
    const prevIdx = (currentIndex - 1 + games.length) % games.length;
    setSelectedGameId(games[prevIdx].id);
  };

  const handleNextGame = () => {
    const nextIdx = (currentIndex + 1) % games.length;
    setSelectedGameId(games[nextIdx].id);
  };

  // Zoom actions
  const zoomIn = () => {
    const delta = stepSize / 100;
    updateCurrent({ scale: currentTransform.scale + delta });
  };

  const zoomOut = () => {
    const delta = stepSize / 100;
    updateCurrent({ scale: currentTransform.scale - delta });
  };

  // Pan actions
  const moveUp = () => updateCurrent({ y: currentTransform.y - stepSize });
  const moveDown = () => updateCurrent({ y: currentTransform.y + stepSize });
  const moveLeft = () => updateCurrent({ x: currentTransform.x - stepSize });
  const moveRight = () => updateCurrent({ x: currentTransform.x + stepSize });

  // Resets
  const resetAll = () => updateCurrent({ scale: 1, x: 0, y: 0 });
  const fitContainPreset = () => updateCurrent({ scale: 0.8, x: 0, y: 0 });
  const zoomOutWidePreset = () => updateCurrent({ scale: 0.65, x: 0, y: 0 });

  return (
    <div
      id="image-crop-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="image-crop-modal-container"
        onClick={(e) => e.stopPropagation()}
        className="relative flex w-full max-w-2xl flex-col rounded-2xl border border-cyan-500/30 bg-slate-950 p-6 shadow-2xl shadow-cyan-950/50 text-slate-100 max-h-[92vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              <Sliders className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-wide text-white">
                Image Crop & Position Studio
              </h2>
              <p className="text-xs text-slate-400">
                Adjust zoom and pan for cutoffs • Toggle with <kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono text-[11px] text-cyan-300 border border-slate-700">Ctrl+Shift+Y</kbd>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl border border-slate-800 bg-slate-900 p-2 text-slate-400 hover:border-slate-700 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Game Selector Bar */}
        <div className="mb-5 flex items-center gap-2">
          <button
            onClick={handlePrevGame}
            title="Previous Game"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-800 bg-slate-900 text-slate-300 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <select
            id="crop-game-selector"
            value={selectedGameId}
            onChange={(e) => setSelectedGameId(e.target.value)}
            className="flex-1 rounded-xl border border-slate-800 bg-slate-900 px-3.5 py-2.5 text-sm font-semibold text-white focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 cursor-pointer"
          >
            {games.map((g, idx) => (
              <option key={g.id} value={g.id}>
                {idx + 1}. {g.name}
              </option>
            ))}
          </select>

          <button
            onClick={handleNextGame}
            title="Next Game"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-800 bg-slate-900 text-slate-300 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>

        {/* Live Preview of Game Card Aspect Ratio */}
        <div className="mb-6 flex flex-col items-center">
          <div className="w-full max-w-md rounded-2xl border border-cyan-500/40 bg-slate-900/90 p-4 shadow-xl shadow-cyan-950/30">
            <div className="mb-2 flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-cyan-300 truncate max-w-[200px]">{currentGame.name}</span>
              <span className="font-mono text-[11px] text-slate-400">
                Zoom: {Math.round(currentTransform.scale * 100)}% | X: {currentTransform.x}% | Y: {currentTransform.y}%
              </span>
            </div>

            {/* Simulated Card Cover Box */}
            <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-slate-700/80 bg-black flex items-center justify-center">
              {currentGame.coverUrl ? (
                <img
                  src={currentGame.coverUrl}
                  alt={currentGame.name}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover select-none pointer-events-none"
                  style={{
                    transform: `scale(${currentTransform.scale}) translate(${currentTransform.x}%, ${currentTransform.y}%)`,
                    transformOrigin: 'center center',
                    transition: 'transform 0.08s ease-out',
                  }}
                />
              ) : (
                <div className="text-xs text-slate-500 font-mono">No cover image available</div>
              )}

              {/* Center guide crosshair subtle overlay */}
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-20">
                <div className="h-full w-px border-l border-dashed border-cyan-400" />
                <div className="absolute w-full h-px border-t border-dashed border-cyan-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Step Size Selector */}
        <div className="mb-4 flex items-center justify-between rounded-xl bg-slate-900/70 border border-slate-800/80 px-4 py-2.5">
          <span className="text-xs font-medium text-slate-300">Button Step Precision:</span>
          <div className="flex items-center gap-1.5">
            {[
              { label: 'Fine (1%)', value: 1 },
              { label: 'Normal (5%)', value: 5 },
              { label: 'Large (15%)', value: 15 },
            ].map((step) => (
              <button
                key={step.value}
                onClick={() => setStepSize(step.value)}
                className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-all ${
                  stepSize === step.value
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm shadow-cyan-500/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {step.label}
              </button>
            ))}
          </div>
        </div>

        {/* Action Controls Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Zoom Section */}
          <div className="rounded-xl border border-slate-800/80 bg-slate-900/50 p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                Zoom (Scale)
              </span>
              <span className="text-xs font-mono font-bold text-white bg-slate-800 px-2 py-0.5 rounded">
                {Math.round(currentTransform.scale * 100)}%
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={zoomOut}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2.5 text-xs font-semibold text-slate-200 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white active:scale-95 transition-all"
              >
                <ZoomOut className="h-4 w-4 text-cyan-400" />
                <span>Zoom Out (-{stepSize}%)</span>
              </button>

              <button
                type="button"
                onClick={zoomIn}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2.5 text-xs font-semibold text-slate-200 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white active:scale-95 transition-all"
              >
                <ZoomIn className="h-4 w-4 text-cyan-400" />
                <span>Zoom In (+{stepSize}%)</span>
              </button>
            </div>

            {/* Quick Zoom Presets */}
            <div className="mt-2.5 flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={fitContainPreset}
                className="flex-1 rounded-lg border border-slate-800/60 bg-slate-800/60 px-2 py-1.5 text-[11px] font-medium text-slate-300 hover:bg-slate-700 hover:text-white transition-colors text-center"
              >
                Fit 80%
              </button>
              <button
                type="button"
                onClick={zoomOutWidePreset}
                className="flex-1 rounded-lg border border-slate-800/60 bg-slate-800/60 px-2 py-1.5 text-[11px] font-medium text-slate-300 hover:bg-slate-700 hover:text-white transition-colors text-center"
              >
                Fit 65% (Wide)
              </button>
              <button
                type="button"
                onClick={() => updateCurrent({ scale: 1.0 })}
                className="flex-1 rounded-lg border border-slate-800/60 bg-slate-800/60 px-2 py-1.5 text-[11px] font-medium text-slate-300 hover:bg-slate-700 hover:text-white transition-colors text-center"
              >
                100% Reset
              </button>
            </div>
          </div>

          {/* Position / Pan Section (Directional Nudge Buttons) */}
          <div className="rounded-xl border border-slate-800/80 bg-slate-900/50 p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                Move / Pan Image
              </span>
              <span className="text-xs font-mono font-bold text-white bg-slate-800 px-2 py-0.5 rounded">
                X:{currentTransform.x}% Y:{currentTransform.y}%
              </span>
            </div>

            {/* Directional Pad */}
            <div className="flex flex-col items-center gap-1.5">
              <button
                type="button"
                onClick={moveUp}
                className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-200 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white active:scale-95 transition-all"
              >
                <ArrowUp className="h-4 w-4 text-cyan-400" />
                <span>Up (-{stepSize}%)</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={moveLeft}
                  className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-200 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white active:scale-95 transition-all"
                >
                  <ArrowLeft className="h-4 w-4 text-cyan-400" />
                  <span>Left</span>
                </button>

                <button
                  type="button"
                  onClick={() => updateCurrent({ x: 0, y: 0 })}
                  title="Center Position (0, 0)"
                  className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-bold text-cyan-300 hover:border-cyan-400 hover:bg-slate-700 hover:text-white transition-all"
                >
                  Center
                </button>

                <button
                  type="button"
                  onClick={moveRight}
                  className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-200 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white active:scale-95 transition-all"
                >
                  <span>Right</span>
                  <ArrowRight className="h-4 w-4 text-cyan-400" />
                </button>
              </div>

              <button
                type="button"
                onClick={moveDown}
                className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-200 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white active:scale-95 transition-all"
              >
                <ArrowDown className="h-4 w-4 text-cyan-400" />
                <span>Down (+{stepSize}%)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between border-t border-slate-800/80 pt-4">
          <button
            type="button"
            onClick={resetAll}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3.5 py-2 text-xs font-medium text-slate-400 hover:border-slate-700 hover:text-white transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset This Game</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-2 rounded-xl bg-cyan-500 px-5 py-2 text-xs font-bold tracking-wide text-slate-950 shadow-lg shadow-cyan-500/30 hover:bg-cyan-400 active:scale-95 transition-all"
          >
            <Check className="h-4 w-4" />
            <span>Done & Save</span>
          </button>
        </div>
      </div>
    </div>
  );
};
