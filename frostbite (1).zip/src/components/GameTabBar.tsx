import React from 'react';
import { GameItem } from '../types';
import { LayoutGrid, X, Plus, Gamepad2 } from 'lucide-react';

interface GameTabBarProps {
  openTabs: GameItem[];
  activeTabId: string | null;
  onSelectTab: (tabId: string | null) => void;
  onCloseTab: (gameId: string, e: React.MouseEvent) => void;
  onOpenLibrary: () => void;
}

export const GameTabBar: React.FC<GameTabBarProps> = ({
  openTabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onOpenLibrary,
}) => {
  if (openTabs.length === 0) return null;

  return (
    <div
      id="frostbite-game-tabs-bar"
      className="flex items-center h-10 w-full bg-slate-950/95 border-b border-slate-800/80 px-2 select-none z-50 overflow-x-auto shrink-0"
    >
      {/* Library Tab */}
      <button
        id="tab-btn-library"
        onClick={onOpenLibrary}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all shrink-0 ${
          activeTabId === null
            ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
            : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <LayoutGrid className="h-3.5 w-3.5" />
        <span>Library</span>
      </button>

      <div className="h-4 w-px bg-slate-800 mx-1.5 shrink-0" />

      {/* Open Game Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto flex-1 py-1">
        {openTabs.map((tab) => {
          const isActive = activeTabId === tab.id;
          return (
            <div
              key={tab.id}
              id={`game-tab-${tab.id}`}
              onClick={() => onSelectTab(tab.id)}
              className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all max-w-[200px] shrink-0 ${
                isActive
                  ? 'bg-slate-900 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-950/50'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
              }`}
            >
              {tab.coverUrl ? (
                <img
                  src={tab.coverUrl}
                  alt=""
                  className="h-4 w-4 rounded object-cover shrink-0"
                />
              ) : (
                <Gamepad2 className="h-3.5 w-3.5 shrink-0" />
              )}
              <span className="truncate max-w-[120px] font-sans text-xs">
                {tab.name}
              </span>
              <button
                id={`close-tab-${tab.id}`}
                onClick={(e) => onCloseTab(tab.id, e)}
                title="Close tab"
                className="p-0.5 rounded-md text-slate-500 hover:text-red-400 hover:bg-slate-800 transition-colors ml-0.5 shrink-0"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          );
        })}

        {/* Plus / Browse Library Button */}
        <button
          id="btn-add-tab-browse"
          onClick={onOpenLibrary}
          title="Browse library to open a game"
          className="flex items-center justify-center h-7 w-7 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-900 border border-slate-800/60 transition-colors shrink-0 ml-1"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
};
