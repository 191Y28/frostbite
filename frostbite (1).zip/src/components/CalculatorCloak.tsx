import React, { useEffect, useState } from 'react';
import { Delete, Lock } from 'lucide-react';

interface CalculatorCloakProps {
  onUnlock: () => void;
}

// Encoded token matrix
const _CLOAK_PAYLOAD = 'VDIxR2V4bz0=';
const _SALT_KEY = 'xZqL9mPvKwRt';

const decodeSecretSequence = (cipher: string, salt: string): string => {
  try {
    const raw = atob(atob(cipher));
    return raw
      .split('')
      .map((c, i) => String.fromCharCode(c.charCodeAt(0) ^ salt.charCodeAt(i % salt.length)))
      .join('');
  } catch {
    return '';
  }
};

export const CalculatorCloak: React.FC<CalculatorCloakProps> = ({ onUnlock }) => {
  const [display, setDisplay] = useState('0');
  const [prevValue, setPrevValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [secretBuffer, setSecretBuffer] = useState('');

  // Validate buffer against runtime decoded key sequence
  useEffect(() => {
    const target = decodeSecretSequence(_CLOAK_PAYLOAD, _SALT_KEY);
    if (target && secretBuffer.endsWith(target)) {
      onUnlock();
    }
  }, [secretBuffer, onUnlock]);

  // Physical keyboard listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Secret code tracker
      if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '#'].includes(e.key)) {
        setSecretBuffer((prev) => (prev + e.key).slice(-10));
      }

      if (e.key >= '0' && e.key <= '9') {
        inputDigit(e.key);
      } else if (e.key === '.') {
        inputDot();
      } else if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') {
        e.preventDefault();
        const op = e.key === '*' ? '×' : e.key === '/' ? '÷' : e.key;
        performOperation(op);
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        performOperation('=');
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape' || e.key === 'c' || e.key === 'C') {
        clearAll();
      } else if (e.key === '#') {
        inputHash();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [display, prevValue, operation, waitingForOperand]);

  const inputDigit = (digit: string) => {
    setSecretBuffer((prev) => (prev + digit).slice(-10));
    if (waitingForOperand) {
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const inputHash = () => {
    setSecretBuffer((prev) => (prev + '#').slice(-10));
    setDisplay((prev) => (prev === '0' ? '#' : prev + '#'));
  };

  const inputDot = () => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
      return;
    }
    if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const clearAll = () => {
    setDisplay('0');
    setPrevValue(null);
    setOperation(null);
    setWaitingForOperand(false);
  };

  const handleBackspace = () => {
    if (waitingForOperand) return;
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  const toggleSign = () => {
    const val = parseFloat(display);
    if (!isNaN(val)) {
      setDisplay(String(-val));
    }
  };

  const inputPercent = () => {
    const val = parseFloat(display);
    if (!isNaN(val)) {
      setDisplay(String(val / 100));
    }
  };

  const performOperation = (nextOp: string) => {
    const inputValue = parseFloat(display.replace(/#/g, ''));

    if (isNaN(inputValue)) {
      clearAll();
      return;
    }

    if (prevValue === null) {
      setPrevValue(inputValue);
    } else if (operation) {
      const currentValue = prevValue;
      let newValue = currentValue;

      switch (operation) {
        case '+':
          newValue = currentValue + inputValue;
          break;
        case '-':
          newValue = currentValue - inputValue;
          break;
        case '×':
        case '*':
          newValue = currentValue * inputValue;
          break;
        case '÷':
        case '/':
          newValue = inputValue !== 0 ? currentValue / inputValue : 0;
          break;
        default:
          break;
      }

      setPrevValue(newValue);
      setDisplay(String(Number(newValue.toFixed(8))));
    }

    setWaitingForOperand(true);
    setOperation(nextOp === '=' ? null : nextOp);
  };

  return (
    <div
      id="calculator-cloak-view"
      className="flex min-h-screen w-full flex-col items-center justify-center bg-slate-950 p-4 font-sans text-slate-100 select-none"
    >
      {/* Sleek Calculator Chassis */}
      <div className="w-full max-w-xs sm:max-w-sm rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-2xl shadow-black/80 backdrop-blur-xl">
        {/* Header / Brand */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800/80 mb-4">
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-slate-700" />
            <div className="h-2.5 w-2.5 rounded-full bg-slate-700" />
            <div className="h-2.5 w-2.5 rounded-full bg-slate-700" />
          </div>
          <span className="text-[11px] font-mono tracking-widest text-slate-500 uppercase">
            Calculator v2.4
          </span>
          <div className="w-8" />
        </div>

        {/* Display Screen */}
        <div className="mb-6 flex flex-col items-end justify-end rounded-2xl border border-slate-800 bg-slate-950/90 p-4 h-24 overflow-hidden">
          <div className="text-xs font-mono text-slate-500 h-4">
            {prevValue !== null && operation ? `${prevValue} ${operation}` : ''}
          </div>
          <div
            id="calc-display"
            className="w-full text-right font-mono text-3xl sm:text-4xl font-light text-slate-100 truncate tracking-tight"
          >
            {display}
          </div>
        </div>

        {/* Keypad Grid */}
        <div className="grid grid-cols-4 gap-3">
          {/* Row 1 */}
          <button
            type="button"
            onClick={clearAll}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/80 text-base font-semibold text-slate-300 hover:bg-slate-700 active:scale-95 transition-all"
          >
            C
          </button>
          <button
            type="button"
            onClick={toggleSign}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/80 text-base font-semibold text-slate-300 hover:bg-slate-700 active:scale-95 transition-all"
          >
            ±
          </button>
          <button
            type="button"
            onClick={inputPercent}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/80 text-base font-semibold text-slate-300 hover:bg-slate-700 active:scale-95 transition-all"
          >
            %
          </button>
          <button
            type="button"
            onClick={() => performOperation('÷')}
            className={`flex h-14 items-center justify-center rounded-2xl text-lg font-bold transition-all active:scale-95 ${
              operation === '÷'
                ? 'bg-amber-500 text-white'
                : 'bg-amber-600/90 text-white hover:bg-amber-500'
            }`}
          >
            ÷
          </button>

          {/* Row 2 */}
          <button
            type="button"
            onClick={() => inputDigit('7')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            7
          </button>
          <button
            type="button"
            onClick={() => inputDigit('8')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            8
          </button>
          <button
            type="button"
            onClick={() => inputDigit('9')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            9
          </button>
          <button
            type="button"
            onClick={() => performOperation('×')}
            className={`flex h-14 items-center justify-center rounded-2xl text-lg font-bold transition-all active:scale-95 ${
              operation === '×'
                ? 'bg-amber-500 text-white'
                : 'bg-amber-600/90 text-white hover:bg-amber-500'
            }`}
          >
            ×
          </button>

          {/* Row 3 */}
          <button
            type="button"
            onClick={() => inputDigit('4')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            4
          </button>
          <button
            type="button"
            onClick={() => inputDigit('5')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            5
          </button>
          <button
            type="button"
            onClick={() => inputDigit('6')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            6
          </button>
          <button
            type="button"
            onClick={() => performOperation('-')}
            className={`flex h-14 items-center justify-center rounded-2xl text-lg font-bold transition-all active:scale-95 ${
              operation === '-'
                ? 'bg-amber-500 text-white'
                : 'bg-amber-600/90 text-white hover:bg-amber-500'
            }`}
          >
            −
          </button>

          {/* Row 4 */}
          <button
            type="button"
            onClick={() => inputDigit('1')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            1
          </button>
          <button
            type="button"
            onClick={() => inputDigit('2')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            2
          </button>
          <button
            type="button"
            onClick={() => inputDigit('3')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            3
          </button>
          <button
            type="button"
            onClick={() => performOperation('+')}
            className={`flex h-14 items-center justify-center rounded-2xl text-lg font-bold transition-all active:scale-95 ${
              operation === '+'
                ? 'bg-amber-500 text-white'
                : 'bg-amber-600/90 text-white hover:bg-amber-500'
            }`}
          >
            +
          </button>

          {/* Row 5 */}
          <button
            type="button"
            onClick={() => inputDigit('0')}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            0
          </button>
          <button
            type="button"
            onClick={inputDot}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-100 hover:bg-slate-800 active:scale-95 transition-all"
          >
            .
          </button>
          <button
            type="button"
            id="btn-calc-hash"
            onClick={inputHash}
            className="flex h-14 items-center justify-center rounded-2xl bg-slate-800/50 text-xl font-medium text-slate-300 hover:bg-slate-800 hover:text-white active:scale-95 transition-all"
          >
            #
          </button>
          <button
            type="button"
            onClick={() => performOperation('=')}
            className="flex h-14 items-center justify-center rounded-2xl bg-cyan-600 text-xl font-bold text-white shadow-lg shadow-cyan-600/20 hover:bg-cyan-500 active:scale-95 transition-all"
          >
            =
          </button>
        </div>
      </div>
    </div>
  );
};
