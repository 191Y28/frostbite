import React, { useState } from 'react';
import { UpcomingGameItem } from '../types';
import { Clock, Sparkles, Info, X } from 'lucide-react';

interface UpcomingGameCardProps {
  game: UpcomingGameItem;
}

export const UpcomingGameCard: React.FC<UpcomingGameCardProps> = ({ game }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <div
        id={`upcoming-card-${game.id}`}
        onClick={() => setIsModalOpen(true)}
        className="group relative flex flex-col overflow-hidden rounded-2xl border border-amber-500/20 bg-gradient-to-b from-slate-900/90 to-slate-950/90 p-3 shadow-lg shadow-black/40 transition-all duration-300 hover:-translate-y-1 hover:border-amber-400/50 hover:shadow-amber-500/10 hover:shadow-2xl cursor-pointer"
      >
        {/* Ambient Glow */}
        <div className="absolute -inset-0.5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10 opacity-0 blur transition-opacity duration-300 group-hover:opacity-100 -z-10" />

        {/* Image Container with 16:9 Aspect Ratio */}
        <div className="relative aspect-video w-full overflow-hidden rounded-xl bg-slate-900">
          <img
            src={game.coverUrl}
            alt={game.name}
            className="h-full w-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-105"
            loading="lazy"
          />

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          {/* Upcoming Badge */}
          <div className="absolute top-2.5 right-2.5 z-10">
            <span className="flex items-center gap-1 rounded-md border border-amber-400/50 bg-amber-950/80 px-2 py-0.5 text-[10px] font-bold tracking-widest text-amber-300 backdrop-blur-md shadow-md shadow-black/60 font-mono">
              <Sparkles className="h-3 w-3 text-amber-400 animate-pulse" />
              UPCOMING
            </span>
          </div>

          {/* Hover Action Overlay */}
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 backdrop-blur-[2px] transition-opacity duration-200 group-hover:opacity-100">
            <div className="flex items-center gap-1.5 rounded-xl border border-amber-400/60 bg-amber-950/90 px-3.5 py-1.5 text-xs font-bold tracking-wider text-amber-200 shadow-lg">
              <Clock className="h-3.5 w-3.5 text-amber-400" />
              <span>COMING SOON</span>
            </div>
          </div>
        </div>

        {/* Title & Info */}
        <div className="mt-3 flex flex-col gap-0.5">
          <div className="flex items-center justify-between gap-2">
            <h4 className="font-['Iceberg',cursive,sans-serif] text-sm font-semibold tracking-wide text-slate-100 group-hover:text-amber-300 transition-colors truncate">
              {game.name}
            </h4>
            <span className="shrink-0 text-[10px] font-mono text-amber-400/90 bg-amber-950/40 border border-amber-800/40 rounded px-1.5 py-0.2">
              SOON
            </span>
          </div>
          {game.releaseNote && (
            <p className="text-[11px] text-slate-400 truncate">
              {game.releaseNote}
            </p>
          )}
        </div>
      </div>

      {/* Info Modal */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200"
          onClick={() => setIsModalOpen(false)}
        >
          <div
            className="relative w-full max-w-md overflow-hidden rounded-2xl border border-amber-500/30 bg-slate-900 p-6 shadow-2xl shadow-amber-500/10 text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="aspect-video w-full overflow-hidden rounded-xl mb-4 border border-slate-800">
              <img
                src={game.coverUrl}
                alt={game.name}
                className="h-full w-full object-cover"
              />
            </div>

            <div className="flex items-center gap-2 mb-2">
              <span className="flex items-center gap-1 rounded bg-amber-950/90 border border-amber-500/50 px-2 py-0.5 text-[10px] font-mono font-bold text-amber-300">
                <Sparkles className="h-3 w-3 text-amber-400" />
                UPCOMING RELEASE
              </span>
            </div>

            <h3 className="font-['Iceberg',cursive,sans-serif] text-xl font-bold text-white mb-1">
              {game.name}
            </h3>
            <p className="text-xs text-slate-300 mb-4">
              {game.releaseNote || 'This title is currently being prepared and tested for seamless web compatibility.'}
            </p>

            <div className="flex items-start gap-2.5 rounded-xl border border-slate-800 bg-slate-950/60 p-3 text-xs text-slate-400">
              <Info className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                Our developers are testing and packaging this game engine. It will become playable directly in the Frostbite library in an upcoming deployment!
              </span>
            </div>

            <button
              onClick={() => setIsModalOpen(false)}
              className="mt-5 w-full rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 py-2 text-xs font-semibold tracking-wider text-slate-200 transition-colors"
            >
              GOT IT
            </button>
          </div>
        </div>
      )}
    </>
  );
};
