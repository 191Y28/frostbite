import React, { useEffect, useRef, useState } from 'react';
import { GameItem } from '../types';
import { setGameActive } from '../utils/imagePreloader';
import {
  ArrowLeft,
  ExternalLink,
  Maximize,
  Minimize,
  RefreshCw,
  Shield,
  ShieldAlert,
  X,
  Zap,
  Play,
  Square,
  Sliders,
  Cpu,
  MousePointer,
  Sparkles,
  Monitor,
  Tv,
} from 'lucide-react';

type AspectRatioMode = 'fill' | '16:9' | '4:3';

interface FullscreenGameModalProps {
  game: GameItem;
  onClose: () => void;
  tabsBar?: React.ReactNode;
}

export const FullscreenGameModal: React.FC<FullscreenGameModalProps> = ({
  game,
  onClose,
  tabsBar,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<AspectRatioMode>('fill');
  const [isCompatibilityMode, setIsCompatibilityMode] = useState(
    game.sandboxMode === 'unrestricted'
  );
  const [iframeKey, setIframeKey] = useState(0);
  const showTimerRef = useRef<NodeJS.Timeout | null>(null);
  const hideTimerRef = useRef<NodeJS.Timeout | null>(null);
  const hasEnteredNativeFsRef = useRef(false);

  // Auto Clicker State
  const isCookieClicker =
    game.id === 'cookie-clicker' ||
    game.name.toLowerCase().includes('cookie clicker');
  const [isAutoClickerOpen, setIsAutoClickerOpen] = useState(false);
  const [isAutoClicking, setIsAutoClicking] = useState(false);
  // Default 20ms = 50 CPS (specifically tuned for 2-core 4GB Chromebooks)
  const [clickIntervalMs, setClickIntervalMs] = useState<number>(20);
  const [totalClicks, setTotalClicks] = useState<number>(0);

  const autoClickerTimerRef = useRef<NodeJS.Timeout | null>(null);
  const clicksAccumulatorRef = useRef<number>(0);

  // Clear timers and toggle active game state on mount/unmount
  useEffect(() => {
    setGameActive(true);
    return () => {
      setGameActive(false);
      if (showTimerRef.current) clearTimeout(showTimerRef.current);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
      if (autoClickerTimerRef.current) clearInterval(autoClickerTimerRef.current);
    };
  }, []);

  // Listen for iframe close message (e.g. from Terraria / GTA error screens)
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data && (e.data.type === 'CLOSE_MODAL' || e.data === 'CLOSE_MODAL')) {
        handleExit();
      }
    };
    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, []);

  // Auto-request browser fullscreen on launch
  useEffect(() => {
    const enterNativeFullscreen = async () => {
      try {
        if (containerRef.current && !document.fullscreenElement) {
          await containerRef.current.requestFullscreen();
          setIsFullscreen(true);
          hasEnteredNativeFsRef.current = true;
        }
      } catch {
        // Handled silently
      }
    };

    enterNativeFullscreen();

    const handleFullscreenChange = () => {
      const isNativeFs = Boolean(document.fullscreenElement);
      setIsFullscreen(isNativeFs);
      if (!isNativeFs && hasEnteredNativeFsRef.current) {
        onClose();
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [onClose]);

  // Global ESC key listener & Auto-Clicker hotkey (C or X)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Esc') {
        e.preventDefault();
        handleExit();
        return;
      }
      const target = e.target as HTMLElement | null;
      const isInputField =
        target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA');
      if (
        !isInputField &&
        (e.key === 'c' || e.key === 'C' || e.key === 'x' || e.key === 'X')
      ) {
        setIsAutoClicking((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  // Auto Clicker Core Loop
  useEffect(() => {
    if (!isAutoClicking) {
      if (autoClickerTimerRef.current) {
        clearInterval(autoClickerTimerRef.current);
        autoClickerTimerRef.current = null;
      }
      return;
    }

    const triggerClick = () => {
      const iframe = iframeRef.current;
      if (!iframe) return;

      try {
        const win = iframe.contentWindow as any;
        const doc = iframe.contentDocument;

        // Method 1: Direct Cookie Clicker Game Engine Hook
        if (win && win.Game && typeof win.Game.ClickCookie === 'function') {
          win.Game.ClickCookie();
        } else if (doc) {
          // Method 2: Target bigCookie DOM element
          const bigCookie = doc.getElementById('bigCookie');
          if (bigCookie) {
            bigCookie.click();
          } else {
            // Method 3: Target canvas or active center point
            const canvas = doc.querySelector('canvas') || doc.body;
            if (canvas) {
              const rect = canvas.getBoundingClientRect();
              const evt = new MouseEvent('click', {
                view: win,
                bubbles: true,
                cancelable: true,
                clientX: rect.left + rect.width / 2,
                clientY: rect.top + rect.height / 2,
              });
              canvas.dispatchEvent(evt);
            }
          }
        }
      } catch (err) {
        // Cross-origin fallback
      }

      // Always send postMessage as well so iframe listeners receive it
      try {
        iframe.contentWindow?.postMessage({ type: 'AUTO_CLICK' }, '*');
      } catch {}

      clicksAccumulatorRef.current += 1;
    };

    const effectiveInterval = Math.max(1, clickIntervalMs);
    autoClickerTimerRef.current = setInterval(triggerClick, effectiveInterval);

    // UI Throttle: update displayed count every 150ms to prevent low-end CPU lag
    const uiInterval = setInterval(() => {
      if (clicksAccumulatorRef.current > 0) {
        setTotalClicks((prev) => prev + clicksAccumulatorRef.current);
        clicksAccumulatorRef.current = 0;
      }
    }, 150);

    return () => {
      if (autoClickerTimerRef.current) {
        clearInterval(autoClickerTimerRef.current);
      }
      clearInterval(uiInterval);
    };
  }, [isAutoClicking, clickIntervalMs]);

  const handleExit = async () => {
    if (document.fullscreenElement) {
      try {
        await document.exitFullscreen();
      } catch (err) {
        console.error('Exit fullscreen error:', err);
      }
    }
    onClose();
  };

  const toggleNativeFullscreen = async () => {
    if (!document.fullscreenElement && containerRef.current) {
      try {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } catch (err) {
        console.error('Request fullscreen error:', err);
      }
    } else if (document.fullscreenElement) {
      try {
        await document.exitFullscreen();
        setIsFullscreen(false);
      } catch (err) {
        console.error('Exit fullscreen error:', err);
      }
    }
  };

  const handleReload = () => {
    setIframeKey((prev) => prev + 1);
  };

  // Top area hover handler: requires 3 continuous seconds of hover before showing
  const handleTopAreaMouseEnter = () => {
    if (hideTimerRef.current) {
      clearTimeout(hideTimerRef.current);
      hideTimerRef.current = null;
    }
    if (!showControls && !showTimerRef.current) {
      showTimerRef.current = setTimeout(() => {
        setShowControls(true);
        showTimerRef.current = null;
      }, 3000);
    }
  };

  // When mouse leaves the top hover area, disappears in 1 second
  const handleTopAreaMouseLeave = () => {
    if (showTimerRef.current) {
      clearTimeout(showTimerRef.current);
      showTimerRef.current = null;
    }
    if (hideTimerRef.current) {
      clearTimeout(hideTimerRef.current);
    }
    hideTimerRef.current = setTimeout(() => {
      setShowControls(false);
      hideTimerRef.current = null;
    }, 1000);
  };

  // Launch in about:blank cloaked tab for stubborn X-Frame-Options blocked games
  const openCloakedWindow = () => {
    const win = window.open('about:blank', '_blank');
    if (win) {
      win.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>${game.name}</title>
            <link rel="icon" href="https://ssl.gstatic.com/docs/doclist/images/infinite_drives_24dp.png">
            <style>
              html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #000; }
              iframe { border: 0; width: 100%; height: 100%; }
            </style>
          </head>
          <body>
            <iframe src="${game.iframeSrc}" allow="fullscreen; autoplay; gamepad; clipboard-write; encrypted-media"></iframe>
          </body>
        </html>
      `);
      win.document.close();
    }
  };

  // Standard Frostbite v2 Sandboxing policies
  const standardSandbox =
    'allow-scripts allow-same-origin allow-forms allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-orientation-lock allow-presentation';

  // Comprehensive Frostbite v2 Feature Policies with WebGL & GPU Compositor Acceleration
  const comprehensivePermissions =
    'accelerometer; autoplay; camera; clipboard-read; clipboard-write; display-capture; encrypted-media; fullscreen; gamepad; geolocation; gyroscope; hid; microphone; midi; payment; picture-in-picture; screen-wake-lock; speaker-selection; usb; web-share; xr-spatial-tracking; focus-without-user-activation; cross-origin-isolated; execution-while-out-of-viewport; execution-while-not-rendered; webgl; webgl2';

  const currentCps = Math.round(1000 / Math.max(1, clickIntervalMs));

  const isHfManor =
    !game.isHtmlDoc &&
    typeof game.iframeSrc === 'string' &&
    game.iframeSrc.includes('hfmanor.com');

  return (
    <div
      ref={containerRef}
      id="frostbite-fullscreen-player"
      className="fixed inset-0 z-50 flex flex-col bg-black overflow-hidden select-none"
    >
      {tabsBar}

      {/* Top Hover Zone: takes 3 seconds of hover to reveal HUD, and disappears 1 second after leaving */}
      <div
        onMouseEnter={handleTopAreaMouseEnter}
        onMouseLeave={handleTopAreaMouseLeave}
        className={`absolute ${tabsBar ? 'top-10' : 'top-0'} left-0 right-0 z-50 transition-all duration-300 ${
          showControls ? 'pointer-events-auto' : 'pointer-events-auto h-4'
        }`}
      >
        {/* Floating HUD Bar (Frostbite v2 Control Deck) */}
        <div
          id="player-hud"
          className={`w-full flex items-center justify-between px-4 sm:px-6 py-2.5 bg-gradient-to-b from-slate-950/95 via-slate-950/80 to-transparent backdrop-blur-md border-b border-cyan-950/40 transition-all duration-300 ${
            showControls
              ? 'opacity-100 translate-y-0 pointer-events-auto'
              : 'opacity-0 -translate-y-full pointer-events-none'
          }`}
        >
          {/* Left: Back & Title */}
          <div className="flex items-center gap-3">
            <button
              id="btn-player-back"
              onClick={handleExit}
              className="flex items-center gap-2 rounded-xl border border-cyan-500/30 bg-slate-900/90 px-3.5 py-1.5 text-xs font-semibold tracking-wide text-slate-200 shadow-lg shadow-black/50 transition-all duration-200 hover:border-cyan-400 hover:bg-slate-800 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="font-['Iceberg',cursive,sans-serif] tracking-wider">BACK TO GAMES</span>
              <kbd className="hidden sm:inline-block rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-mono text-cyan-400 border border-slate-700">
                ESC
              </kbd>
            </button>

            <div className="hidden sm:flex items-center gap-2 border-l border-slate-800 pl-3">
              <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
              <span className="font-['Iceberg',cursive,sans-serif] text-sm tracking-wider text-slate-200 truncate max-w-xs md:max-w-md">
                {game.name}
              </span>
              {game.tag && (
                <span className="rounded bg-rose-950/90 border border-rose-500/60 px-1.5 py-0.5 text-[9px] font-mono font-bold text-rose-300">
                  {game.tag}
                </span>
              )}
            </div>
          </div>

          {/* Right: Quick Tools (v2 engine toggles + Auto Clicker) */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Auto Clicker Menu Toggle Button */}
            <button
              id="btn-toggle-autoclicker"
              onClick={() => setIsAutoClickerOpen((prev) => !prev)}
              title="Open Auto Clicker Control Panel (Hotkey: C / X)"
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-mono font-semibold transition-all shadow-md ${
                isAutoClicking
                  ? 'border-emerald-500/80 bg-emerald-950/70 text-emerald-300 ring-2 ring-emerald-500/40 animate-pulse'
                  : isAutoClickerOpen
                  ? 'border-cyan-500 bg-cyan-950/50 text-cyan-300'
                  : isCookieClicker
                  ? 'border-amber-500/60 bg-amber-950/40 text-amber-300 hover:bg-amber-900/50 hover:border-amber-400'
                  : 'border-slate-800 bg-slate-900/80 text-slate-300 hover:border-cyan-500/40 hover:bg-slate-800'
              }`}
            >
              <Zap className={`h-3.5 w-3.5 ${isAutoClicking ? 'text-emerald-400 fill-emerald-400' : 'text-amber-400'}`} />
              <span>AUTO CLICKER</span>
              {isAutoClicking && (
                <span className="rounded-full bg-emerald-500/20 px-1.5 py-0.2 text-[10px] text-emerald-300">
                  {currentCps} CPS
                </span>
              )}
            </button>

            {/* Compatibility / Sandbox Mode Toggle */}
            <button
              id="btn-toggle-sandbox"
              onClick={() => {
                setIsCompatibilityMode((prev) => !prev);
                setIframeKey((k) => k + 1);
              }}
              title={
                isCompatibilityMode
                  ? 'Unrestricted Compatibility Mode active (click to enable standard sandbox)'
                  : 'Standard Protected Sandbox active (click to enable unrestricted compatibility)'
              }
              className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-[11px] font-mono transition-all ${
                isCompatibilityMode
                  ? 'border-amber-500/50 bg-amber-950/30 text-amber-300 hover:bg-amber-900/40'
                  : 'border-slate-800 bg-slate-900/80 text-slate-400 hover:border-cyan-500/40 hover:text-slate-200'
              }`}
            >
              {isCompatibilityMode ? (
                <>
                  <ShieldAlert className="h-3.5 w-3.5 text-amber-400" />
                  <span className="hidden md:inline">UNRESTRICTED</span>
                </>
              ) : (
                <>
                  <Shield className="h-3.5 w-3.5 text-cyan-400" />
                  <span className="hidden md:inline">SANDBOXED</span>
                </>
              )}
            </button>

            {/* Aspect Ratio Switcher */}
            <button
              id="btn-aspect-ratio"
              onClick={() => {
                setAspectRatio((curr) =>
                  curr === 'fill' ? '16:9' : curr === '16:9' ? '4:3' : 'fill'
                );
              }}
              title={`Aspect ratio: ${aspectRatio.toUpperCase()} (click to cycle)`}
              className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900/80 px-2.5 py-1.5 text-[11px] font-mono text-slate-300 hover:border-cyan-500/40 hover:bg-slate-800 transition-colors"
            >
              {aspectRatio === 'fill' ? (
                <Monitor className="h-3.5 w-3.5 text-cyan-400" />
              ) : (
                <Tv className="h-3.5 w-3.5 text-cyan-400" />
              )}
              <span className="hidden sm:inline">{aspectRatio.toUpperCase()}</span>
            </button>

            {/* Cloaked Window Popout (Bypasses Frame Blocks) */}
            <button
              id="btn-player-popout"
              onClick={openCloakedWindow}
              title="Open in about:blank cloaked tab (bypasses frame blockers)"
              className="rounded-xl border border-slate-800 bg-slate-900/80 p-2 text-slate-300 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <ExternalLink className="h-3.5 w-3.5" />
            </button>

            {/* Reload Iframe */}
            <button
              id="btn-player-reload"
              onClick={handleReload}
              title="Reload game frame"
              className="rounded-xl border border-slate-800 bg-slate-900/80 p-2 text-slate-300 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </button>

            {/* Toggle Native Fullscreen */}
            <button
              id="btn-player-fullscreen-toggle"
              onClick={toggleNativeFullscreen}
              title={isFullscreen ? 'Exit display fullscreen' : 'Enter display fullscreen'}
              className="rounded-xl border border-slate-800 bg-slate-900/80 p-2 text-slate-300 hover:border-cyan-500/40 hover:bg-slate-800 hover:text-white transition-colors"
            >
              {isFullscreen ? <Minimize className="h-3.5 w-3.5" /> : <Maximize className="h-3.5 w-3.5" />}
            </button>

            {/* Close Game Button */}
            <button
              id="btn-player-close"
              onClick={handleExit}
              title="Close game (Esc)"
              className="rounded-xl border border-red-500/30 bg-red-950/40 p-2 text-red-300 hover:border-red-400 hover:bg-red-900/60 hover:text-white transition-colors"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Floating Auto Clicker Drawer / Control Panel */}
      {isAutoClickerOpen && (
        <div
          id="autoclicker-control-deck"
          className="absolute top-16 right-4 sm:right-6 z-50 w-80 sm:w-96 rounded-2xl border border-cyan-500/30 bg-slate-950/95 p-4 sm:p-5 shadow-2xl shadow-black/80 backdrop-blur-xl animate-in fade-in slide-in-from-top-4 duration-200"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-400">
                <Zap className="h-4 w-4 fill-amber-400" />
              </div>
              <div>
                <h3 className="font-['Iceberg',cursive,sans-serif] text-sm tracking-wider text-slate-100 flex items-center gap-1.5">
                  AUTO CLICKER
                  {isCookieClicker && (
                    <span className="text-[10px] text-amber-400 font-mono font-bold bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-500/30">
                      COOKIE MODE
                    </span>
                  )}
                </h3>
                <p className="text-[11px] text-slate-400 font-sans">
                  Fast simulated clicks without frame drops
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsAutoClickerOpen(false)}
              className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Main Action Start / Stop Button */}
          <div className="my-4">
            <button
              id="btn-autoclicker-toggle-active"
              onClick={() => setIsAutoClicking((prev) => !prev)}
              className={`w-full flex items-center justify-center gap-2.5 py-3 px-4 rounded-xl font-bold font-mono text-sm tracking-wider transition-all duration-200 shadow-lg ${
                isAutoClicking
                  ? 'bg-red-500 hover:bg-red-600 text-white shadow-red-900/40 ring-2 ring-red-400/50'
                  : 'bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-extrabold shadow-emerald-900/40'
              }`}
            >
              {isAutoClicking ? (
                <>
                  <Square className="h-4 w-4 fill-white" />
                  <span>STOP AUTO CLICKER</span>
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 fill-slate-950" />
                  <span>START AUTO CLICKER</span>
                </>
              )}
            </button>
            <div className="flex items-center justify-between mt-2 px-1 text-[11px] font-mono text-slate-400">
              <span>Hotkey: Press <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-cyan-300 border border-slate-700">C</kbd> or <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-cyan-300 border border-slate-700">X</kbd></span>
              <span className="text-emerald-400 font-semibold">{totalClicks.toLocaleString()} Clicks Sent</span>
            </div>
          </div>

          {/* Presets Grid */}
          <div className="space-y-2 mb-4">
            <label className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="h-3 w-3 text-cyan-400" />
              <span>Speed Presets</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {/* 2-Core 4GB Chromebook Safe Preset */}
              <button
                type="button"
                onClick={() => setClickIntervalMs(20)}
                className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition-all ${
                  clickIntervalMs === 20
                    ? 'border-emerald-500 bg-emerald-950/40 ring-1 ring-emerald-500/50'
                    : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-1 text-xs font-bold text-emerald-400">
                  <Cpu className="h-3.5 w-3.5" />
                  <span>Chromebook Safe</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  20 ms • 50 CPS (2-Core/4GB)
                </div>
              </button>

              {/* Turbo 10ms */}
              <button
                type="button"
                onClick={() => setClickIntervalMs(10)}
                className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition-all ${
                  clickIntervalMs === 10
                    ? 'border-cyan-500 bg-cyan-950/40 ring-1 ring-cyan-500/50'
                    : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-1 text-xs font-bold text-cyan-300">
                  <Zap className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Turbo Speed</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  10 ms • 100 CPS
                </div>
              </button>

              {/* Extreme 5ms */}
              <button
                type="button"
                onClick={() => setClickIntervalMs(5)}
                className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition-all ${
                  clickIntervalMs === 5
                    ? 'border-amber-500 bg-amber-950/40 ring-1 ring-amber-500/50'
                    : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-1 text-xs font-bold text-amber-300">
                  <Sparkles className="h-3.5 w-3.5 text-amber-400" />
                  <span>Extreme</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  5 ms • 200 CPS
                </div>
              </button>

              {/* Smallest / 1ms */}
              <button
                type="button"
                onClick={() => setClickIntervalMs(1)}
                className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition-all ${
                  clickIntervalMs === 1
                    ? 'border-rose-500 bg-rose-950/40 ring-1 ring-rose-500/50'
                    : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-1 text-xs font-bold text-rose-300">
                  <MousePointer className="h-3.5 w-3.5 text-rose-400" />
                  <span>Smallest (Max)</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  1 ms • 1,000 CPS
                </div>
              </button>
            </div>
          </div>

          {/* Custom Editable Interval Input */}
          <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Custom Interval (ms):</span>
              <span className="font-mono text-cyan-400 font-bold">
                {clickIntervalMs} ms (~{currentCps} clicks/sec)
              </span>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="range"
                min="1"
                max="100"
                step="1"
                value={clickIntervalMs}
                onChange={(e) => setClickIntervalMs(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
              />
              <input
                type="number"
                min="1"
                max="1000"
                value={clickIntervalMs}
                onChange={(e) => setClickIntervalMs(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-16 rounded-lg bg-slate-950 border border-slate-700 px-2 py-1 text-center font-mono text-xs text-cyan-300 focus:border-cyan-400 focus:outline-none"
              />
            </div>
          </div>

          {/* 2-Core Chromebook Stability Badge */}
          <div className="mt-3 flex items-start gap-2 bg-cyan-950/30 border border-cyan-500/20 rounded-xl p-2.5 text-[11px] text-cyan-200/90 leading-tight">
            <Cpu className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong>Chromebook Safe Guard:</strong> 20ms ensures zero tab freezing on dual-core Celeron & 4GB RAM devices while cookie clicking at top efficiency.
            </div>
          </div>
        </div>
      )}

      {/* Floating Quick Auto Clicker Toggle Widget for Cookie Clicker */}
      {isCookieClicker && !isAutoClickerOpen && (
        <div className="absolute bottom-6 right-6 z-50 flex items-center gap-2">
          <button
            id="widget-quick-autoclicker"
            onClick={() => setIsAutoClicking((prev) => !prev)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-mono text-xs font-bold shadow-2xl transition-all ${
              isAutoClicking
                ? 'bg-red-500 text-white shadow-red-500/40 ring-2 ring-red-400/50 animate-pulse'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/30 hover:scale-105'
            }`}
          >
            <Zap className={`h-4 w-4 ${isAutoClicking ? 'fill-white' : 'fill-slate-950'}`} />
            <span>{isAutoClicking ? `AUTO CLICKING (${currentCps} CPS)` : 'AUTO CLICKER'}</span>
          </button>
          <button
            onClick={() => setIsAutoClickerOpen(true)}
            title="Open Auto Clicker Settings"
            className="p-2.5 rounded-2xl border border-slate-700 bg-slate-900/90 text-slate-300 hover:text-white hover:bg-slate-800 shadow-xl"
          >
            <Sliders className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Game Iframe Container (Frostbite v2 Rendering Layer with GPU Compositor Isolation) */}
      <div
        className="relative flex-1 w-full h-full flex items-center justify-center bg-black overflow-hidden"
        style={{ contain: 'strict', transform: 'translateZ(0)' }}
      >
        <div
          className={`relative transition-all duration-150 flex items-center justify-center ${
            aspectRatio === 'fill'
              ? 'w-full h-full'
              : aspectRatio === '16:9'
              ? 'w-full max-w-[177.78vh] aspect-video h-auto max-h-screen'
              : 'w-full max-w-[133.33vh] aspect-[4/3] h-auto max-h-screen'
          }`}
          style={{ contain: 'layout size', transform: 'translateZ(0)' }}
        >
          {game.isHtmlDoc ? (
            <iframe
              key={`doc-${iframeKey}`}
              ref={iframeRef}
              id="active-game-iframe"
              srcDoc={game.iframeSrc}
              title={game.name}
              className="h-full w-full border-0 bg-black"
              loading="eager"
              tabIndex={0}
              onLoad={() => iframeRef.current?.focus()}
              referrerPolicy="no-referrer"
              allow={comprehensivePermissions}
              sandbox={isCompatibilityMode ? undefined : standardSandbox}
              style={{
                width: '100%',
                height: '100%',
                border: 'none',
                transform: 'translateZ(0)',
                willChange: 'transform',
                contain: 'strict',
                backfaceVisibility: 'hidden',
              }}
            />
          ) : (
            <iframe
              key={`src-${iframeKey}`}
              ref={iframeRef}
              id="active-game-iframe"
              src={game.iframeSrc}
              title={game.name}
              className={
                isHfManor
                  ? 'h-full border-0 bg-black shrink-0'
                  : 'h-full w-full border-0 bg-black'
              }
              tabIndex={0}
              onLoad={() => iframeRef.current?.focus()}
              style={
                isHfManor
                  ? {
                      width: '166.67%',
                      minWidth: '166.67%',
                      maxWidth: 'none',
                      height: '100%',
                      border: 'none',
                      transform: 'translateZ(0)',
                      willChange: 'transform',
                      contain: 'strict',
                      backfaceVisibility: 'hidden',
                    }
                  : {
                      width: '100%',
                      height: '100%',
                      border: 'none',
                      transform: 'translateZ(0)',
                      willChange: 'transform',
                      contain: 'strict',
                      backfaceVisibility: 'hidden',
                    }
              }
              loading="eager"
              referrerPolicy="no-referrer"
              allow={comprehensivePermissions}
              sandbox={isCompatibilityMode ? undefined : standardSandbox}
            />
          )}
        </div>
      </div>
    </div>
  );
};
