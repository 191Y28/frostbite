import React, { useState } from 'react';
import { GameItem } from '../types';
import { parseIframeInput, readFileAsDataUrl } from '../utils/iframeParser';
import { Check, Code2, ImagePlus, Sparkles, X } from 'lucide-react';

interface AddGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddGame: (game: GameItem) => void;
}

export const AddGameModal: React.FC<AddGameModalProps> = ({
  isOpen,
  onClose,
  onAddGame,
}) => {
  const [name, setName] = useState('');
  const [rawInput, setRawInput] = useState('');
  const [coverUrl, setCoverUrl] = useState<string | undefined>(undefined);
  const [isDragOver, setIsDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const parsed = parseIframeInput(rawInput);

  const handleRawInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setRawInput(val);
    setError(null);

    // If name is currently empty, check if iframe snippet has a title attribute
    const p = parseIframeInput(val);
    if (!name.trim() && p.title) {
      setName(p.title);
    }
    if (!coverUrl && p.coverUrl) {
      setCoverUrl(p.coverUrl);
    }
  };

  const handleDropCover = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        try {
          const dataUrl = await readFileAsDataUrl(file);
          setCoverUrl(dataUrl);
        } catch (err) {
          console.error('Error reading dropped cover:', err);
        }
      }
    }
  };

  const handleFileCoverInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      if (file.type.startsWith('image/')) {
        try {
          const dataUrl = await readFileAsDataUrl(file);
          setCoverUrl(dataUrl);
        } catch (err) {
          console.error('Error reading file cover:', err);
        }
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) {
      setError('Please provide a game name.');
      return;
    }

    if (!parsed.src) {
      setError('Please enter a valid iframe snippet or game URL.');
      return;
    }

    const newGame: GameItem = {
      id: `game_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: cleanName,
      iframeSrc: parsed.src,
      rawIframeSnippet: rawInput.trim(),
      coverUrl: coverUrl,
      isHtmlDoc: parsed.isHtmlDoc,
      sandboxMode: 'standard',
      createdAt: Date.now(),
    };

    onAddGame(newGame);
    setName('');
    setRawInput('');
    setCoverUrl(undefined);
    setError(null);
    onClose();
  };

  return (
    <div
      id="add-game-modal-backdrop"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div
        id="add-game-modal-dialog"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-2xl border border-cyan-500/30 bg-slate-900/95 p-6 shadow-2xl shadow-cyan-950/50 backdrop-blur-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-400 ring-1 ring-cyan-500/30">
              <Code2 className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-wider text-white">ADD UNBLOCKED GAME</h2>
              <p className="text-xs text-slate-400">Paste your game iframe snippet or link</p>
            </div>
          </div>

          <button
            type="button"
            id="btn-close-modal"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Game Title */}
          <div>
            <label className="block text-xs font-semibold tracking-wider text-slate-300 mb-1.5 uppercase">
              Game Title
            </label>
            <input
              type="text"
              id="input-game-name"
              placeholder="e.g. Slope, Retro Bowl, 1v1.LOL..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-colors"
            />
          </div>

          {/* Iframe or URL */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold tracking-wider text-slate-300 uppercase">
                Iframe Code or URL
              </label>
              {parsed.src && (
                <span className="flex items-center gap-1 text-[11px] font-medium text-cyan-400">
                  <Check className="h-3 w-3" /> Ready
                </span>
              )}
            </div>
            <textarea
              id="input-game-iframe"
              rows={3}
              placeholder='Paste game URL, github.io link, inspect-element HTML, or <iframe> tag...'
              value={rawInput}
              onChange={handleRawInputChange}
              className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-2.5 font-mono text-xs text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-colors"
            />
            {parsed.resolutionNote && (
              <div className="mt-1.5 flex items-center gap-1.5 rounded-lg border border-cyan-500/30 bg-cyan-950/40 px-2.5 py-1 text-[11px] text-cyan-300">
                <Sparkles className="h-3 w-3 shrink-0 text-cyan-400" />
                <span>{parsed.resolutionNote}</span>
              </div>
            )}
            {parsed.src && (
              <p className="mt-1 truncate text-[11px] text-slate-400">
                Source: <span className="text-cyan-300 font-mono">{parsed.src}</span>
              </p>
            )}
          </div>

          {/* Cover Drop Box */}
          <div>
            <label className="block text-xs font-semibold tracking-wider text-slate-300 mb-1.5 uppercase">
              Cover Image <span className="text-slate-500 font-normal lowercase">(optional - can drag & drop later)</span>
            </label>
            <div
              id="modal-cover-dropzone"
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragOver(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setIsDragOver(false);
              }}
              onDrop={handleDropCover}
              className={`relative flex aspect-video w-full cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed transition-all duration-200 overflow-hidden ${
                isDragOver
                  ? 'border-cyan-400 bg-cyan-950/40 ring-2 ring-cyan-400/50'
                  : 'border-slate-800 bg-slate-950/50 hover:border-slate-700'
              }`}
            >
              {coverUrl ? (
                <div className="relative h-full w-full">
                  <img
                    src={coverUrl}
                    alt="Cover preview"
                    className="h-full w-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setCoverUrl(undefined);
                    }}
                    className="absolute top-2 right-2 rounded-lg bg-slate-950/80 p-1 text-slate-300 hover:text-white"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <label
                  htmlFor="modal-file-cover-input"
                  className="flex h-full w-full cursor-pointer flex-col items-center justify-center gap-1.5 p-4 text-center"
                >
                  <ImagePlus className="h-6 w-6 text-slate-400" />
                  <span className="text-xs font-medium text-slate-300">
                    Drag & drop image here or click to browse
                  </span>
                  <span className="text-[11px] text-slate-500">
                    PNG, JPG, WEBP, GIF
                  </span>
                </label>
              )}
              <input
                id="modal-file-cover-input"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileCoverInput}
              />
            </div>
          </div>

          {error && (
            <div className="rounded-lg bg-red-950/50 border border-red-500/30 p-2.5 text-xs text-red-300">
              {error}
            </div>
          )}

          {/* Submit */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 text-xs font-semibold tracking-wide text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="btn-save-game"
              className="flex items-center gap-2 rounded-xl bg-cyan-500 px-5 py-2.5 text-xs font-bold tracking-wider text-slate-950 shadow-lg shadow-cyan-500/30 hover:bg-cyan-400 hover:shadow-cyan-400/50 transition-all duration-200 active:scale-95"
            >
              <Sparkles className="h-4 w-4" />
              <span>ADD TO FROSTBITE</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
