import React, { useEffect, useMemo, useState } from 'react';
import { GameItem, GameSeries } from '../types';
import { GameCard } from './GameCard';
import { Layers, Search, X, Sparkles } from 'lucide-react';

interface SeriesModalProps {
  isOpen: boolean;
  series: GameSeries | null;
  games: GameItem[];
  onClose: () => void;
  onLaunch: (game: GameItem) => void;
  onUpdateCover?: (gameId: string, coverDataUrl: string) => void;
  onDeleteGame?: (gameId: string) => void;
}

export const SeriesModal: React.FC<SeriesModalProps> = ({
  isOpen,
  series,
  games,
  onClose,
  onLaunch,
  onUpdateCover,
  onDeleteGame,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Reset search on series change or close
  useEffect(() => {
    setSearchQuery('');
  }, [series?.id, isOpen]);

  // ESC to close
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Filter games belonging to this series
  const seriesGames = useMemo(() => {
    if (!series) return [];
    return games.filter(series.filter);
  }, [series, games]);

  // Apply in-modal search
  const filteredGames = useMemo(() => {
    if (!searchQuery.trim()) return seriesGames;
    const q = searchQuery.toLowerCase().trim();
    return seriesGames.filter((g) => g.name.toLowerCase().includes(q));
  }, [seriesGames, searchQuery]);

  if (!isOpen || !series) return null;

  return (
    <div
      id="series-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="series-modal-container"
        className="relative flex flex-col w-full max-w-6xl max-h-[92vh] rounded-3xl border border-slate-800 bg-[#030712] shadow-2xl shadow-cyan-950/40 overflow-hidden"
      >
        {/* Modal Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800/90 bg-slate-900/90 px-6 py-4">
          {/* Title & Count Badge */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Layers className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="font-['Iceberg',cursive,sans-serif] text-xl font-bold tracking-wide text-white">
                  {series.name}
                </h2>
                <span className="rounded-full bg-cyan-950/80 border border-cyan-500/40 px-2.5 py-0.5 text-xs font-mono font-bold text-cyan-300">
                  {seriesGames.length} {seriesGames.length === 1 ? 'Game' : 'Games'}
                </span>
              </div>
              {series.description && (
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  {series.description}
                </p>
              )}
            </div>
          </div>

          {/* Search Bar & Close */}
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder={`Search in ${series.name}...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
                className="w-full rounded-xl border border-slate-800 bg-slate-950/80 pl-9 pr-8 py-2 text-xs text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            <button
              onClick={onClose}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-800 bg-slate-900 text-slate-400 hover:border-slate-700 hover:bg-slate-800 hover:text-white transition-colors"
              title="Close Series"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Modal Body / Games Grid */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {filteredGames.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-[300px] text-center p-8 space-y-3">
              <Sparkles className="h-8 w-8 text-cyan-500/40" />
              <p className="text-sm font-medium text-slate-400">
                No titles in <span className="text-cyan-400">{series.name}</span> match "
                <span className="text-slate-200">{searchQuery}</span>"
              </p>
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-cyan-400 hover:underline"
              >
                Clear filter
              </button>
            </div>
          ) : (
            <div
              id="series-games-grid"
              className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
            >
              {filteredGames.map((game) => (
                <GameCard
                  key={game.id}
                  game={game}
                  onLaunch={(g) => {
                    onClose();
                    onLaunch(g);
                  }}
                  onUpdateCover={onUpdateCover}
                  onDelete={onDeleteGame}
                />
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-slate-800/80 bg-slate-900/60 px-6 py-3 text-xs text-slate-400 font-mono">
          <span>Click any card to play in fullscreen</span>
          <span>{filteredGames.length} of {seriesGames.length} shown</span>
        </div>
      </div>
    </div>
  );
};
