import React from 'react';
import { motion } from 'motion/react';
import { Gamepad2, Play, Sparkles } from 'lucide-react';

interface HomeViewProps {
  onSelectGames: () => void;
  onSelectYouTube: () => void;
  onSelectAI: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectGames,
  onSelectYouTube,
  onSelectAI,
}) => {
  return (
    <div
      id="frostbite-home-container"
      className="relative flex min-h-screen w-full flex-col items-center justify-center overflow-hidden bg-[#030712] px-6"
    >
      {/* Refined Subtle Chill Glow (Toned down to complement the ice logo) */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-cyan-950/20 blur-[100px] pointer-events-none" />
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[320px] h-[120px] rounded-full bg-sky-900/15 blur-[80px] pointer-events-none" />
      </div>

      {/* Main Container */}
      <div className="relative z-10 flex flex-col items-center justify-center max-w-4xl w-full">
        {/* Frostbite Logo */}
        <motion.div
          initial={{ opacity: 0, y: -12, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="relative mb-12 flex flex-col items-center"
        >
          <div className="relative group cursor-default">
            {/* Subtle icy rim light */}
            <div className="absolute -inset-1 rounded-2xl bg-cyan-500/10 blur-md opacity-40 group-hover:opacity-60 transition-opacity" />
            <img
              id="frostbite-home-logo"
              src="/frostbite-logo.png"
              onError={(e) => {
                const target = e.currentTarget;
                if (!target.src.includes('cooltext515221975249661.png')) {
                  target.src = '/cooltext515221975249661.png';
                }
              }}
              alt="Frostbite"
              className="relative max-h-24 sm:max-h-28 md:max-h-32 w-auto object-contain drop-shadow-[0_4px_16px_rgba(6,182,212,0.25)] select-none pointer-events-none"
            />
          </div>
        </motion.div>

        {/* Center Action Buttons (GAMES, YOUTUBE, AI) */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-5 w-full max-w-3xl"
        >
          {/* GAMES Button */}
          <motion.button
            id="btn-nav-games"
            onClick={onSelectGames}
            whileHover={{ scale: 1.03, y: -2 }}
            whileTap={{ scale: 0.97 }}
            className="group relative flex w-full items-center justify-center gap-4 overflow-hidden rounded-2xl border border-cyan-500/25 bg-slate-900/75 px-5 py-5 sm:py-6 shadow-xl shadow-cyan-950/30 backdrop-blur-xl transition-all duration-300 hover:border-cyan-400/80 hover:bg-slate-900/90 hover:shadow-cyan-500/20"
          >
            {/* Frost Sheen Line */}
            <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-cyan-400/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-400 ring-1 ring-cyan-500/30 transition-all duration-300 group-hover:scale-110 group-hover:bg-cyan-500/20 group-hover:text-cyan-300 group-hover:ring-cyan-400/50">
              <Gamepad2 className="h-6 w-6 transition-transform duration-300 group-hover:rotate-6" />
            </div>

            <div className="flex flex-col text-left">
              <span className="font-['Iceberg',cursive,sans-serif] tracking-[0.15em] text-xl font-bold text-slate-100 transition-colors duration-200 group-hover:text-white">
                GAMES
              </span>
              <span className="text-[10px] tracking-widest text-slate-400 group-hover:text-cyan-300/80 font-mono">
                UNBLOCKED
              </span>
            </div>
          </motion.button>

          {/* YOUTUBE Button */}
          <motion.button
            id="btn-nav-youtube"
            onClick={onSelectYouTube}
            whileHover={{ scale: 1.03, y: -2 }}
            whileTap={{ scale: 0.97 }}
            className="group relative flex w-full items-center justify-center gap-4 overflow-hidden rounded-2xl border border-red-500/20 bg-slate-900/75 px-5 py-5 sm:py-6 shadow-xl shadow-red-950/25 backdrop-blur-xl transition-all duration-300 hover:border-red-400/70 hover:bg-slate-900/90 hover:shadow-red-500/20"
          >
            {/* Frost Sheen Line */}
            <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-red-400/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />

            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-500/10 text-red-400 ring-1 ring-red-500/30 transition-all duration-300 group-hover:scale-110 group-hover:bg-red-500/20 group-hover:text-red-300 group-hover:ring-red-400/50">
              <Play className="h-5 w-5 fill-current ml-0.5 transition-transform duration-300 group-hover:scale-110" />
            </div>

            <div className="flex flex-col text-left">
              <span className="font-['Iceberg',cursive,sans-serif] tracking-[0.15em] text-xl font-bold text-slate-100 transition-colors duration-200 group-hover:text-white">
                YOUTUBE
              </span>
              <span className="text-[10px] tracking-widest text-slate-400 group-hover:text-red-300/80 font-mono">
                PLAYER
              </span>
            </div>
          </motion.button>

          {/* AI Button */}
          <motion.button
            id="btn-nav-ai"
            onClick={onSelectAI}
            whileHover={{ scale: 1.03, y: -2 }}
            whileTap={{ scale: 0.97 }}
            className="group relative flex w-full items-center justify-center gap-4 overflow-hidden rounded-2xl border border-emerald-500/25 bg-slate-900/75 px-5 py-5 sm:py-6 shadow-xl shadow-emerald-950/30 backdrop-blur-xl transition-all duration-300 hover:border-emerald-400/80 hover:bg-slate-900/90 hover:shadow-emerald-500/20"
          >
            {/* Frost Sheen Line */}
            <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-emerald-400/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />

            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/30 transition-all duration-300 group-hover:scale-110 group-hover:bg-emerald-500/20 group-hover:text-emerald-300 group-hover:ring-emerald-400/50">
              <Sparkles className="h-5 w-5 transition-transform duration-300 group-hover:rotate-12" />
            </div>

            <div className="flex flex-col text-left">
              <span className="font-['Iceberg',cursive,sans-serif] tracking-[0.15em] text-xl font-bold text-slate-100 transition-colors duration-200 group-hover:text-white">
                AI
              </span>
              <span className="text-[10px] tracking-widest text-slate-400 group-hover:text-emerald-300/80 font-mono">
                ASSISTANT
              </span>
            </div>
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
};

