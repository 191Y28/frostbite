import React, { useEffect, useMemo, useState, useCallback } from 'react';
import { GameItem, GameSeries } from '../types';
import { GameCard } from './GameCard';
import { GAME_SERIES_LIST } from '../data/seriesData';
import { SeriesCard } from './SeriesCard';
import { SeriesModal } from './SeriesModal';
import { AddGameModal } from './AddGameModal';
import { FullscreenGameModal } from './FullscreenGameModal';
import { GameTabBar } from './GameTabBar';
import { ArrowLeft, Search, X, Sparkles, Gamepad2, Layers, ChevronRight, Flame } from 'lucide-react';
import { preloadImagesBatch } from '../utils/imagePreloader';

// 5 series collapsed into series cards within the main library to eliminate clutter
const COLLAPSED_SERIES_IDS = [
  'subway-surfers-series',
  'fireboy-watergirl-series',
  'motox3m-series',
  'temple-run-series',
  'papas-series',
] as const;

type LibraryEntry =
  | { type: 'game'; id: string; name: string; game: GameItem }
  | { type: 'series'; id: string; name: string; series: GameSeries; count: number };

interface GamesViewProps {
  games: GameItem[];
  onBackToHome: () => void;
  onAddGame: (game: GameItem) => void;
  onUpdateCover: (gameId: string, coverDataUrl: string) => void;
  onDeleteGame: (gameId: string) => void;
  externalAddOpen?: boolean;
  onResetExternalAdd?: () => void;
  externalLaunchGame?: GameItem | null;
  onResetExternalLaunch?: () => void;
}

export const GamesView: React.FC<GamesViewProps> = ({
  games,
  onBackToHome,
  onAddGame,
  onUpdateCover,
  onDeleteGame,
  externalAddOpen,
  onResetExternalAdd,
  externalLaunchGame,
  onResetExternalLaunch,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [openTabs, setOpenTabs] = useState<GameItem[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);
  const [selectedSeries, setSelectedSeries] = useState<GameSeries | null>(null);

  const activeGame = useMemo(
    () => openTabs.find((g) => g.id === activeTabId) || null,
    [openTabs, activeTabId]
  );

  useEffect(() => {
    if (externalAddOpen) {
      setIsAddModalOpen(true);
      onResetExternalAdd?.();
    }
  }, [externalAddOpen, onResetExternalAdd]);

  // Preload game covers in background ONLY when library is being browsed, never while playing
  useEffect(() => {
    if (activeGame) return;
    const covers = games.map((g) => g.coverUrl);
    const seriesCovers = GAME_SERIES_LIST.map((s) => s.coverUrl);
    preloadImagesBatch([...covers, ...seriesCovers], 6);
  }, [games, activeGame]);

  // Calculate live game count for each series
  const seriesCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const s of GAME_SERIES_LIST) {
      counts[s.id] = games.filter(s.filter).length;
    }
    return counts;
  }, [games]);

  // Total unique games across all defined series
  const totalSeriesGamesCount = useMemo(() => {
    const uniqueSeriesGameIds = new Set<string>();
    for (const s of GAME_SERIES_LIST) {
      for (const g of games) {
        if (s.filter(g)) {
          uniqueSeriesGameIds.add(g.id);
        }
      }
    }
    return uniqueSeriesGameIds.size;
  }, [games]);

  // 5 franchises collapsed into series cards within the main library to eliminate clutter
  const collapsedSeriesList = useMemo(() => {
    return GAME_SERIES_LIST.filter((s) =>
      (COLLAPSED_SERIES_IDS as readonly string[]).includes(s.id)
    );
  }, []);

  // Check if a game belongs to one of the 5 collapsed series
  const isGameInCollapsedSeries = useCallback(
    (game: GameItem) => {
      return collapsedSeriesList.some((s) => s.filter(game));
    },
    [collapsedSeriesList]
  );

  // Alphabetized Library items: individual games (excluding the 5 franchises) + 5 collapsed series cards
  const allLibraryEntries = useMemo<LibraryEntry[]>(() => {
    const entries: LibraryEntry[] = [];

    // Add games that are NOT in the 5 collapsed series
    for (const game of games) {
      if (!isGameInCollapsedSeries(game)) {
        entries.push({
          type: 'game',
          id: game.id,
          name: game.name,
          game,
        });
      }
    }

    // Add the 5 collapsed series cards (if they contain at least 1 game)
    for (const series of collapsedSeriesList) {
      const count = seriesCounts[series.id] || 0;
      if (count > 0) {
        entries.push({
          type: 'series',
          id: series.id,
          name: series.name,
          series,
          count,
        });
      }
    }

    // Alphabetize everything by display name
    return entries.sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
    );
  }, [games, isGameInCollapsedSeries, collapsedSeriesList, seriesCounts]);

  // Filter regular games/series based on search bar query
  const filteredLibraryEntries = useMemo(() => {
    if (!searchQuery.trim()) return allLibraryEntries;
    const q = searchQuery.toLowerCase().trim();
    return allLibraryEntries.filter((entry) => {
      if (entry.type === 'game') {
        return entry.game.name.toLowerCase().includes(q);
      }
      // For series, match series name, description, or any individual game inside this series
      return (
        entry.series.name.toLowerCase().includes(q) ||
        (entry.series.description &&
          entry.series.description.toLowerCase().includes(q)) ||
        games.some((g) => entry.series.filter(g) && g.name.toLowerCase().includes(q))
      );
    });
  }, [allLibraryEntries, searchQuery, games]);

  // Total games represented in the library section (accounting for all games within collapsed series)
  const libraryTotalGamesCount = useMemo(() => {
    if (!searchQuery.trim()) {
      return games.length;
    }
    return filteredLibraryEntries.reduce((acc, entry) => {
      return acc + (entry.type === 'game' ? 1 : entry.count);
    }, 0);
  }, [games.length, searchQuery, filteredLibraryEntries]);

  // Popular Games (Mount Rushmore: Minecraft, Run 3, Melon Playground, Jetpack Joyride)
  const popularGames = useMemo(() => {
    const popularIds = ['minecraft', 'run-3', 'melon-playground', 'jetpack-joyride'];
    const matched = popularIds
      .map((id) => games.find((g) => g.id === id))
      .filter((g): g is GameItem => Boolean(g));

    if (!searchQuery.trim()) return matched;
    const q = searchQuery.toLowerCase().trim();
    return matched.filter((g) => g.name.toLowerCase().includes(q));
  }, [games, searchQuery]);

  // Visible series: always show all series/categories (or filtered by search)
  const visibleSeries = useMemo(() => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return GAME_SERIES_LIST.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          games.some((g) => s.filter(g) && g.name.toLowerCase().includes(q))
      );
    }
    return GAME_SERIES_LIST;
  }, [searchQuery, games]);

  // Launch a game into tabs & player
  const handleLaunchGame = useCallback((game: GameItem) => {
    setSelectedSeries(null);
    setOpenTabs((prev) => {
      if (prev.some((g) => g.id === game.id)) return prev;
      return [...prev, game];
    });
    setActiveTabId(game.id);
  }, []);

  // Handle external launch from Game Directory Modal
  useEffect(() => {
    if (externalLaunchGame) {
      handleLaunchGame(externalLaunchGame);
      onResetExternalLaunch?.();
    }
  }, [externalLaunchGame, handleLaunchGame, onResetExternalLaunch]);

  const handleCloseTab = useCallback((gameId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setOpenTabs((prev) => {
      const next = prev.filter((g) => g.id !== gameId);
      if (activeTabId === gameId) {
        if (next.length > 0) {
          setActiveTabId(next[next.length - 1].id);
        } else {
          setActiveTabId(null);
        }
      }
      return next;
    });
  }, [activeTabId]);

  const handleSelectTab = useCallback((tabId: string | null) => {
    setActiveTabId(tabId);
  }, []);

  const handleOpenLibrary = useCallback(() => {
    setActiveTabId(null);
  }, []);

  const handleSelectSeries = useCallback((series: GameSeries) => {
    setSelectedSeries(series);
  }, []);

  const handleCloseSeries = useCallback(() => {
    setSelectedSeries(null);
  }, []);

  const hasAnyResults =
    filteredLibraryEntries.length > 0 ||
    popularGames.length > 0 ||
    visibleSeries.length > 0;

  return (
    <div
      id="frostbite-games-view"
      className="relative min-h-screen w-full bg-[#030712] text-slate-100 flex flex-col"
    >
      {/* 1. TABS BAR WHEN BROWSING LIBRARY */}
      {activeGame === null && openTabs.length > 0 && (
        <GameTabBar
          openTabs={openTabs}
          activeTabId={activeTabId}
          onSelectTab={handleSelectTab}
          onCloseTab={handleCloseTab}
          onOpenLibrary={handleOpenLibrary}
        />
      )}

      {/* 2. FULLSCREEN ACTIVE GAME WITH INTEGRATED TABS */}
      {activeGame && (
        <FullscreenGameModal
          key={activeGame.id}
          game={activeGame}
          onClose={() => handleCloseTab(activeGame.id)}
          tabsBar={
            <GameTabBar
              openTabs={openTabs}
              activeTabId={activeTabId}
              onSelectTab={handleSelectTab}
              onCloseTab={handleCloseTab}
              onOpenLibrary={handleOpenLibrary}
            />
          }
        />
      )}

      {/* 3. LIBRARY VIEW (Hidden when game is playing to freeze library CPU/GPU usage) */}
      <div
        className="flex flex-col flex-1 w-full px-4 py-6 sm:px-8 lg:px-12"
        style={{ display: activeGame ? 'none' : 'flex' }}
      >
        {/* Top Navigation & Search Header */}
        <header className="sticky top-0 z-30 mb-8 -mx-4 -mt-2 px-4 py-4 sm:-mx-8 sm:px-8 lg:-mx-12 lg:px-12 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
          {/* Left: Back & Branding */}
          <div className="flex items-center gap-4">
            <button
              id="btn-back-home"
              onClick={onBackToHome}
              className="group flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/80 px-3.5 py-2 text-xs font-semibold tracking-wider text-slate-300 shadow-sm transition-all duration-200 hover:border-cyan-500/50 hover:bg-slate-800 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
              <span>HOME</span>
            </button>

            <div className="flex items-center gap-2.5">
              <span className="font-['Iceberg',cursive,sans-serif] tracking-[0.15em] text-xl font-bold bg-gradient-to-r from-cyan-300 via-white to-slate-300 bg-clip-text text-transparent">
                GAMES
              </span>
              <span className="rounded-full bg-slate-800/80 border border-slate-700/60 px-2 py-0.5 text-[11px] font-mono text-cyan-400">
                {games.length}
              </span>
            </div>
          </div>

          {/* Right: Search Bar */}
          <div className="flex items-center">
            <div className="relative w-56 sm:w-72 md:w-80">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                id="search-games-input"
                placeholder="Search games or series..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border border-slate-800/80 bg-slate-900/90 pl-10 pr-9 py-2 text-xs text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area: Scaled to 90% size to see more content without changing 4-column layout */}
      <main
        className="mx-auto flex-1 w-full max-w-7xl space-y-8"
        style={{ zoom: 0.9 }}
      >
        {!hasAnyResults ? (
          /* No search results */
          <div className="flex flex-col items-center justify-center min-h-[40vh] text-center p-8">
            <p className="text-sm font-medium text-slate-400">
              No games or series found matching "<span className="text-cyan-400">{searchQuery}</span>"
            </p>
            <button
              onClick={() => setSearchQuery('')}
              className="mt-3 text-xs text-cyan-400 hover:underline"
            >
              Clear search filter
            </button>
          </div>
        ) : (
          <>
            {/* 1. GAME SERIES SECTION (Positioned Above the Games Section) */}
            {visibleSeries.length > 0 && (
              <section id="section-game-series" className="space-y-4">
                <div className="flex items-center justify-between border-b border-cyan-500/20 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                      <Layers className="h-4 w-4" />
                    </div>
                    <div>
                      <h2 className="font-['Iceberg',cursive,sans-serif] text-lg font-bold tracking-wider text-cyan-200">
                        GAME SERIES
                      </h2>
                      <p className="text-[11px] text-cyan-400/70 font-mono">
                        Franchises & themed multi-game collections
                      </p>
                    </div>
                  </div>

                  {/* Right Header Controls: Clean aligned game count */}
                  <div className="flex items-center">
                    <span
                      id="series-total-count-badge"
                      className="rounded-full bg-cyan-950/80 border border-cyan-500/40 px-3 py-1 text-xs font-mono font-bold text-cyan-300 shadow-sm"
                    >
                      {totalSeriesGamesCount} Games Across Series
                    </span>
                  </div>
                </div>

                {/* Series Grid */}
                <div
                  id="series-grid"
                  className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
                >
                  {visibleSeries.map((series) => (
                    <SeriesCard
                      key={series.id}
                      series={series}
                      gamesCount={seriesCounts[series.id] || 0}
                      onSelect={handleSelectSeries}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* 2. POPULAR GAMES SECTION (Mount Rushmore of Unblocked Classics) */}
            {popularGames.length > 0 && (
              <section id="section-popular-games" className="space-y-4">
                <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
                      <Flame className="h-4 w-4" />
                    </div>
                    <div>
                      <h2 className="font-['Iceberg',cursive,sans-serif] text-lg font-bold tracking-wider text-amber-200">
                        POPULAR GAMES
                      </h2>
                      <p className="text-[11px] text-amber-400/70 font-mono">
                        The Mount Rushmore of unblocked classics
                      </p>
                    </div>
                  </div>
                  <span className="rounded-full bg-amber-950/70 border border-amber-500/40 px-2.5 py-0.5 text-xs font-mono font-bold text-amber-300">
                    {popularGames.length}
                  </span>
                </div>

                <div
                  id="popular-games-grid"
                  className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
                >
                  {popularGames.map((game, index) => (
                    <GameCard
                      key={`popular-${game.id}`}
                      game={game}
                      priority={index < 4}
                      onLaunch={handleLaunchGame}
                      onUpdateCover={onUpdateCover}
                      onDelete={onDeleteGame}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* 3. ALL GAMES (LIBRARY SECTION) */}
            {filteredLibraryEntries.length > 0 && (
              <section id="section-all-games" className="space-y-4 pt-2">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                      <Gamepad2 className="h-4 w-4" />
                    </div>
                    <div>
                      <h2 className="font-['Iceberg',cursive,sans-serif] text-lg font-bold tracking-wider text-slate-100">
                        ALL GAMES
                      </h2>
                      <p className="text-[11px] text-slate-400 font-mono">
                        Alphabetical unblocked library
                      </p>
                    </div>
                  </div>
                  <span className="rounded-full bg-slate-900 border border-slate-700/60 px-2.5 py-0.5 text-xs font-mono text-cyan-400">
                    {libraryTotalGamesCount}
                  </span>
                </div>

                <div
                  id="games-grid"
                  className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
                >
                  {filteredLibraryEntries.map((entry, index) => {
                    if (entry.type === 'series') {
                      return (
                        <SeriesCard
                          key={`library-series-${entry.series.id}`}
                          idPrefix="library-series-card"
                          series={entry.series}
                          gamesCount={entry.count}
                          onSelect={handleSelectSeries}
                        />
                      );
                    }
                    return (
                      <GameCard
                        key={entry.game.id}
                        game={entry.game}
                        priority={index < 8}
                        onLaunch={handleLaunchGame}
                        onUpdateCover={onUpdateCover}
                        onDelete={onDeleteGame}
                      />
                    );
                  })}
                </div>
              </section>
            )}
          </>
        )}
      </main>
      </div>

      {/* Add Game Modal (Triggered by Ctrl+Alt+J) */}
      <AddGameModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddGame={onAddGame}
      />

      {/* Series Popup Browser Modal */}
      <SeriesModal
        isOpen={selectedSeries !== null}
        series={selectedSeries}
        games={games}
        onClose={handleCloseSeries}
        onLaunch={handleLaunchGame}
        onUpdateCover={onUpdateCover}
        onDeleteGame={onDeleteGame}
      />
    </div>
  );
};
