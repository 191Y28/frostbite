import React, { useState, useEffect, useCallback } from 'react';
import {
  ArrowLeft,
  Check,
  Copy,
  ExternalLink,
  Globe,
  Play,
  RefreshCw,
  Search,
  ShieldCheck,
  Video,
  X,
  Zap,
  Flame,
  Shield,
  Layers,
  Sparkles,
  Tv,
} from 'lucide-react';
import { YouTubeEmbedEngine, YouTubeVideoItem } from '../types';

interface YouTubeViewProps {
  onBackToHome: () => void;
}

// User-provided API key preconfigured for all users
const PERMANENT_API_KEY = 'AIzaSyCmmqnSbAAyto7FQkcGhOcZ0_kgcyxfZEw';

function decodeHtmlEntities(str: string): string {
  const txt = document.createElement('textarea');
  txt.innerHTML = str;
  return txt.value;
}

function extractYouTubeVideoId(input: string): string | null {
  const trimmed = input.trim();
  if (!trimmed) return null;

  // Direct 11-char ID
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }

  // URLs: youtu.be, youtube.com/watch?v=, youtube.com/embed/, youtube.com/shorts/
  const match = trimmed.match(
    /(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([a-zA-Z0-9_-]{11})/i
  );
  if (match && match[1]) {
    return match[1];
  }

  return null;
}

export const YouTubeView: React.FC<YouTubeViewProps> = ({ onBackToHome }) => {
  const [searchInput, setSearchInput] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('ufc_fights');
  const [activeVideo, setActiveVideo] = useState<{
    id: string;
    title?: string;
    channel?: string;
  } | null>(null);

  // Default to 'invidious' (Yewtu.be) so MCPS / school network filters don't trigger "Video Restricted"
  const [engine, setEngine] = useState<YouTubeEmbedEngine>('invidious');
  const [searchResults, setSearchResults] = useState<YouTubeVideoItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // UFC & Combat Sports Curated Categories
  const categories = [
    { id: 'ufc_fights', label: '🥊 UFC Full Fights', query: 'UFC full fights' },
    { id: 'ufc_highlights', label: '💥 UFC Highlights', query: 'UFC highlights' },
    { id: 'boxing_fights', label: '🥊 Boxing Fights', query: 'Boxing full fights' },
    { id: 'gaming', label: '🎮 Gaming Highlights', query: 'Gaming highlights montage' },
    { id: 'music', label: '🎵 Music & Lo-Fi', query: 'Lofi hip hop beats chill' },
  ];

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const copyVideoUrl = (videoId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    navigator.clipboard.writeText(url);
    setCopiedId(videoId);
    showToast(`Copied YouTube URL to clipboard!`);
    setTimeout(() => {
      setCopiedId((prev) => (prev === videoId ? null : prev));
    }, 2000);
  };

  // Perform search (YouTube Data API v3 with automatic safeSearch=none and fallback mirrors)
  const executeSearch = useCallback(async (query: string, categoryId?: string) => {
    const q = query.trim();
    if (!q) return;

    if (categoryId) {
      setActiveCategory(categoryId);
    } else {
      setActiveCategory('');
    }

    // First check: did user paste a direct YouTube video URL or ID?
    const directId = extractYouTubeVideoId(q);
    if (directId) {
      setActiveVideo({
        id: directId,
        title: 'Direct Video Stream',
        channel: 'YouTube Video',
      });
      return;
    }

    setIsSearching(true);
    setSearchError(null);

    // Primary: Query YouTube Data API v3 with safeSearch=none so school/MCPS filters do not hide results
    try {
      const res = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=27&type=video&safeSearch=none&q=${encodeURIComponent(
          q
        )}&key=${PERMANENT_API_KEY}`
      );

      if (res.ok) {
        const data = await res.json();
        const items: YouTubeVideoItem[] = (data.items || [])
          .filter((item: any) => item.id?.videoId)
          .map((item: any) => ({
            id: item.id.videoId,
            title: decodeHtmlEntities(item.snippet.title),
            channelTitle: decodeHtmlEntities(item.snippet.channelTitle),
            thumbnailUrl:
              item.snippet.thumbnails?.high?.url ||
              item.snippet.thumbnails?.medium?.url ||
              item.snippet.thumbnails?.default?.url ||
              `https://img.youtube.com/vi/${item.id.videoId}/hqdefault.jpg`,
            description: item.snippet.description,
            publishedAt: new Date(item.snippet.publishedAt).toLocaleDateString(),
          }));

        if (items.length > 0) {
          setSearchResults(items);
          setIsSearching(false);
          return;
        }
      }
    } catch (err) {
      console.warn('YouTube Data API query failed, falling back to public mirrors:', err);
    }

    // Secondary fallback mirrors if Google API limit reached
    const fallbackEndpoints = [
      `https://inv.nadeko.net/api/v1/search?q=${encodeURIComponent(q)}&type=video`,
      `https://yewtu.be/api/v1/search?q=${encodeURIComponent(q)}&type=video`,
    ];

    let foundResults = false;

    for (const endpoint of fallbackEndpoints) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);

        const res = await fetch(endpoint, { signal: controller.signal });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data) && data.length > 0) {
            const items: YouTubeVideoItem[] = data
              .filter((item: any) => item.videoId)
              .slice(0, 27)
              .map((item: any) => ({
                id: item.videoId,
                title: decodeHtmlEntities(item.title || 'YouTube Video'),
                channelTitle: decodeHtmlEntities(item.author || item.channelTitle || 'YouTube Creator'),
                thumbnailUrl:
                  item.videoThumbnails?.[0]?.url ||
                  `https://img.youtube.com/vi/${item.videoId}/hqdefault.jpg`,
                description: item.description,
                publishedAt: item.publishedText || 'Recent',
              }));

            setSearchResults(items);
            foundResults = true;
            setSearchError(null);
            break;
          }
        }
      } catch {
        // Try next
      }
    }

    if (!foundResults) {
      setSearchError('Could not fetch results. Check your network or paste a direct video link.');
    }

    setIsSearching(false);
  }, []);

  // Initial showcase load: the YouTube system immediately acts as the video shower/browser!
  useEffect(() => {
    executeSearch('UFC boxing gaming highlights full fight', 'showcase');
  }, [executeSearch]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeSearch(searchInput);
  };

  // Build the embed URL based on chosen engine (unrestricted privacy nodes bypass MCPS policies)
  const getEmbedSrc = (videoId: string, activeEngine: YouTubeEmbedEngine): string => {
    switch (activeEngine) {
      case 'invidious':
        // yewtu.be completely decouples from Google's restricted mode infrastructure
        return `https://yewtu.be/embed/${videoId}?autoplay=1`;
      case 'piped':
        // Piped video privacy network proxy
        return `https://piped.video/embed/${videoId}?autoplay=1`;
      case 'piped2':
        // Secondary Piped mirror
        return `https://piped.mha.fi/embed/${videoId}?autoplay=1`;
      case 'nocookie':
        // Standard YouTube NoCookie (can still be filtered by MCPS DNS)
        return `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1&iv_load_policy=3&enablejsapi=1`;
      default:
        return `https://yewtu.be/embed/${videoId}?autoplay=1`;
    }
  };

  // Open in cloaked about:blank tab (bypasses Chromebook & MCPS network blocks completely)
  const openCloakedWindow = (videoId: string, title?: string) => {
    const embedSrc = getEmbedSrc(videoId, engine);
    const win = window.open('about:blank', '_blank');
    if (win) {
      win.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>${title || 'Google Drive - Document'}</title>
            <link rel="icon" href="https://ssl.gstatic.com/docs/doclist/images/infinite_drives_24dp.png">
            <style>
              html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #000; }
              iframe { border: 0; width: 100%; height: 100%; }
            </style>
          </head>
          <body>
            <iframe 
              src="${embedSrc}" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
              allowfullscreen
            ></iframe>
          </body>
        </html>
      `);
      win.document.close();
    }
  };

  return (
    <div
      id="frostbite-youtube-view"
      className="relative min-h-screen w-full bg-[#030712] px-4 py-6 sm:px-8 lg:px-12 text-slate-100 flex flex-col"
    >
      {/* Top Header */}
      <header className="sticky top-0 z-30 mb-6 -mx-4 -mt-6 px-4 py-4 sm:-mx-8 sm:px-8 lg:-mx-12 lg:px-12 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
          <button
            id="btn-back-home-yt"
            onClick={onBackToHome}
            className="group flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/80 px-3.5 py-2 text-xs font-semibold tracking-wider text-slate-300 shadow-sm transition-all duration-200 hover:border-red-500/50 hover:bg-slate-800 hover:text-white"
          >
            <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
            <span>HOME</span>
          </button>

          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-red-600/20 text-red-400 ring-1 ring-red-500/30">
              <Play className="h-3.5 w-3.5 fill-current ml-0.5" />
            </div>
            <span className="font-['Iceberg',cursive,sans-serif] tracking-[0.15em] text-xl font-bold bg-gradient-to-r from-red-400 via-white to-slate-300 bg-clip-text text-transparent">
              YOUTUBE SHOWER
            </span>
          </div>

          {/* School Bypass Active Indicator */}
          <div className="hidden sm:flex items-center gap-1.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 px-3 py-1 text-[11px] font-mono text-emerald-300">
            <Shield className="h-3 w-3 text-emerald-400" />
            <span>MCPS Bypass Active</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto flex-1 w-full max-w-6xl flex flex-col">
        {/* Active Embed Player */}
        {activeVideo && (
          <div className="mb-6 w-full rounded-2xl border border-red-500/30 bg-slate-900/80 p-4 sm:p-5 shadow-2xl shadow-red-950/30">
            {/* Player Controls Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3 mb-3">
              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-red-600/20 text-red-400">
                  <Play className="h-3 w-3 fill-current ml-0.5" />
                </div>
                <div className="min-w-0">
                  <h3 className="truncate text-xs font-bold text-slate-100">
                    {activeVideo.title || 'YouTube Player'}
                  </h3>
                  {activeVideo.channel && (
                    <p className="truncate text-[10px] text-slate-400">
                      {activeVideo.channel} &bull; <span className="font-mono text-red-300">{activeVideo.id}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Controls */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Copy URL Button */}
                <button
                  type="button"
                  onClick={() => copyVideoUrl(activeVideo.id)}
                  className="flex items-center gap-1.5 rounded-xl border border-emerald-500/30 bg-emerald-950/60 px-3 py-1 text-xs font-semibold text-emerald-300 hover:bg-emerald-900/80 hover:text-white transition-colors"
                >
                  {copiedId === activeVideo.id ? (
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )}
                  <span>{copiedId === activeVideo.id ? 'COPIED!' : 'COPY URL'}</span>
                </button>

                {/* Engine Switcher */}
                <div className="flex items-center gap-1 rounded-xl border border-slate-800 bg-slate-950/80 p-1 text-xs">
                  <button
                    type="button"
                    onClick={() => setEngine('invidious')}
                    className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-medium transition-colors ${
                      engine === 'invidious'
                        ? 'bg-red-600 text-white font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Yewtu.be Invidious Mirror - Bypasses MCPS Restrictions"
                  >
                    <Globe className="h-3 w-3" />
                    <span>Bypass 1 (Yewtu)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEngine('piped')}
                    className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-medium transition-colors ${
                      engine === 'piped'
                        ? 'bg-red-600 text-white font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Piped Video Mirror"
                  >
                    <Zap className="h-3 w-3" />
                    <span>Bypass 2 (Piped)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEngine('nocookie')}
                    className={`flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium transition-colors ${
                      engine === 'nocookie'
                        ? 'bg-red-600 text-white font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Standard YouTube NoCookie"
                  >
                    <Play className="h-3 w-3" />
                    <span>NoCookie</span>
                  </button>
                </div>

                {/* Cloaked Tab Popout */}
                <button
                  type="button"
                  onClick={() => openCloakedWindow(activeVideo.id, activeVideo.title)}
                  title="Open in cloaked about:blank tab"
                  className="flex items-center gap-1 rounded-xl border border-slate-800 bg-slate-950/80 px-2.5 py-1 text-xs text-slate-300 hover:border-red-500/40 hover:bg-slate-800 hover:text-white transition-colors"
                >
                  <ExternalLink className="h-3 w-3 text-red-400" />
                  <span className="hidden sm:inline">Stealth Tab</span>
                </button>

                {/* Close Player */}
                <button
                  type="button"
                  onClick={() => setActiveVideo(null)}
                  className="rounded-xl border border-slate-800 bg-slate-950/80 p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
                  title="Close Player"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* School Network Bypass Notice Banner */}
            <div className="mb-3 flex items-center justify-between gap-2 rounded-xl border border-emerald-500/20 bg-emerald-950/20 px-3 py-1.5 text-[11px] text-emerald-300 font-mono">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                <span>Unrestricted Stream Engine active. MCPS Google policy & owner-disabled embed blocks bypassed.</span>
              </div>
              <span className="hidden md:inline text-slate-400 text-[10px]">
                If a video ever freezes, switch to Bypass 2 or Stealth Tab.
              </span>
            </div>

            {/* Video Iframe */}
            <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-red-500/20 bg-black shadow-2xl">
              <iframe
                key={`${activeVideo.id}-${engine}`}
                src={getEmbedSrc(activeVideo.id, engine)}
                title={activeVideo.title || 'YouTube Player'}
                className="h-full w-full border-0"
                referrerPolicy="no-referrer"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                allowFullScreen
              />
            </div>
          </div>
        )}

        {/* Clean Search & Highlights Bar */}
        <div className="mb-6 w-full rounded-2xl border border-slate-800/80 bg-slate-900/60 p-4 sm:p-5 shadow-xl">
          <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                id="input-youtube-search"
                placeholder="Search UFC fights, boxing, gaming, or paste YouTube link..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950/80 pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:border-red-400 focus:outline-none focus:ring-1 focus:ring-red-400 transition-colors"
              />
            </div>

            <button
              type="submit"
              id="btn-execute-yt-search"
              disabled={isSearching}
              className="flex items-center justify-center gap-2 rounded-xl bg-red-600 px-5 py-2.5 text-xs font-bold tracking-wider text-white shadow-lg shadow-red-600/30 hover:bg-red-500 hover:shadow-red-500/50 transition-all duration-150 active:scale-95 disabled:opacity-50"
            >
              {isSearching ? (
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Search className="h-3.5 w-3.5" />
              )}
              <span>{isSearching ? 'SEARCHING...' : 'SEARCH'}</span>
            </button>
          </form>

          {/* Curated Categories Bar (Acts as the Shower / Showcase) */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => {
                    setSearchInput(cat.query);
                    executeSearch(cat.query, cat.id);
                  }}
                  className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-all shadow-sm ${
                    isActive
                      ? 'border-red-500 bg-red-600 text-white font-bold shadow-red-600/30'
                      : 'border-slate-800 bg-slate-950/70 text-slate-300 hover:border-red-500/40 hover:bg-red-950/30 hover:text-white'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {searchError && (
            <div className="mt-3 rounded-xl border border-amber-500/30 bg-amber-950/30 p-2.5 text-xs text-amber-300 leading-relaxed">
              {searchError}
            </div>
          )}
        </div>

        {/* Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-slate-900/95 px-4 py-3 text-xs font-semibold text-emerald-300 shadow-2xl backdrop-blur-md">
            <Check className="h-4 w-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Results Grid / Showcase Shower */}
        {searchResults.length > 0 ? (
          <div className="w-full flex-1 flex flex-col">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pb-12">
              {searchResults.map((video) => {
                const isCopied = copiedId === video.id;
                return (
                  <div
                    key={video.id}
                    className="group flex flex-col justify-between overflow-hidden rounded-xl border border-slate-800/80 bg-slate-900/70 p-2.5 shadow-lg transition-transform transition-colors duration-100 hover:-translate-y-1 hover:border-red-500/40 hover:bg-slate-900"
                    style={{ transform: 'translateZ(0)' }}
                  >
                    <div>
                      {/* Thumbnail */}
                      <div
                        onClick={() => {
                          setActiveVideo({
                            id: video.id,
                            title: video.title,
                            channel: video.channelTitle,
                          });
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="relative aspect-video w-full overflow-hidden rounded-lg bg-slate-950 cursor-pointer"
                      >
                        <img
                          src={video.thumbnailUrl}
                          alt={video.title}
                          className="h-full w-full object-cover transition-opacity duration-150 group-hover:brightness-110"
                          loading="lazy"
                          decoding="async"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <div className="flex items-center gap-1.5 rounded-full bg-red-600 px-3 py-1 text-xs font-bold text-white shadow-lg">
                            <Play className="h-3 w-3 fill-current" />
                            <span>PLAY UNBLOCKED</span>
                          </div>
                        </div>
                      </div>

                      {/* Meta */}
                      <div className="mt-2.5">
                        <h4
                          onClick={() => {
                            setActiveVideo({
                              id: video.id,
                              title: video.title,
                              channel: video.channelTitle,
                            });
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className="line-clamp-2 text-xs font-bold text-slate-100 group-hover:text-red-300 transition-colors leading-snug cursor-pointer"
                          title={video.title}
                        >
                          {video.title}
                        </h4>
                        <p className="mt-1 text-[11px] text-slate-400 truncate">
                          {video.channelTitle} {video.publishedAt ? `• ${video.publishedAt}` : ''}
                        </p>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="mt-3 flex items-center gap-2 pt-2 border-t border-slate-800/50">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveVideo({
                            id: video.id,
                            title: video.title,
                            channel: video.channelTitle,
                          });
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="flex-1 flex items-center justify-center gap-1.5 rounded-lg bg-red-600 px-2 py-1.5 text-xs font-bold tracking-wider text-white shadow-md shadow-red-600/20 hover:bg-red-500 hover:shadow-red-500/40 transition-all duration-150 active:scale-95"
                      >
                        <Play className="h-3 w-3 fill-current" />
                        <span>WATCH</span>
                      </button>

                      {/* COPY URL BUTTON */}
                      <button
                        type="button"
                        onClick={(e) => copyVideoUrl(video.id, e)}
                        title="Copy YouTube URL to clipboard without opening"
                        className={`flex items-center gap-1 rounded-lg border px-2 py-1.5 text-xs font-semibold transition-all duration-150 active:scale-95 ${
                          isCopied
                            ? 'border-emerald-500/60 bg-emerald-950 text-emerald-300 font-bold'
                            : 'border-slate-800 bg-slate-950 text-slate-300 hover:border-emerald-500/40 hover:bg-emerald-950/40 hover:text-emerald-300'
                        }`}
                      >
                        {isCopied ? (
                          <Check className="h-3 w-3 text-emerald-400 shrink-0" />
                        ) : (
                          <Copy className="h-3 w-3 shrink-0" />
                        )}
                        <span>{isCopied ? 'COPIED!' : 'COPY URL'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => openCloakedWindow(video.id, video.title)}
                        title="Open in stealth cloaked tab (about:blank)"
                        className="rounded-lg border border-slate-800 bg-slate-950 px-2 py-1.5 text-[11px] font-mono text-slate-300 hover:border-red-500/40 hover:bg-slate-800 hover:text-white transition-colors flex items-center gap-1"
                      >
                        <ExternalLink className="h-3 w-3 text-red-400" />
                        <span>Cloak</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : !isSearching ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-500">
            <Video className="h-10 w-10 text-slate-700 mb-2" />
            <p className="text-xs text-slate-400 max-w-sm">
              Search any video or click a showcase category above to stream without restrictions.
            </p>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-500">
            <RefreshCw className="h-8 w-8 text-red-500 animate-spin mb-2" />
            <p className="text-xs text-slate-400">
              Loading unrestricted stream showcase...
            </p>
          </div>
        )}
      </main>
    </div>
  );
};
