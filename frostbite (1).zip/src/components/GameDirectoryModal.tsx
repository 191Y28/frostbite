import React, { useState, useMemo, useCallback } from 'react';
import { GameItem } from '../types';
import {
  X,
  Search,
  Copy,
  Check,
  Sparkles,
  Gamepad2,
  ListOrdered,
  Layers,
  Flame,
  ExternalLink,
  Bot,
  Play,
} from 'lucide-react';

interface GameDirectoryModalProps {
  games: GameItem[];
  isOpen: boolean;
  onClose: () => void;
  onLaunchGame?: (game: GameItem) => void;
}

// Helper to provide descriptive genre / info for each game to enrich AI prompt export
export function getGameInfo(game: GameItem): { genre: string; desc: string } {
  const nameLower = game.name.toLowerCase();
  const idLower = game.id.toLowerCase();

  if (idLower.includes('melon') || nameLower.includes('melon playground')) {
    return {
      genre: 'Physics Sandbox / Ragdoll Combat',
      desc: 'Physics destruction sandbox with ragdolls, weapons, and tools — ideal for UFC & MMA fight simulations',
    };
  }
  if (idLower.includes('happy-wheels') || nameLower.includes('happy wheels')) {
    return {
      genre: 'Ragdoll Physics / Obstacle Survival',
      desc: 'Legendary physics-based obstacle course survival with ragdoll carnage, vehicular traps, and custom levels',
    };
  }
  if (nameLower.includes('fruit ninja')) {
    return { genre: 'Arcade / Slicing', desc: 'Fast-paced fruit slicing action' };
  }
  if (nameLower.includes('wrestling') || nameLower.includes('wrassling')) {
    return { genre: 'Combat / Physics Wrestling', desc: 'Ragdoll combat and wrestling battles' };
  }
  if (nameLower.includes('boxing')) {
    return { genre: 'Combat / Sports Boxing', desc: 'Punching mechanics and championship knockouts' };
  }
  if (nameLower.includes('street fighter') || nameLower.includes('mortal kombat') || nameLower.includes('streets of rage')) {
    return { genre: 'Retro Fighting / Brawler', desc: 'Iconic arcade martial arts and special moves combat' };
  }
  if (nameLower.includes('super smash')) {
    return { genre: 'Platform Fighter', desc: 'Multiplayer arena brawler with Nintendo roster' };
  }
  if (nameLower.includes('subway surfers')) {
    return { genre: 'Endless Runner', desc: 'Fast 3D track dodging trains and obstacles' };
  }
  if (nameLower.includes('temple run')) {
    return { genre: 'Endless Runner', desc: 'High-speed escape from temple guardians' };
  }
  if (nameLower.includes('moto x3m')) {
    return { genre: 'Physics Stunt Racing', desc: 'Extreme obstacle course motocross with explosive hazards' };
  }
  if (nameLower.includes('papa')) {
    return { genre: 'Time-Management Restaurant', desc: 'High-stakes culinary restaurant simulator' };
  }
  if (nameLower.includes('fireboy') || nameLower.includes('watergirl')) {
    return { genre: 'Co-op Puzzle Platformer', desc: 'Elemental puzzle-solving across ancient temples' };
  }
  if (nameLower.includes('vex')) {
    return { genre: 'Precision Platformer', desc: 'Hardcore stickman parkour with deadly spikes' };
  }
  if (nameLower.includes('minecraft') || idLower.includes('minecraft')) {
    return { genre: 'Voxel Sandbox / Survival', desc: 'Block-building open world exploration and survival' };
  }
  if (idLower.includes('run-3') || nameLower.includes('run 3')) {
    return { genre: 'Sci-Fi Gravity Tunnel Runner', desc: 'Rotating space tunnels and alien gravity physics' };
  }
  if (idLower.includes('cookie-clicker') || nameLower.includes('cookie clicker')) {
    return { genre: 'Incremental / Clicker', desc: 'Legendary infinite cookie baking progression' };
  }
  if (nameLower.includes('1v1.lol') || idLower.includes('1v1')) {
    return { genre: 'Competitive 3D Shooter', desc: 'Third-person building and tactical shooting duels' };
  }
  if (nameLower.includes('time shooter') || idLower.includes('timeshooter')) {
    return { genre: 'Time-Bending Shooter', desc: 'SUPERHOT-inspired action where time moves only when you move' };
  }
  if (nameLower.includes('krunker')) {
    return { genre: 'Fast-Paced FPS', desc: 'High-mobility voxel first-person shooter' };
  }
  if (nameLower.includes('madalin')) {
    return { genre: '3D Stunt Driving', desc: 'Supercar free-drive with giant loops and ramps' };
  }
  if (nameLower.includes('basketball') || nameLower.includes('basketbros')) {
    return { genre: 'Sports Basketball', desc: 'High-flying arcade dunks, steals, and 1v1 hoop duels' };
  }
  if (nameLower.includes('retro bowl')) {
    return { genre: 'Sports Football', desc: 'Pixel-art American football management and playbook action' };
  }
  if (nameLower.includes('smash karts')) {
    return { genre: '3D Kart Battle Royale', desc: 'Weaponized go-kart multiplayer arena destruction' };
  }
  if (nameLower.includes('snow rider')) {
    return { genre: '3D Endless Sledding', desc: 'Winter obstacle avoidance at breakneck speeds' };
  }
  if (nameLower.includes('bitlife')) {
    return { genre: 'Life Simulator', desc: 'Text-based sandbox life choices simulator' };
  }
  if (nameLower.includes('infinite craft')) {
    return { genre: 'Alchemy / Logic Sandbox', desc: 'Combine basic elements to discover infinite creations' };
  }
  if (nameLower.includes('duck life')) {
    return { genre: 'Training RPG / Racing', desc: 'Train duck skills in running, flying, and swimming' };
  }
  if (nameLower.includes('crossy road')) {
    return { genre: 'Endless Arcade Hopper', desc: 'Timed lane crossing across roads, rivers, and rails' };
  }
  if (nameLower.includes('jetpack joyride')) {
    return { genre: 'Action Side-Scroller', desc: 'Bullet-powered jetpack laboratory evasion' };
  }

  // General fallbacks based on words
  if (nameLower.includes('random') || nameLower.includes('physics')) {
    return { genre: 'Physics Ragdoll', desc: 'Wacky ragdoll physics competition' };
  }
  if (nameLower.includes('mario') || nameLower.includes('sonic')) {
    return { genre: 'Retro Platformer', desc: 'Classic side-scrolling platform adventure' };
  }
  if (nameLower.includes('io') || idLower.includes('io')) {
    return { genre: 'Multiplayer Arena (.IO)', desc: 'Fast multiplayer arena survival and territory growth' };
  }
  if (nameLower.includes('sniper') || nameLower.includes('gun')) {
    return { genre: 'Action / Shooting', desc: 'Target acquisition and tactical projectile combat' };
  }

  return { genre: 'Arcade / Action', desc: 'Classic browser-based unblocked gaming experience' };
}

export const GameDirectoryModal: React.FC<GameDirectoryModalProps> = ({
  games,
  isOpen,
  onClose,
  onLaunchGame,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedType, setCopiedType] = useState<'claude' | 'simple' | null>(null);

  // Sort games alphabetically
  const alphabetizedGames = useMemo(() => {
    return [...games].sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
    );
  }, [games]);

  // Filter games based on search query
  const filteredGames = useMemo(() => {
    if (!searchQuery.trim()) return alphabetizedGames;
    const q = searchQuery.toLowerCase().trim();
    return alphabetizedGames.filter((g) => {
      const info = getGameInfo(g);
      return (
        g.name.toLowerCase().includes(q) ||
        info.genre.toLowerCase().includes(q) ||
        info.desc.toLowerCase().includes(q)
      );
    });
  }, [alphabetizedGames, searchQuery]);

  // Copy customized prompt for Claude
  const handleCopyForClaude = useCallback(() => {
    const listFormatted = alphabetizedGames
      .map((g, idx) => {
        const info = getGameInfo(g);
        return `${idx + 1}. ${g.name} [${info.genre}] - ${info.desc}`;
      })
      .join('\n');

    const promptText = `Here is my complete current unblocked games library (${alphabetizedGames.length} games in alphabetical order):

${listFormatted}

---
ABOUT MY GAMING TASTE & PREFERENCES:
- I really enjoy physics sandboxes and ragdoll fight simulators (like Melon Playground on PC and Fruit Playground on my phone, which I love using to simulate realistic and chaotic UFC / MMA fights).
- I also love arcade and retro fighting games (Street Fighter, Mortal Kombat, Rowdy Wrestling, Big Shot Boxing).
- I like high-replayability action, runners, and skill-based physics games (Run 3, Moto X3M, Vex, Minecraft).

REQUEST FOR CLAUDE:
Based on my current library and my specific taste (especially physics sandboxes, fighting games, and UFC/MMA combat simulators):
1. Please recommend 10 to 15 exciting new unblocked web/HTML5 games that would be great additions to my library.
2. For each recommendation, explain why it fits my taste and whether it's available as an unblocked HTML5/WebGL game.
3. Suggest any hidden gems in the ragdoll/physics combat or fighting genre that I might not know about!`;

    navigator.clipboard.writeText(promptText);
    setCopiedType('claude');
    setTimeout(() => setCopiedType(null), 3000);
  }, [alphabetizedGames]);

  // Copy simple numbered list
  const handleCopySimple = useCallback(() => {
    const simpleList = alphabetizedGames
      .map((g, idx) => `${idx + 1}. ${g.name}`)
      .join('\n');

    navigator.clipboard.writeText(
      `Unblocked Games Library (${alphabetizedGames.length} Games):\n\n${simpleList}`
    );
    setCopiedType('simple');
    setTimeout(() => setCopiedType(null), 3000);
  }, [alphabetizedGames]);

  if (!isOpen) return null;

  return (
    <div
      id="game-directory-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 sm:p-6"
      onClick={onClose}
    >
      <div
        id="game-directory-modal"
        onClick={(e) => e.stopPropagation()}
        className="relative flex flex-col w-full max-w-4xl h-[88vh] rounded-2xl border border-cyan-500/30 bg-slate-950 text-slate-100 shadow-2xl shadow-cyan-950/50 overflow-hidden"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 shadow-inner">
              <ListOrdered className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-['Iceberg',cursive,sans-serif] text-xl font-bold tracking-wider text-slate-100">
                  GAME DIRECTORY & AI EXPORT
                </h2>
                <span className="rounded-full bg-cyan-950/80 border border-cyan-500/40 px-2.5 py-0.5 text-xs font-mono font-bold text-cyan-300">
                  {alphabetizedGames.length} Games
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Alphabetical catalog with genre tags & prompt copy for Claude
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            title="Close directory (Esc)"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Action Bar: Copy CTAs & Quick Filter */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 px-6 py-3.5 bg-slate-900/60 border-b border-slate-800/80">
          {/* Search bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              id="directory-search-input"
              placeholder="Filter by title, genre, physics, UFC..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-700/70 bg-slate-900/90 pl-10 pr-9 py-2 text-xs text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Copy Buttons */}
          <div className="flex items-center gap-2">
            <button
              id="btn-copy-simple-list"
              onClick={handleCopySimple}
              className="flex items-center gap-1.5 rounded-xl border border-slate-700/80 bg-slate-800/80 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700 hover:text-white transition-all shadow-sm"
              title="Copy clean numbered list of titles"
            >
              {copiedType === 'simple' ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-300">Titles Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5 text-slate-400" />
                  <span>Copy Names</span>
                </>
              )}
            </button>

            <button
              id="btn-copy-claude-prompt"
              onClick={handleCopyForClaude}
              className="group flex items-center gap-2 rounded-xl border border-cyan-500/50 bg-gradient-to-r from-cyan-600 to-blue-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-cyan-900/40 hover:from-cyan-500 hover:to-blue-500 hover:border-cyan-400 transition-all transform hover:-translate-y-0.5"
              title="Copies complete formatted prompt with your UFC / physics taste pre-filled for Claude"
            >
              {copiedType === 'claude' ? (
                <>
                  <Check className="h-4 w-4 text-emerald-300" />
                  <span className="text-emerald-100">Ready for Claude!</span>
                </>
              ) : (
                <>
                  <Bot className="h-4 w-4 text-cyan-200 group-hover:rotate-12 transition-transform" />
                  <span>Copy Prompt for Claude</span>
                  <Sparkles className="h-3 w-3 text-cyan-200" />
                </>
              )}
            </button>
          </div>
        </div>

        {/* Informative Banner about Preferences */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-gradient-to-r from-cyan-950/40 via-blue-950/30 to-purple-950/20 border-b border-slate-800/60 text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <Flame className="h-3.5 w-3.5 text-amber-400 shrink-0" />
            <span>
              <strong className="text-cyan-300">Taste Profile Included:</strong> Physics sandboxes (Melon & Fruit Playground UFC fights), ragdoll combat, runners & brawlers.
            </span>
          </div>
          <span className="hidden sm:inline font-mono text-[11px] text-slate-400">
            Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-cyan-300">Ctrl+Shift+J</kbd> anytime
          </span>
        </div>

        {/* Scrollable Game Directory List */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-2.5 custom-scrollbar">
          {filteredGames.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center text-slate-400">
              <Gamepad2 className="h-10 w-10 text-slate-600 mb-2" />
              <p className="text-sm font-medium">No games match "{searchQuery}"</p>
            </div>
          ) : (
            filteredGames.map((game, index) => {
              const info = getGameInfo(game);
              const isMelon = game.id === 'melon-playground';

              return (
                <div
                  key={game.id}
                  id={`directory-game-${game.id}`}
                  className={`group flex items-center justify-between gap-4 p-3 rounded-xl border transition-all ${
                    isMelon
                      ? 'border-emerald-500/50 bg-emerald-950/20 hover:bg-emerald-950/30'
                      : 'border-slate-800/80 bg-slate-900/60 hover:border-cyan-500/40 hover:bg-slate-900'
                  }`}
                >
                  {/* Left: Index, Cover, Title & Info */}
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <span className="font-mono text-xs font-semibold text-slate-500 w-7 shrink-0 text-right">
                      {String(index + 1).padStart(3, '0')}
                    </span>

                    {game.coverUrl && (
                      <div className="h-10 w-10 rounded-lg overflow-hidden border border-slate-800 shrink-0 bg-slate-950">
                        <img
                          src={game.coverUrl}
                          alt={game.name}
                          className="h-full w-full object-cover"
                          loading="lazy"
                        />
                      </div>
                    )}

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-100 group-hover:text-cyan-300 transition-colors">
                          {game.name}
                        </span>
                        {isMelon && (
                          <span className="rounded-md bg-emerald-900/80 border border-emerald-500/50 px-2 py-0.5 text-[10px] font-bold text-emerald-300 uppercase tracking-wider">
                            Mount Rushmore • UFC Sandbox
                          </span>
                        )}
                        <span className="rounded-md bg-slate-800/90 border border-slate-700/60 px-2 py-0.5 text-[10px] font-mono text-cyan-400">
                          {info.genre}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 truncate mt-0.5">
                        {info.desc}
                      </p>
                    </div>
                  </div>

                  {/* Right: Quick Launch button */}
                  {onLaunchGame && (
                    <button
                      onClick={() => {
                        onClose();
                        onLaunchGame(game);
                      }}
                      className="shrink-0 flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/80 px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-cyan-400 hover:bg-cyan-500 hover:text-black transition-all"
                    >
                      <Play className="h-3.5 w-3.5 fill-current" />
                      <span className="hidden sm:inline">Play</span>
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer with quick stats */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-900/80 text-xs text-slate-400">
          <span>
            Showing <strong className="text-slate-200">{filteredGames.length}</strong> of {alphabetizedGames.length} total games
          </span>
          <div className="flex items-center gap-3">
            <span className="text-slate-500 hidden sm:inline">
              Prompt includes UFC / Fruit Playground fight simulation context
            </span>
            <button
              onClick={onClose}
              className="rounded-lg border border-slate-700 px-3 py-1 text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
