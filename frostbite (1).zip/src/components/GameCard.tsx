import React, { useState, memo } from 'react';
import { GameItem } from '../types';
import { readFileAsDataUrl } from '../utils/iframeParser';
import { Maximize2 } from 'lucide-react';

interface GameCardProps {
  game: GameItem;
  onLaunch: (game: GameItem) => void;
  onUpdateCover?: (gameId: string, coverDataUrl: string) => void;
  onDelete?: (gameId: string) => void;
  priority?: boolean;
}

export const GameCard: React.FC<GameCardProps> = memo(({
  game,
  onLaunch,
  onUpdateCover,
  priority = false,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isTitleHovered, setIsTitleHovered] = useState(false);
  const [imgError, setImgError] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    if (!onUpdateCover) return;

    // 1. Check if user dropped a local image file
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        try {
          const dataUrl = await readFileAsDataUrl(file);
          onUpdateCover(game.id, dataUrl);
          return;
        } catch (err) {
          console.error('Failed to read image drop:', err);
        }
      }
    }

    // 2. Check if user dragged an image from the web (URL or HTML)
    const uriList = e.dataTransfer.getData('text/uri-list');
    const plainText = e.dataTransfer.getData('text/plain');
    const html = e.dataTransfer.getData('text/html');

    let droppedUrl = uriList || plainText;
    if (!droppedUrl && html) {
      const imgMatch = html.match(/<img\b[^>]*\bsrc=["']([^"']+)["']/i);
      if (imgMatch && imgMatch[1]) {
        droppedUrl = imgMatch[1];
      }
    }

    if (droppedUrl && /^https?:\/\/.+\.(png|jpe?g|webp|gif|svg|avif)(\?.*)?$/i.test(droppedUrl)) {
      onUpdateCover(game.id, droppedUrl);
    } else if (droppedUrl && /^https?:\/\//i.test(droppedUrl)) {
      onUpdateCover(game.id, droppedUrl);
    }
  };

  const scale = game.coverTransform?.scale ?? 1;
  const x = game.coverTransform?.x ?? 0;
  const y = game.coverTransform?.y ?? 0;

  return (
    <div
      id={`game-card-${game.id}`}
      className="group relative flex flex-col rounded-2xl border border-slate-800/90 bg-slate-900/95 p-3 transition-transform transition-colors duration-100 hover:-translate-y-1 hover:border-cyan-500/40 hover:bg-slate-900 game-card-optimized"
      style={{ transform: 'translateZ(0)' }}
    >
      {/* Squircle Cover Container */}
      <div
        id={`cover-box-${game.id}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => onLaunch(game)}
        className={`relative aspect-video w-full cursor-pointer overflow-hidden rounded-xl border transition-colors duration-100 flex items-center justify-center bg-slate-950 ${
          isDragOver
            ? 'border-cyan-400 bg-cyan-950/50 ring-2 ring-cyan-400/50'
            : 'border-slate-800/70 group-hover:border-slate-700'
        }`}
      >
        {game.coverUrl && !imgError ? (
          <img
            src={game.coverUrl}
            alt={game.name}
            loading={priority ? 'eager' : 'lazy'}
            decoding="async"
            // @ts-ignore
            fetchPriority={priority ? 'high' : 'low'}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover transition-opacity duration-150 group-hover:brightness-110"
            style={{
              transform: `scale(${scale}) translate(${x}%, ${y}%)`,
              transformOrigin: 'center center',
            }}
          />
        ) : (
          <div className="flex flex-col items-center justify-center gap-1.5 p-4 text-center">
            <span className="font-['Iceberg',cursive,sans-serif] text-sm tracking-wider text-slate-500 group-hover:text-cyan-400 transition-colors">
              {game.name.substring(0, 3).toUpperCase()}
            </span>
          </div>
        )}

        {/* Hover Launch Overlay (High performance, no backdrop-blur) */}
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/70 opacity-0 transition-opacity duration-100 group-hover:opacity-100 pointer-events-none">
          <div className="flex items-center gap-2 rounded-xl bg-cyan-500 px-3.5 py-1.5 text-xs font-semibold tracking-wide text-slate-950 shadow-md shadow-cyan-500/30">
            <Maximize2 className="h-3.5 w-3.5" />
            <span>PLAY FULLSCREEN</span>
          </div>
        </div>

        {/* Tag Badge (e.g. RETIRED) */}
        {game.tag && (
          <div className="absolute top-2 right-2 z-10">
            <span className="rounded-md border border-rose-500/60 bg-rose-950/90 px-2 py-0.5 text-[10px] font-bold tracking-widest text-rose-300 font-mono">
              {game.tag}
            </span>
          </div>
        )}
      </div>

      {/* Title Area Below the Cover Box */}
      <div className="relative mt-2.5 flex items-center justify-between px-1">
        <div
          className="relative min-w-0 flex-1 flex items-center gap-1.5"
          onMouseEnter={() => setIsTitleHovered(true)}
          onMouseLeave={() => setIsTitleHovered(false)}
        >
          {/* Truncated Name */}
          <div
            onClick={() => onLaunch(game)}
            className="cursor-pointer truncate text-sm font-semibold text-slate-200 transition-colors duration-100 group-hover:text-cyan-300"
          >
            {game.name}
          </div>
          {game.tag && (
            <span className="shrink-0 text-[10px] font-bold text-rose-400 font-mono">
              [{game.tag}]
            </span>
          )}

          {/* Instant Hover Tooltip for Full Name */}
          {isTitleHovered && (
            <div
              id={`tooltip-${game.id}`}
              className="absolute -top-10 left-0 z-40 max-w-xs whitespace-nowrap rounded-lg border border-cyan-500/40 bg-slate-900 px-2.5 py-1 text-xs font-medium text-slate-100 shadow-xl shadow-black/80 pointer-events-none animate-in fade-in zoom-in-95 duration-75"
            >
              <div className="truncate">{game.name}</div>
              {/* Arrow */}
              <div className="absolute -bottom-1 left-4 h-2 w-2 rotate-45 border-b border-r border-cyan-500/40 bg-slate-900" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
});

GameCard.displayName = 'GameCard';
