import React from 'react';
import { GameSeries } from '../types';
import { Layers, ChevronRight } from 'lucide-react';

interface SeriesCardProps {
  series: GameSeries;
  gamesCount: number;
  onSelect: (series: GameSeries) => void;
  idPrefix?: string;
}

export const SeriesCard: React.FC<SeriesCardProps> = React.memo(({
  series,
  gamesCount,
  onSelect,
  idPrefix = 'series-card',
}) => {
  return (
    <div
      id={`${idPrefix}-${series.id}`}
      onClick={() => onSelect(series)}
      className="group relative flex flex-col rounded-2xl border border-slate-800/90 bg-slate-900/95 p-3 transition-all duration-200 hover:-translate-y-1 hover:border-cyan-500/50 hover:bg-slate-900 hover:shadow-xl hover:shadow-cyan-950/40 cursor-pointer game-card-optimized select-none"
    >
      {/* Cover Container */}
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-slate-800/80 bg-black flex items-center justify-center">
        {series.coverUrl && (
          <img
            src={series.coverUrl}
            alt={series.name}
            loading="lazy"
            decoding="async"
            referrerPolicy="no-referrer"
            className={`h-full w-full object-cover transition-transform duration-300 group-hover:scale-105 ${
              series.coverBlurred ? 'blur-[3px] scale-105 brightness-90' : 'brightness-95'
            }`}
          />
        )}

        {/* Ambient Dark Gradient for Legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent pointer-events-none" />

        {/* Top-Right Badge: Live Game Count */}
        <div className="absolute top-2.5 right-2.5 z-10">
          <span className="inline-flex items-center gap-1 rounded-full border border-cyan-500/40 bg-slate-950/85 px-2.5 py-0.5 text-[11px] font-mono font-bold text-cyan-300 shadow-md shadow-black/80">
            <Layers className="h-3 w-3 text-cyan-400" />
            <span>{gamesCount} {gamesCount === 1 ? 'Game' : 'Games'}</span>
          </span>
        </div>

        {/* Bottom Banner Title Overlay inside cover */}
        <div className="absolute bottom-2.5 left-2.5 right-2.5 z-10 flex flex-col">
          <span className="font-['Iceberg',cursive,sans-serif] text-base sm:text-lg font-bold tracking-wide text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)] group-hover:text-cyan-300 transition-colors">
            {series.name}
          </span>
          {series.description && (
            <span className="text-[11px] text-slate-300/90 truncate drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] font-mono">
              {series.description}
            </span>
          )}
        </div>

        {/* Hover Action Overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/60 opacity-0 transition-opacity duration-200 group-hover:opacity-100 z-20">
          <div className="flex items-center gap-1.5 rounded-xl bg-cyan-500 px-3.5 py-1.5 text-xs font-bold tracking-wide text-slate-950 shadow-lg shadow-cyan-500/40 transition-transform duration-200 hover:scale-105 active:scale-95">
            <span>BROWSE SERIES</span>
            <ChevronRight className="h-4 w-4" />
          </div>
        </div>
      </div>

      {/* Footer Sub-Info */}
      <div className="mt-2.5 flex items-center justify-between px-1 text-xs">
        <div className="flex items-center gap-1.5 text-slate-400 font-mono text-[11px]">
          <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse" />
          <span>Click to view full collection</span>
        </div>
        <span className="text-cyan-400 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center text-[11px]">
          OPEN
        </span>
      </div>
    </div>
  );
});

SeriesCard.displayName = 'SeriesCard';
