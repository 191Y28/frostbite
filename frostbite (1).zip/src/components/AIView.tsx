import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import {
  ArrowLeft,
  Bot,
  Send,
  Sparkles,
  Paperclip,
  Image as ImageIcon,
  FileText,
  X,
  Globe,
  Trash2,
  Copy,
  Check,
  RotateCcw,
  ExternalLink,
  ChevronDown,
} from 'lucide-react';
import { ChatMessage, ChatAttachment, SearchSource } from '../types';

interface AIViewProps {
  onBackToHome: () => void;
}

const STORAGE_KEY_AI_MESSAGES = 'frostbite_ai_messages_v1';
const STORAGE_KEY_AI_SEARCH = 'frostbite_ai_search_enabled';

const STARTER_PROMPTS = [
  {
    title: 'Web & Deep Research',
    prompt: 'Search the web for the latest updates and breakthroughs in technology this week, summarizing key takeaways in bold.',
    icon: Globe,
  },
  {
    title: 'Analyze Documents & Images',
    prompt: 'I will attach an image or PDF. Please give me a detailed breakdown and identify the key facts.',
    icon: FileText,
  },
  {
    title: 'Humanized Explanations',
    prompt: 'Explain how neural networks process vision in a chill, easy-to-understand way with bold highlights.',
    icon: Sparkles,
  },
  {
    title: 'Code & Architecture',
    prompt: 'Review best practices for building high-performance web applications with zero input lag.',
    icon: Bot,
  },
];

export const AIView: React.FC<AIViewProps> = ({ onBackToHome }) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_AI_MESSAGES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [];
  });

  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [enableSearch, setEnableSearch] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_AI_SEARCH) === 'true';
    } catch {
      return false;
    }
  });
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Save messages to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_AI_MESSAGES, JSON.stringify(messages));
    } catch (e) {
      console.error(e);
    }
  }, [messages]);

  // Save search setting
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_AI_SEARCH, String(enableSearch));
    } catch {}
  }, [enableSearch]);

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [input]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearHistory = () => {
    if (messages.length === 0) return;
    if (window.confirm('Clear conversation history?')) {
      setMessages([]);
      localStorage.removeItem(STORAGE_KEY_AI_MESSAGES);
    }
  };

  const processFiles = (files: FileList | File[]) => {
    const fileList = Array.from(files);
    for (const file of fileList) {
      if (file.size > 20 * 1024 * 1024) {
        alert(`File ${file.name} is larger than 20MB limit.`);
        continue;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        if (!dataUrl) return;

        const isImg = file.type.startsWith('image/');
        const newAtt: ChatAttachment = {
          id: `att_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          name: file.name,
          type: file.type || 'application/octet-stream',
          size: file.size,
          dataUrl,
          previewUrl: isImg ? dataUrl : undefined,
        };

        setAttachments((prev) => [...prev, newAtt]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processFiles(e.target.files);
      e.target.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files) {
      processFiles(e.dataTransfer.files);
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend !== undefined ? textToSend : input).trim();
    if ((!text && attachments.length === 0) || isLoading) return;

    const userMessage: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      content: text,
      attachments: attachments.length > 0 ? [...attachments] : undefined,
      timestamp: Date.now(),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setAttachments([]);
    setIsLoading(true);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    try {
      // Send chat history and current attachments to /api/ai/chat
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
            attachments: m.attachments,
          })),
          enableSearch,
          model: 'gemini-3.6-flash',
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with ${res.status}`);
      }

      const data = await res.json();

      const assistantMessage: ChatMessage = {
        id: `msg_asst_${Date.now()}`,
        role: 'assistant',
        content: data.reply || 'No response received.',
        sources: data.sources && data.sources.length > 0 ? data.sources : undefined,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: `msg_err_${Date.now()}`,
        role: 'assistant',
        content: `**Error reaching Gemini AI:**\n\n${err?.message || 'Please check your connection or try again.'}`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div
      id="frostbite-ai-view"
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={handleDrop}
      className="relative flex h-screen w-full flex-col bg-[#070b14] text-slate-100 font-['Plus_Jakarta_Sans',sans-serif] overflow-hidden select-text"
    >
      {/* Subtle background glow */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[300px] bg-cyan-950/15 blur-[120px] pointer-events-none" />
      </div>

      {/* Top Header Bar */}
      <header className="relative z-10 flex h-16 w-full shrink-0 items-center justify-between border-b border-slate-800/80 bg-slate-950/80 px-4 sm:px-6 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-ai-back-home"
            onClick={onBackToHome}
            className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/80 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:border-slate-700 hover:bg-slate-800 hover:text-white transition-all active:scale-95"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Home</span>
          </button>

          <div className="h-4 w-px bg-slate-800" />

          {/* Model Status Pill */}
          <div className="flex items-center gap-2 rounded-full border border-cyan-500/25 bg-cyan-950/30 px-3 py-1 text-xs text-cyan-300 shadow-inner">
            <Sparkles className="h-3.5 w-3.5 text-cyan-400 animate-pulse" />
            <span className="font-semibold tracking-wide">Gemini 3.7 Flash</span>
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
          </div>
        </div>

        {/* Right Tools: Web Search toggle & Clear Chat */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="btn-ai-toggle-search"
            onClick={() => setEnableSearch((prev) => !prev)}
            className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-semibold transition-all ${
              enableSearch
                ? 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300 shadow-sm shadow-cyan-950'
                : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
            }`}
            title="Toggle Web Search & Research Grounding"
          >
            <Globe className={`h-3.5 w-3.5 ${enableSearch ? 'text-cyan-400' : 'text-slate-500'}`} />
            <span className="hidden sm:inline">Web Search</span>
            <span className={`text-[10px] uppercase font-mono px-1 py-0.2 rounded ${enableSearch ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-500'}`}>
              {enableSearch ? 'ON' : 'OFF'}
            </span>
          </button>

          {messages.length > 0 && (
            <button
              type="button"
              id="btn-ai-clear-chat"
              onClick={handleClearHistory}
              className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900/60 px-3 py-1.5 text-xs font-medium text-slate-400 hover:border-red-900/50 hover:bg-red-950/20 hover:text-red-300 transition-all"
              title="Clear conversation"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span className="hidden md:inline">Clear</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Conversation Thread */}
      <main className="relative flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-6">
        <div className="mx-auto max-w-3xl space-y-6 pb-4">
          {/* Welcome Screen when Empty */}
          {messages.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col items-center justify-center pt-8 sm:pt-14 text-center"
            >
              <div className="relative mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-cyan-500/30 bg-slate-900/90 shadow-xl shadow-cyan-950/40">
                <Sparkles className="h-8 w-8 text-cyan-400" />
                <div className="absolute -inset-1 rounded-2xl bg-cyan-500/20 blur-md pointer-events-none" />
              </div>

              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-2">
                How can I help you today?
              </h2>
              <p className="max-w-md text-sm text-slate-400 leading-relaxed mb-8">
                Powered by Gemini with real-time web research, multi-image and document analysis, and natural human responses.
              </p>

              {/* Starter Prompt Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl">
                {STARTER_PROMPTS.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSendMessage(item.prompt)}
                      className="group flex flex-col items-start gap-1.5 rounded-2xl border border-slate-800/80 bg-slate-900/60 p-4 text-left transition-all duration-200 hover:border-cyan-500/40 hover:bg-slate-900/90 hover:shadow-lg hover:shadow-cyan-950/20 active:scale-[0.98]"
                    >
                      <div className="flex items-center gap-2 text-cyan-400 group-hover:text-cyan-300">
                        <Icon className="h-4 w-4" />
                        <span className="text-xs font-semibold">{item.title}</span>
                      </div>
                      <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                        {item.prompt}
                      </p>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Render Messages */}
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              {/* Attachment Previews in Message */}
              {msg.attachments && msg.attachments.length > 0 && (
                <div className={`flex flex-wrap gap-2 mb-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.attachments.map((att) => (
                    <div
                      key={att.id}
                      className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/80 p-2 overflow-hidden shadow-sm"
                    >
                      {att.previewUrl ? (
                        <img
                          src={att.previewUrl}
                          alt={att.name}
                          className="h-14 w-14 rounded-lg object-cover border border-slate-700"
                        />
                      ) : (
                        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-slate-800 text-cyan-400">
                          <FileText className="h-6 w-6" />
                        </div>
                      )}
                      <div className="flex flex-col pr-2">
                        <span className="text-xs font-medium text-slate-200 max-w-[140px] truncate">
                          {att.name}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {formatFileSize(att.size)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Message Bubble */}
              <div
                className={`group relative max-w-[92%] sm:max-w-[85%] rounded-2xl px-4 py-3.5 leading-relaxed text-sm shadow-md ${
                  msg.role === 'user'
                    ? 'bg-cyan-600 text-white rounded-tr-sm font-normal'
                    : 'bg-slate-900/90 border border-slate-800/90 text-slate-200 rounded-tl-sm backdrop-blur-md'
                }`}
              >
                {msg.role === 'assistant' ? (
                  <div className="prose prose-invert prose-sm max-w-none space-y-3 leading-relaxed">
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      components={{
                        strong: ({ children }) => (
                          <strong className="font-bold text-white bg-slate-800/40 px-1 py-0.5 rounded text-[0.95em]">
                            {children}
                          </strong>
                        ),
                        p: ({ children }) => <p className="mb-2.5 last:mb-0 leading-relaxed text-slate-200">{children}</p>,
                        ul: ({ children }) => <ul className="list-disc list-inside space-y-1.5 my-2 text-slate-300">{children}</ul>,
                        ol: ({ children }) => <ol className="list-decimal list-inside space-y-1.5 my-2 text-slate-300">{children}</ol>,
                        li: ({ children }) => <li className="leading-relaxed">{children}</li>,
                        code: ({ children, className }) => {
                          const isInline = !className;
                          return isInline ? (
                            <code className="rounded bg-slate-950 px-1.5 py-0.5 font-mono text-xs text-cyan-300 border border-slate-800">
                              {children}
                            </code>
                          ) : (
                            <pre className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950 p-3 font-mono text-xs text-slate-200 my-2">
                              <code>{children}</code>
                            </pre>
                          );
                        },
                        blockquote: ({ children }) => (
                          <blockquote className="border-l-2 border-cyan-500/70 pl-3 italic text-slate-300 my-2">
                            {children}
                          </blockquote>
                        ),
                      }}
                    >
                      {msg.content}
                    </ReactMarkdown>

                    {/* Grounding Web Search Sources */}
                    {msg.sources && msg.sources.length > 0 && (
                      <div className="mt-4 pt-3 border-t border-slate-800/80">
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 mb-2">
                          <Globe className="h-3.5 w-3.5 text-cyan-400" />
                          <span>Sources & References:</span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {msg.sources.map((src, sIdx) => (
                            <a
                              key={sIdx}
                              href={src.url}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-950/80 px-2.5 py-1 text-xs text-cyan-300 hover:border-cyan-500/50 hover:bg-slate-800 hover:text-white transition-all truncate max-w-[260px]"
                            >
                              <span className="truncate">{src.title || src.url}</span>
                              <ExternalLink className="h-3 w-3 shrink-0 opacity-70" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                )}

                {/* Copy button on assistant message */}
                {msg.role === 'assistant' && (
                  <div className="mt-2 flex items-center justify-end pt-1">
                    <button
                      type="button"
                      onClick={() => handleCopy(msg.id, msg.content)}
                      className="flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition-all opacity-0 group-hover:opacity-100"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="h-3 w-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3 w-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {/* Loading Indicator */}
          {isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-3"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-xl border border-cyan-500/30 bg-slate-900 text-cyan-400 shadow-md">
                <Sparkles className="h-4 w-4 animate-spin" />
              </div>
              <div className="flex items-center gap-2 rounded-2xl border border-slate-800/80 bg-slate-900/80 px-4 py-3 text-sm text-slate-300">
                <span className="animate-pulse">Gemini 3.7 Flash is analyzing...</span>
                <div className="flex gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Drag & Drop Overlay */}
      <AnimatePresence>
        {isDragOver && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pointer-events-none absolute inset-0 z-50 flex flex-col items-center justify-center bg-cyan-950/80 backdrop-blur-md border-2 border-dashed border-cyan-400 m-4 rounded-3xl"
          >
            <ImageIcon className="h-12 w-12 text-cyan-300 mb-2 animate-bounce" />
            <p className="text-lg font-bold text-white">Drop images or PDFs here</p>
            <p className="text-xs text-cyan-200">Supports multi-image & document analysis</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom Composer / Input Area */}
      <footer className="relative z-10 shrink-0 border-t border-slate-800/80 bg-slate-950/90 p-4 sm:p-5 backdrop-blur-xl">
        <div className="mx-auto max-w-3xl">
          {/* Active Attachments Preview Bar */}
          {attachments.length > 0 && (
            <div className="mb-3 flex flex-wrap gap-2.5">
              {attachments.map((att) => (
                <div
                  key={att.id}
                  className="relative group flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900 p-1.5 pr-3 shadow-md"
                >
                  {att.previewUrl ? (
                    <img
                      src={att.previewUrl}
                      alt={att.name}
                      className="h-10 w-10 rounded-lg object-cover border border-slate-700"
                    />
                  ) : (
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-800 text-cyan-400">
                      <FileText className="h-5 w-5" />
                    </div>
                  )}
                  <div className="flex flex-col max-w-[150px]">
                    <span className="text-xs font-medium text-slate-200 truncate">{att.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{formatFileSize(att.size)}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeAttachment(att.id)}
                    className="ml-1 flex h-5 w-5 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-red-900/60 hover:text-red-300 transition-all"
                    title="Remove file"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Text Input Chassis */}
          <div className="relative flex flex-col rounded-2xl border border-slate-800 bg-slate-900/90 shadow-2xl shadow-black/80 transition-all focus-within:border-cyan-500/60 focus-within:ring-1 focus-within:ring-cyan-500/30">
            <textarea
              ref={textareaRef}
              id="input-ai-chat"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask anything, analyze images or PDFs, search the web... (Shift+Enter for new line)"
              rows={1}
              className="w-full resize-none bg-transparent px-4 pt-3.5 pb-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none max-h-44 leading-relaxed"
            />

            {/* Bottom Controls inside Composer */}
            <div className="flex items-center justify-between px-3 pb-2.5 pt-1">
              <div className="flex items-center gap-1.5">
                {/* File Upload Button */}
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,.pdf,text/*,.md,.json,.csv"
                  onChange={handleFileInput}
                  className="hidden"
                />
                <button
                  type="button"
                  id="btn-ai-attach"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1.5 rounded-xl border border-slate-800/80 bg-slate-800/50 px-2.5 py-1.5 text-xs font-medium text-slate-400 hover:border-slate-700 hover:bg-slate-800 hover:text-slate-200 transition-all"
                  title="Attach images or PDFs"
                >
                  <Paperclip className="h-4 w-4 text-slate-400" />
                  <span className="hidden sm:inline">Attach</span>
                </button>

                {/* Web Search Quick Toggle */}
                <button
                  type="button"
                  onClick={() => setEnableSearch((prev) => !prev)}
                  className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs font-medium transition-all ${
                    enableSearch
                      ? 'border-cyan-500/30 bg-cyan-950/30 text-cyan-300'
                      : 'border-slate-800/80 bg-slate-800/50 text-slate-400 hover:text-slate-300'
                  }`}
                  title="Search the web for up-to-date information"
                >
                  <Globe className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Search Grounding</span>
                </button>
              </div>

              {/* Send Button */}
              <button
                type="button"
                id="btn-ai-send"
                onClick={() => handleSendMessage()}
                disabled={(!input.trim() && attachments.length === 0) || isLoading}
                className={`flex h-9 w-9 items-center justify-center rounded-xl transition-all ${
                  (input.trim() || attachments.length > 0) && !isLoading
                    ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/30 hover:bg-cyan-500 active:scale-95'
                    : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                }`}
                title="Send message"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="mt-2 flex items-center justify-center gap-4 text-[11px] text-slate-400">
            <span>Powered by Gemini 3.7 Flash</span>
            <span>•</span>
            <span>Multimodal Image & PDF Reader</span>
            <span>•</span>
            <span>Web Search Grounded</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
