export interface CoverTransform {
  scale: number; // 0.3 to 3.0 (default 1.0)
  x: number;     // offset % (default 0)
  y: number;     // offset % (default 0)
}

export interface GameItem {
  id: string;
  name: string;
  iframeSrc: string;
  rawIframeSnippet?: string;
  coverUrl?: string;
  coverTransform?: CoverTransform;
  tag?: string; // Optional tag like 'RETIRED'
  isHtmlDoc?: boolean; // If true, render via srcdoc for complex embeds/scripts
  sandboxMode?: 'standard' | 'unrestricted'; // Unrestricted needed for games with strict WebAssembly or third-party workers
  createdAt: number;
}

export interface UpcomingGameItem {
  id: string;
  name: string;
  coverUrl: string;
  tag?: string;
  releaseNote?: string;
}

export type ActiveView = 'home' | 'games' | 'youtube' | 'ai';

export interface ChatAttachment {
  id: string;
  name: string;
  type: string; // mimeType
  size: number;
  dataUrl: string; // base64
  previewUrl?: string;
}

export interface SearchSource {
  title?: string;
  url?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  attachments?: ChatAttachment[];
  sources?: SearchSource[];
  timestamp: number;
}

export interface YouTubeVideoItem {
  id: string;
  title: string;
  channelTitle: string;
  thumbnailUrl: string;
  description?: string;
  publishedAt?: string;
}

export type YouTubeEmbedEngine = 'invidious' | 'piped' | 'piped2' | 'nocookie';

export interface GameSeries {
  id: string;
  name: string;
  description?: string;
  coverUrl: string;
  coverBlurred?: boolean;
  filter: (game: GameItem) => boolean;
}

export interface GameTab {
  id: string;
  game: GameItem;
  title: string;
}

