export const ONE_V_ONE_LOL_HTML = `<!DOCTYPE html>
<html lang="en-us">
  <head>
    <base href="https://1v1-lol-online.github.io/">
    <meta charset="utf-8">
    <title>1v1 LOL - topVAZ #3</title>
    <meta name="robots" content="noindex,nofollow">
    <script type="text/javascript" async="" src="https://server.cpmstar.com/cached/zonefiles/372_49986_1v1.js?rnd=786616"></script>
    <script src="lib/jquery.min.js"></script>
    <script src="js/IronSourceRV.js"></script>
    <script src="js/mobileRedirect.js"></script>
    <script src="js/fullscreen.js"></script>
    <script>
      var gameLoaded = false;
      window.addEventListener("beforeunload", function (e) {
        if (adsVisible || !gameLoaded || !lockedOccured) return null;
        var confirmationMessage = "Are you sure you want to leave? ";
        (e || window.event).returnValue = confirmationMessage;
        return confirmationMessage;
      });
      window.alert = function (e) {
        console.log(e);
      };
    </script>
    <link rel="icon" type="image/png" href="favicon.png?v2">
    <meta property="og:title" content="1v1.LOL">
    <meta property="og:type" content="website">
    <meta property="og:description" content="Discover 1v1, the online building simulator & third person shooting game. Battle royale, build fight, box fight, zone wars and more game modes to enjoy!">
    <link rel="stylesheet" href="css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="description" content="Discover 1v1, the online building simulator & third person shooting game. Battle royale, build fight, box fight, zone wars and more game modes to enjoy!">
    <meta name="keywords" content="just,build,simulator,practice,free,online,battle,royale">
    <script type="text/javascript" src="js/sdkloader/ima3.js"></script>

    <!-- ZONETAG - PLACE INTO HEAD SECTION OR RUN CODE AT STARTUP -->
    <script>
      (function (zonefile) {
        var y = window.location.href
          .split("#")[0]
          .split("")
          .reduce(function (a, b) {
            return ((a << 5) - a + b.charCodeAt(0)) >>> 1;
          }, 0);
        y = (10 + ((y * 7) % 26)).toString(36) + y.toString(36);
        var drutObj = (window[y] = window[y] || {});
        function failCpmstarAPI() {
          var failFn = function (o) {
            o && typeof o === "object" && o.fail && o.fail();
          };
          drutObj && Array.isArray(drutObj.cmd) && drutObj.cmd.forEach(failFn) && (drutObj.cmd.length = 0);
          window.cpmstarAPI = window["_" + zonefile] = failFn;
        }
        var rnd = Math.round(Math.random() * 999999);
        var s = document.createElement("script");
        s.type = "text/javascript";
        s.async = true;
        s.onerror = failCpmstarAPI;
        var proto = document.location.protocol;
        var host = proto == "https:" || proto == "file:" ? "https://server" : "//cdn";
        if (window.location.hash == "#cpmstarDev") host = "//dev.server";
        if (window.location.hash == "#cpmstarStaging") host = "//staging.server";
        s.src = host + ".cpmstar.com/cached/zonefiles/" + zonefile + ".js?rnd=" + rnd;
        var s2 = document.getElementsByTagName("script")[0];
        s2.parentNode.insertBefore(s, s2);
        window.cpmstarAPI = function (o) {
          (drutObj.cmd = drutObj.cmd || []).push(o);
        };
      })("372_49986_1v1");
      if (window.performance && window.performance.__proto__) {
        try {
          Object.defineProperty(window.performance.__proto__, "measures", Object.getOwnPropertyDescriptor(window.performance.__proto__, "now"));
          delete window.performance.__proto__.now;
          window.performance.__proto__.now = {};
          Object.defineProperty(window.performance.__proto__, "now", {
            get: function () {
              return this.measures;
            },
          });
          Object.defineProperty(window.performance.__proto__, "now", {
            set: function () {
              Object.defineProperty(window.performance.__proto__, "now", {
                get: function () {
                  return function () {
                    return this.measures() / 2;
                  };
                },
              });
            },
          });
        } catch (e) {}
      }
    </script>
    <script src="js/cpmstar.js"></script>
  </head>

  <body style="margin: 0; padding: 0; background: #000; overflow: hidden; width: 100%; height: 100vh;">
    <div id="gameContainer" style="padding: 0px; margin: 0px; border: 0px; position: absolute; width: 100%; height: 100%; background: rgb(0, 0, 0);">
      <canvas id="#canvas" width="100%" height="100%" style="width: 100%; height: 100%; cursor: default; display: block;"></canvas>
    </div>
    <div id="loader" style="display: none;">
      <img class="logo" src="logo.png">
      <div class="spinner" style="display: none;"></div>
      <div class="progress" style="display: block;">
        <div class="full" style="transform: scaleX(1);"></div>
      </div>
    </div>

    <script id="unity-loader" src="UnityLoader.js"></script>
    <script>
      var gameJsonUrl = "WebGL.json";
      var gameInstance = UnityLoader.instantiate("gameContainer", gameJsonUrl, { onProgress: UnityProgress });

      window.unityInstance = gameInstance;
      var lockedOccured = false;

      function UnityProgress(gameInstance, progress) {
        if (!gameInstance.Module) {
          return;
        }
        const loader = document.querySelector("#loader");
        if (loader) {
          if (!gameInstance.progress) {
            const progressEl = document.querySelector("#loader .progress");
            if (progressEl) progressEl.style.display = "block";
            gameInstance.progress = progressEl ? progressEl.querySelector(".full") : null;
            const spinner = loader.querySelector(".spinner");
            if (spinner) spinner.style.display = "none";
          }
          if (gameInstance.progress) {
            gameInstance.progress.style.transform = "scaleX(" + progress + ")";
          }
          if (progress === 1 && !gameInstance.removeTimeout) {
            loader.style.display = "none";
            gameLoaded = true;
          }
        }
      }

      document.onkeydown = function (e) {
        if (e.altKey || e.ctrlKey || e.key == "F1" || e.key == "F2" || e.key == "F3" || e.key == "F4") {
          e.preventDefault();
        }
      };

      document.onmouseup = function (e) {
        e.preventDefault();
      };

      document.addEventListener("pointerlockchange", lockChangeAlert, false);
      document.addEventListener("mozpointerlockchange", lockChangeAlert, false);

      function lockChangeAlert() {
        if (!lockedOccured && document.pointerLockElement) lockedOccured = true;
        if (!document.pointerLockElement && lockedOccured) {
          lockedOccured = false;
          if (gameInstance && gameInstance.SendMessage) {
            try { gameInstance.SendMessage("Pause Menu", "OnCursorUnlocked"); } catch(e){}
          }
        }
      }
    </script>
    <script src="firebase/firebase-app.js"></script>
    <script src="firebase/firebase-analytics.js"></script>
    <script src="firebase/firebase-auth.js"></script>
    <script src="firebase/firebase-firestore.js"></script>
    <script src="firebase/firebase-remote-config.js"></script>
    <script src="js/firebase.js?v=147"></script>
    <script src="js/login.js?v=147"></script>
    <script src="js/firebase-config.js?v=147"></script>
    <script>
      try {
        if (typeof initializeFireBase === 'function') initializeFireBase();
        if (typeof initRemoteConfig === 'function') initRemoteConfig();
      } catch (e) {}
    </script>
    <script src="js/windowResize.js"></script>
    <script src="js/adblockManager.js"></script>
    <script src="js/macUserAgent.js"></script>
    <script src="js/visibilityChangeListener.js"></script>
    <script>
      function onUnityReady() {
        if (typeof checkAdBlock === 'function') checkAdBlock();
        if (typeof sendConfig === 'function') sendConfig();
      }
      if (typeof fixMacUserAgent === 'function') fixMacUserAgent();
    </script>
  </body>
</html>`;
