export const COOKIE_CLICKER_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <base href="https://cookieclickerplay.github.io/file/">
  <meta charset="utf-8">
  <title>Cookie Clicker</title>
  <meta name="description" content="The original idle game where you bake cookies to rule the universe!">
  <meta name="viewport" content="width=900, initial-scale=1">
  <link rel="shortcut icon" href="img/favicon.ico" />
  <link href="https://fonts.googleapis.com/css?family=Merriweather:900&subset=latin,latin-ext" rel="stylesheet" type="text/css">
  <script src="base64.js"></script>
  <script src="main.js"></script>
  <link href="style.css?v=2.053" rel="stylesheet" type="text/css">
  <script type="text/javascript" src="/cloak.js"></script>
  <meta name="robots" content="noindex,nofollow" />
  <style>
    html, body {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background: #000;
    }
  </style>
  <script>
    // Frostbite Auto-Clicker listener
    window.addEventListener('message', function(e) {
      if (!e.data) return;
      if (e.data.type === 'AUTO_CLICK' || e.data === 'AUTO_CLICK') {
        try {
          if (window.Game && typeof window.Game.ClickCookie === 'function') {
            window.Game.ClickCookie();
          } else {
            var cookie = document.getElementById('bigCookie');
            if (cookie) cookie.click();
          }
        } catch (err) {}
      }
    });
  </script>
</head>
<body>
  <div id="wrapper">
    <div id="topBar">
      <div><b>Cookie Clicker</b>&trade; &copy; <a href="//orteil.dashnet.org" target="_blank" id="topbarOrteil">Orteil</a>, 2021 - <a href="//dashnet.org" target="_blank" id="topbarDashnet">DashNet</a></div>
      <div><a href="https://twitter.com/orteil42" target="_blank" id="topbarTwitter">twitter</a></div>
      <div><a href="https://orteil42.tumblr.com" target="_blank" id="topbarTumblr">tumblr</a></div>
      <div style="position:relative;"><div style="width:22px;height:32px;background:url(img/discord.png);position:absolute;left:0px;top:0px;pointer-events:none;"></div><a href="https://discordapp.com/invite/cookie" target="_blank" style="padding-left:16px;" id="topbarDiscord">Discord</a></div>
      <div style="position:relative;"><div style="width:25px;height:32px;background:url(img/weeHoodie.png);position:absolute;left:-2px;top:0px;pointer-events:none;"></div><a class="blueLink" href="http://www.redbubble.com/people/dashnet" target="_blank" style="padding-left:12px;" id="topbarMerch">Merch!</a></div>
      <div style="position:relative;"><div style="width:22px;height:32px;background:url(img/patreon.png);position:absolute;left:0px;top:0px;pointer-events:none;"></div><a class="orangeLink" href="https://www.patreon.com/dashnet" target="_blank" style="padding-left:16px;" id="topbarPatreon">Patreon</a></div>
      <div style="position:relative;display:none;font-weight:bold;" id="heralds"><div style="position:absolute;top:-4px;width:31px;height:39px;background:url(img/heraldFlag.png);left:50%;margin-left:-15px;pointer-events:none;"></div><div id="heraldsAmount" style="position:relative;z-index:10;text-shadow:0px 1px 0px #000,0px 0px 6px #ff00e4;color:#fff;">-</div></div>
      <div><a class="lightblueLink" style="font-weight:bold;" href="https://play.google.com/store/apps/details?id=org.dashnet.cookieclicker" target="_blank" id="topbarMobileCC">Cookie Clicker for Android</a></div>
      <div><a href="//orteil.dashnet.org/randomgen/" target="_blank" id="topbarRandomgen">RandomGen</a></div>
      <div><a href="//orteil.dashnet.org/igm/" target="_blank" id="topbarIGM">Idle Game Maker</a></div>
      <div id="links" class="hoverer">
        Other versions
        <div class="hoverable">
          <a href="../" target="_blank" id="linkVersionLive">Live version</a>
          <a href="beta" target="_blank" id="linkVersionBeta">Try the beta!</a>
          <a href="//orteil.dashnet.org/cookieclicker/v10466" target="_blank" id="linkVersionOld">v. 1.0466</a>
          <a href="//orteil.dashnet.org/experiments/cookie/" target="_blank">Classic</a>
        </div>
      </div>
    </div>
    <div id="game">
      <div id="javascriptError">
        <div id="loader">
          <div class="spinnyBig"></div>
          <div class="spinnySmall"></div>
          <div id="loading" class="title">Loading...</div>
          <div id="failedToLoad" class="title">This is taking longer than expected.<br>
          <div style="font-size:65%;line-height:120%;">Slow connection? If not, please make sure your javascript is enabled, then refresh.<br>
          If problems persist, this might be on our side - wait a few minutes, then hit ctrl+f5!</div></div>
          <div id="ifIE9" class="title" style="font-size:100%;line-height:120%;">Your browser may not be recent enough to run Cookie Clicker.<br>You might want to update, or switch to a more modern browser such as Chrome or Firefox.</div>
        </div>
      </div>
      <canvas id="backgroundCanvas"></canvas>
      <div id="goldenCookie" class="goldenCookie"></div>
      <div id="seasonPopup" class="seasonPopup"></div>
      <div id="shimmers"></div>
      <div id="alert"></div>
      <div id="particles"></div>
      <div id="sparkles" class="sparkles"></div>
      <div id="notes"></div>
      <div id="darken"></div>
      <div id="toggleBox" class="framed prompt"></div>
      <div id="promptAnchor"><div id="prompt" class="framed"><div id="promptContent"></div><div class="close" onclick="PlaySound('snd/tick.mp3');Game.ClosePrompt();">x</div></div></div>
      <div id="versionNumber" class="title"></div>
      <div id="ascend">
        <div id="ascendBG"></div>
        <div id="ascendZoomable"><div id="ascendContent"><div id="ascendUpgrades" style="position:absolute;"></div></div></div>
        <div id="ascendOverlay"></div>
      </div>
      <div id="debug"><div id="devConsole" class="framed"></div><div id="debugLog"></div></div>
      <div id="sectionLeft" class="inset">
        <canvas id="backgroundLeftCanvas" style="z-index:5;"></canvas>
        <div class="blackFiller"></div>
        <div class="blackGradient"></div>
        <div id="sectionLeftInfo"></div>
        <div id="cookies" class="title"></div>
        <div id="bakeryNameAnchor"><div id="bakeryName" class="title"></div></div>
        <div id="specialPopup" class="framed prompt offScreen"></div>
        <div id="buffs" class="crateBox"></div>
        <div id="cookieAnchor">
          <div id="bigCookie"></div>
          <div id="cookieNumbers"></div>
        </div>
        <div id="sectionLeftExtra"></div>
      </div>
      <div class="separatorLeft"></div>
      <div class="separatorRight"></div>
      <div id="sectionMiddle" class="inset">
        <div id="comments" class="inset title">
          <div id="prefsButton" class="button">Options</div>
          <div id="statsButton" class="button">Stats</div>
          <div id="logButton" class="button"><div id="checkForUpdate">New update!</div>Info</div>
          <div id="legacyButton" class="button">Legacy<div id="ascendMeterContainer" class="smallFramed meterContainer"><div id="ascendMeter" class="meter filling"></div></div><div class="roundedPanel" id="ascendNumber"></div><div id="ascendTooltip" class="framed"></div></div>
          <div id="commentsTextBelow" class="commentsText"></div>
          <div id="commentsText" class="commentsText"></div>
          <div class="separatorBottom"></div>
        </div>
        <div id="centerArea">
          <div id="buildingsTitle" class="inset title zoneTitle">Buildings</div>
          <div id="buildingsMaster"></div>
          <div id="rows"></div>
          <div id="menu"></div>
        </div>
      </div>
      <div id="sectionRight" class="inset">
        <div id="smallSupport" style="width:300px;text-align:center;padding-bottom:40px;background:rgba(0,0,0,0.5);position:relative;z-index:100;"></div>
        <div id="store">
          <div id="storeTitle" class="inset title zoneTitle">Store</div>
          <div id="toggleUpgrades" class="storeSection upgradeBox"></div>
          <div id="techUpgrades" class="storeSection upgradeBox"></div>
          <div id="vaultUpgrades" class="storeSection upgradeBox"></div>
          <div id="upgrades" class="storeSection upgradeBox"></div>
          <div id="products" class="storeSection"></div>
        </div>
        <div id="detectAds" class="adBanner" style="background:transparent;width:1px;height:1px;"></div>
        <div id="support" style="margin-top:130px;">
          <div style="position:relative;"></div>
        </div>
      </div>
      <div id="focusButtons">
        <div id="focusLeft" class="title">Cookie</div>
        <div id="focusMiddle" class="title" style="font-size:80%;padding-top:18px;padding-bottom:14px;">Buildings</div>
        <div id="focusRight" class="title">Store</div>
        <div id="focusMenu" class="title">Menu</div>
      </div>
      <div id="compactOverlay" class="title">
        <div id="compactCommentsText" class="commentsText"></div>
        <div id="compactCookies"></div>
        <div class="separatorBottom"></div>
      </div>
      <div id="tooltipAnchor"><div id="tooltip" class="framed" onMouseOut="Game.tooltip.hide();"></div></div>
    </div>
  </div>
</body>
</html>`;
