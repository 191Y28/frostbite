export const PAPAS_SUSHIRIA_HTML = `<!DOCTYPE html>
<html lang="en" style="width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden; background: #000;">
<head>
  <meta charset="utf-8">
  <title>Papa's Sushiria</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://unpkg.com/@ruffle-rs/ruffle"></script>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #000;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    #player-container {
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    ruffle-player {
      width: 100% !important;
      height: 100% !important;
    }
  </style>
</head>
<body>
  <div id="player-container"></div>
  <script>
    window.RufflePlayer = window.RufflePlayer || {};
    window.addEventListener("DOMContentLoaded", () => {
      const ruffle = window.RufflePlayer.newest();
      const player = ruffle.createPlayer();
      const container = document.getElementById("player-container");
      container.appendChild(player);
      player.load({
        url: "https://www.gameslol.net/data/1285.swf",
        backgroundColor: "#000000",
        letterbox: "on",
        autoplay: "on",
        unmuteOverlay: "hidden"
      });
    });
  </script>
</body>
</html>`;
