export const MOTO_X3M_3_HTML = `<!DOCTYPE html>
<html class="wf-impact-n4-active wf-allerdisplay-n4-active wf-cfcrackbold-n4-active wf-active">
<head>
<base href="https://unblockedgames67.gitlab.io/projects/moto-x3m-3/">
<link href="assets/css/app.css" rel="stylesheet" type="text/css">
<meta charset="utf-8">
<meta content="ie=edge" http-equiv="x-ua-compatible">
<meta content="initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" name="viewport">
<style type="text/css">
    * {
        margin: 0;
        padding: 0;
    }
    html, body {
        width: 100%;
        height: 100%;
        overflow: hidden;
        background: #000;
    }
    #content {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    canvas {
        width: 100% !important;
        height: 100% !important;
        object-fit: contain;
    }
</style>
<title>Moto X3M 3</title>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<link rel="stylesheet" href="assets/css/AllerDisplay.css" media="all">
<link rel="stylesheet" href="assets/css/CfCrackBold.css" media="all">
<link rel="stylesheet" href="assets/css/impact.css" media="all">
</head>
<body dir="ltr">
<div id="content"><canvas width="855" height="481"></canvas></div>
<div id="orientation"></div>
<div id="loader" style="display: none;">Loading ...</div>
<script src="assets/box2dweb/nape.min.js" type="text/javascript"></script>
<script src="assets/box2dweb/nape-debug-draw.min.js" type="text/javascript"></script>
<script src="assets/box2dweb/jquery-3.1.1.min.js" type="text/javascript"></script>
<script src="assets/box2dweb/easeljs-0.8.2.combined.js" type="text/javascript"></script>
<script src="assets/box2dweb/bluebird.min.js" type="text/javascript"></script>
<script src="motox3m3.min.js" type="text/javascript"></script>
</body>
</html>`;
