export const GTA_VICE_CITY_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grand Theft Auto: Vice City - Error</title>
    <style>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      body, html {
        width: 100%;
        height: 100%;
        background-color: #202124;
        color: #e8eaed;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 24px;
        overflow: auto;
      }
      .error-card {
        max-width: 580px;
        width: 100%;
        background: #292a2d;
        border: 1px solid #3c4043;
        border-radius: 16px;
        padding: 40px 32px;
        box-shadow: 0 12px 36px rgba(0, 0, 0, 0.5);
        text-align: left;
      }
      .icon-wrapper {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 56px;
        height: 56px;
        border-radius: 12px;
        background: rgba(239, 68, 68, 0.15);
        border: 1px solid rgba(239, 68, 68, 0.3);
        color: #f87171;
        margin-bottom: 24px;
      }
      .icon-wrapper svg {
        width: 32px;
        height: 32px;
        stroke: currentColor;
      }
      h1 {
        font-size: 24px;
        font-weight: 600;
        color: #f1f3f4;
        margin-bottom: 12px;
        letter-spacing: -0.3px;
      }
      p {
        font-size: 14px;
        line-height: 1.6;
        color: #9aa0a6;
        margin-bottom: 20px;
      }
      .code-box {
        background: #1e1f22;
        border: 1px solid #3c4043;
        border-radius: 8px;
        padding: 12px 16px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 12px;
        color: #fca5a5;
        margin-bottom: 24px;
        word-break: break-all;
      }
      .details-list {
        list-style: none;
        font-size: 13px;
        color: #bdc1c6;
        margin-bottom: 28px;
        line-height: 1.8;
      }
      .details-list li {
        display: flex;
        align-items: flex-start;
        gap: 8px;
      }
      .details-list li::before {
        content: "•";
        color: #8ab4f8;
        font-weight: bold;
      }
      .btn-row {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
      }
      .btn-primary {
        background: #8ab4f8;
        color: #202124;
        border: none;
        border-radius: 8px;
        padding: 10px 20px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.2s;
      }
      .btn-primary:hover {
        background: #a8c7fa;
      }
      .btn-secondary {
        background: transparent;
        color: #8ab4f8;
        border: 1px solid #5f6368;
        border-radius: 8px;
        padding: 10px 20px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: border-color 0.2s, background 0.2s;
      }
      .btn-secondary:hover {
        border-color: #8ab4f8;
        background: rgba(138, 180, 248, 0.08);
      }
    </style>
</head>
<body>
    <div class="error-card">
        <div class="icon-wrapper">
            <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
                <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
                <line x1="6" y1="6" x2="6.01" y2="6"></line>
                <line x1="6" y1="18" x2="6.01" y2="18"></line>
            </svg>
        </div>
        <h1>Ran out of memory</h1>
        <p>
            Grand Theft Auto: Vice City required more memory than this browser or system can allocate for WebAssembly runtime heaps (633.45 MB required).
        </p>
        <div class="code-box">
            Error code: Out of Memory (RESULT_CODE_KILLED_BAD_MESSAGE)
        </div>
        <ul class="details-list">
            <li>Failed to allocate linear memory for WebAssembly instance</li>
            <li>Heap size allocation request: 633.45 MB exceeded available RAM quota</li>
            <li>Try closing other active browser tabs to free up system memory</li>
        </ul>
        <div class="btn-row">
            <button class="btn-primary" onclick="location.reload()">Reload</button>
            <button class="btn-secondary" onclick="window.parent?.postMessage({type: 'CLOSE_MODAL'}, '*')">Close Game</button>
        </div>
    </div>
</body>
</html>
`;
