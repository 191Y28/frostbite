export const BOB_THE_ROBBER_4_HTML = `<!DOCTYPE html>
<html lang="en-us"><head>
    <base href="https://ubg235.pages.dev/game/bob-the-robber-4/">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Bob the Robber 4</title>
    <script id="gamedistribution-jssdk" src="main.min.js"></script>
    <meta name="description" content="Bob the Robber 4 is the fourth game in the Bob the Robber series. This time, Bob has his sights set on France to make his next fortune. Traverse the corridors of various establishments finding loot, and make sure you don’t get caught!">
    <meta name="robots" content="noindex,nofollow">
    <script>
      function UnityCallJs() { console.log("unity call!"); }
      function UnityCallEndgameJs() { console.log("untiy call end game"); }
      function UnityCallPlayJs() { console.log("untiy call Play game"); }
      function UnityCallLeaderboardJs() { console.log("untiy call On Leaderboard"); }
      function UnityCallAgainJs() { console.log("unity call Again"); }
      function UnityCallBackHomeJs() { console.log("untiy call backHome"); }
      function UnityCallChangeDayLeaderboardJs() { console.log("untiy call change day leaderboard"); }
      function UnityCallCloseLeaderboardJs() { console.log("untiy call close leaderboard"); }
    </script>
    <style>
      html, body {
        margin: 0;
        padding: 0;
        width: 100vw;
        height: 100vh;
        overflow: hidden;
        background: #000;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .webgl-content * {
        border: 0;
        margin: 0;
        padding: 0;
      }
      .webgl-content {
        position: absolute;
        width: 100% !important;
        height: 100% !important;
      }
      #gameContainer,
      #unityContainer,
      canvas {
        width: 100% !important;
        height: 100% !important;
      }
      .webgl-content .logo,
      .progress {
        position: absolute;
        left: 50%;
        top: 50%;
        -webkit-transform: translate(-50%, -50%);
        transform: translate(-50%, -50%);
      }
      .webgl-content .logo {
        background: url("progressLogo.Light.png") no-repeat center/contain;
        width: 354px;
        height: 130px;
      }
      .webgl-content .progress {
        height: 18px;
        width: 141px;
        margin-top: 90px;
      }
      .webgl-content .progress .empty {
        background: url("progressEmpty.Light.png") no-repeat right/cover;
        float: right;
        width: 100%;
        height: 100%;
        display: inline-block;
      }
      .webgl-content .progress .full {
        background: url("progressFull.Light.png") no-repeat left/cover;
        float: left;
        width: 0%;
        height: 100%;
        display: inline-block;
      }
    </style>
  </head>
  <body style="margin: 0 auto; overflow: hidden">
    <div class="webgl-content">
      <div id="gameContainer" style="width: 100%; height: 100%; margin: 0px; padding: 0px; border: 0px; position: relative; background: black;">
        <canvas id="#canvas" style="cursor: default;" width="589" height="768"></canvas>
      </div>
    </div>
    <script src="UnityLoader2019.js"></script>
    <script>
      var gameInstance = UnityLoader.instantiate("gameContainer", "web.json");
      function UnityProgress(gameInstance, progress) {}
    </script>
  </body>
</html>`;
