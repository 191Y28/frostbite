export const SUBWAY_SURFERS_TOKYO_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <base href="https://rawcdn.githack.com/3kh0/3kh0-assets/main/subway-surfers-tokyo/">
    <meta charset="UTF-8">
    <script src="game.js"></script>
    <script src="./set.js" type="text/javascript"></script>
    <meta http-equiv="content-type" content="text/html; charset=UTF8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="height=device-height, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no, minimal-ui, viewport-fit=cover">
    <title>Subway Surfers: Tokyo</title>
    <style>
        body, html { 
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            background-color: #0b316b;
            overflow: hidden;
            background-image: url('assets/preload/splash.png');
            background-repeat: no-repeat;
            background-position: center;
        }

        #message {
            text-align: center;
            font-size: 8px;
            z-index: 5;
            font-family: "Verdana", sans-serif;
            color: #fff;
            position: fixed;
            width: 100%;
            z-index: 9999;
        }

        .dot {
            display: inline;
            margin-left: 0.2em;
            margin-right: 0.2em;
            position: relative;
            top: -1em;
            font-size: 3.5em;
            opacity: 0;
            animation: showHideDot 2.5s ease-in-out infinite;
        }

        .dot.one { animation-delay: 0.2s; }
        .dot.two { animation-delay: 0.4s; }
        .dot.three { animation-delay: 0.6s; }

        @keyframes showHideDot {
            0% { opacity: 0; }
            50% { opacity: 1; }
            60% { opacity: 1; }
            100% { opacity: 0; }
        }

        #pixi-canvas {
            position: absolute;
            inset: 0px;
            width: 100% !important;
            height: 100% !important;
            overflow: visible;
            display: block;
            touch-action: none;
            cursor: inherit;
        }
    </style>
    <script src="./js/dependencies.bundle.js"></script>
    <script src="./js/index.js"></script>
    <style>
        @font-face {
            font-family: Lilita One;
            src: url("assets/font/lilita-one.woff2?h=sktwi14z3l34lqwki") format('woff2'),
                 url("assets/font/lilita-one.woff?h=sktwi14z3l34lqwki") format('woff');
            font-weight: normal;
            font-style: normal;
        }
        @font-face {
            font-family: Stencilia;
            src: url("assets/font/stencilia.woff2?h=sktwi14z3l34lqwki") format('woff2'),
                 url("assets/font/stencilia.woff?h=sktwi14z3l34lqwki") format('woff');
            font-weight: normal;
            font-style: normal;
        }
        @font-face {
            font-family: Titan One;
            src: url("assets/font/titan-one.woff2?h=sktwi14z3l34lqwki") format('woff2'),
                 url("assets/font/titan-one.woff?h=sktwi14z3l34lqwki") format('woff');
            font-weight: normal;
            font-style: normal;
        }
    </style>
</head>
<body>
    <script>
        window.NOSW = true;
        window.GAME_CONFIG = {
            pokiSdkDebug: false,
            leaderboard: 'mockup',
            bundlesPath: './bundles',
        };
    </script>
    <script src="js/loading.js"></script>
    <script src="js/boot.js"></script>

    <div class="fontcache" style="font-family: 'Lilita One'; position: fixed; margin-left: -100px; margin-top: -100px; background-color: blue; z-index: 9999;">.</div>
    <div class="fontcache" style="font-family: Stencilia; position: fixed; margin-left: -100px; margin-top: -100px; background-color: blue; z-index: 9999;">.</div>
    <div class="fontcache" style="font-family: 'Titan One'; position: fixed; margin-left: -100px; margin-top: -100px; background-color: blue; z-index: 9999;">.</div>
    <canvas id="pixi-canvas"></canvas>
</body>
</html>`;
