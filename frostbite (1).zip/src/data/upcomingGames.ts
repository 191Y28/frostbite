import { UpcomingGameItem } from '../types';
import minecraftCover from '../assets/minecraft.webp';

export const UPCOMING_GAMES: UpcomingGameItem[] = [
  {
    id: 'minecraft-26-3',
    name: 'Minecraft (26.3)',
    coverUrl: minecraftCover,
    tag: 'UPCOMING',
    releaseNote: 'Wilderness Bound Update (v26.3)',
  },
];

