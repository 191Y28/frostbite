import { GameSeries } from '../types';
import subwaySurfersCover from '../assets/subway-surfers.jpg';
import fireboyWatergirl1Cover from '../assets/fireboy-watergirl-1.jpeg';
import motox3mCover from '../assets/motox3m.png';
import templeRun2Cover from '../assets/temple-run-2.jpeg';
import basketRandomCover from '../assets/basket-random.webp';
import retroBowlCover from '../assets/retro-bowl.png';
import gtaViceCityCover from '../assets/gta-vice-city.jpeg';
import papasFreezeriaCover from '../assets/papas-freezeria.jpeg';

/**
 * Predefined Game Series list in the specified display order:
 * 1. Subway Surfers Series
 * 2. Fireboy & Watergirl Series
 * 3. Moto X3M Series
 * 4. Temple Run Series
 * 5. Two Player Series (Basket Random blurred cover)
 * 6. Retro & Classic Series
 * 7. Action & Adventure Series
 * 8. Papa's Series
 */
export const GAME_SERIES_LIST: GameSeries[] = [
  {
    id: 'subway-surfers-series',
    name: 'Subway Surfers Series',
    description: 'World Tour editions across global cities',
    coverUrl: subwaySurfersCover,
    filter: (g) => {
      const name = g.name.toLowerCase();
      // Only include main World Tour / endless runner versions, excluding spin-offs like Blast or Match
      return (
        name.includes('subway surfers') &&
        !name.includes('blast') &&
        !name.includes('match')
      );
    },
  },
  {
    id: 'fireboy-watergirl-series',
    name: 'Fireboy & Watergirl Series',
    description: 'Elemental co-op puzzle platformers 1 through 6',
    coverUrl: fireboyWatergirl1Cover,
    filter: (g) => {
      const name = g.name.toLowerCase();
      return name.includes('fireboy') || name.includes('watergirl');
    },
  },
  {
    id: 'motox3m-series',
    name: 'Moto X3M Series',
    description: 'Adrenaline stunt bike obstacle courses & seasonal themes',
    coverUrl: motox3mCover,
    filter: (g) => {
      const name = g.name.toLowerCase();
      return name.includes('moto x3m') || name.includes('motox3m');
    },
  },
  {
    id: 'temple-run-series',
    name: 'Temple Run Series',
    description: 'High-speed cursed idol temple escapes & seasonal maps',
    coverUrl: templeRun2Cover,
    filter: (g) => {
      const name = g.name.toLowerCase();
      return name.includes('temple run') && !name.includes('temple of boom');
    },
  },
  {
    id: 'two-player-series',
    name: 'Two Player Series',
    description: 'Head-to-head physics & multiplayer battle favorites',
    coverUrl: basketRandomCover,
    coverBlurred: true,
    filter: (g) => {
      const name = g.name.toLowerCase();
      return (
        name.includes('random') ||
        name.includes('rooftop snipers') ||
        name.includes('tube jumpers') ||
        name.includes('wrassling') ||
        name.includes('rowdy wrestling') ||
        name.includes('1v1.lol') ||
        name.includes('boxing') ||
        name.includes('gun mayhem') ||
        name.includes('temple of boom') ||
        name.includes('getaway shootout') ||
        name.includes('streets of rage') ||
        name.includes('street fighter') ||
        name.includes('smash bros') ||
        name.includes('mortal kombat')
      );
    },
  },
  {
    id: 'retro-classic-series',
    name: 'Retro & Classic Series',
    description: 'Timeless arcade hits, sports simulations & retro gems',
    coverUrl: retroBowlCover,
    filter: (g) => {
      const name = g.name.toLowerCase();
      return (
        name.includes('retro bowl') ||
        name.includes('tetris') ||
        name.includes('mario') ||
        name.includes('smash bros') ||
        name.includes('street fighter') ||
        name.includes('streets of rage') ||
        name.includes('mortal kombat') ||
        name.includes('2048') ||
        name.includes('fruit ninja') ||
        name.includes('doodle jump')
      );
    },
  },
  {
    id: 'action-open-world-series',
    name: 'Action & Adventure Series',
    description: 'Expansive open worlds, survival crafting & dungeons',
    coverUrl: gtaViceCityCover,
    filter: (g) => {
      const name = g.name.toLowerCase();
      return (
        name.includes('minecraft') ||
        name.includes('gta') ||
        name.includes('drift hunters') ||
        name.includes('tomb of the mask')
      );
    },
  },
  {
    id: 'papas-series',
    name: "Papa's Series",
    description: 'Iconic restaurant time-management & cooking stations',
    coverUrl: papasFreezeriaCover,
    filter: (g) => {
      const name = g.name.toLowerCase();
      return name.includes('papa');
    },
  },
];
