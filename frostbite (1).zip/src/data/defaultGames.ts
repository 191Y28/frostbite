import { GameItem } from '../types';
import madalinCover from '../assets/madalin-stunt-cars-2.jpeg';
import boxingCover from '../assets/boxing-physics-2.jpg';
import boxingRandomCover from '../assets/boxing-random.jpeg';
import oneVOneCover from '../assets/1v1lol.jpeg';
import slopeCover from '../assets/slope.jpeg';
import retroBowlCover from '../assets/retro-bowl.png';
import fruitNinjaCover from '../assets/fruit-ninja.jpg';
import sm64Cover from '../assets/sm64.jpeg';
import bitlifeCover from '../assets/bitlife.jpeg';
import subwaySurfersCover from '../assets/subway-surfers.jpg';
import subwaySurfersBuenosCover from '../assets/subway-surfers-buenos.webp';
import subwaySurfersZurichCover from '../assets/subway-surfers-zurich.avif';
import subwaySurfersBarcelonaCover from '../assets/subway-surfers-barcelona.jpg';
import subwaySurfersBeijingCover from '../assets/subway-surfers-beijing.jpeg';
import subwaySurfersBerlinCover from '../assets/subway-surfers-berlin.jpeg';
import subwaySurfersHoustonCover from '../assets/subway-surfers-houston.jpeg';
import subwaySurfersIcelandCover from '../assets/subway-surfers-iceland.jpg';
import subwaySurfersMexicoCover from '../assets/subway-surfers-mexico.jpeg';
import subwaySurfersMiamiCover from '../assets/subway-surfers-miami.jpeg';
import subwaySurfersWinterHolidayCover from '../assets/subway-surfers-winter-holiday.jpeg';
import subwaySurfersNewYorkCover from '../assets/subway-surfers-new-york.jpeg';
import subwaySurfersMonacoCover from '../assets/subway-surfers-monaco.jpeg';
import subwaySurfersHollywoodCover from '../assets/subway-surfers-hollywood.jpeg';
import subwaySurfersTokyoCover from '../assets/subway-surfers-tokyo.jpeg';
import templeRun2Cover from '../assets/temple-run-2.jpeg';
import templeRun2JungleFallCover from '../assets/temple-run-2-jungle-fall.jpeg';
import templeRun2SpookySummitCover from '../assets/temple-run-2-spooky-summit.jpeg';
import templeRun2HoliFestivalCover from '../assets/temple-run-2-holi-festival.jpeg';
import templeRun2HolidayHavocCover from '../assets/temple-run-2-holiday-havoc.jpeg';
import templeRun2FrozenShadowsCover from '../assets/temple-run-2-frozen-shadows.jpeg';
import ragdollHitCover from '../assets/ragdoll-hit.webp';

import motox3mCover from '../assets/motox3m.png';
import motox3m2Cover from '../assets/motox3m-2.jpeg';
import motox3m3Cover from '../assets/motox3m-3.jpg';
import motox3mWinterCover from '../assets/motox3m-winter.jpeg';
import motox3mPoolPartyCover from '../assets/motox3m-pool-party.jpeg';
import motox3mSpookyLandCover from '../assets/motox3m-spooky-land.png';
import game2048Cover from '../assets/2048.jpeg';
import basketRandomCover from '../assets/basket-random.webp';
import soccerRandomCover from '../assets/soccer-random.jpeg';
import tombOfTheMaskCover from '../assets/tomb-of-the-mask.jpeg';
import fireboyWatergirl1Cover from '../assets/fireboy-watergirl-1.jpeg';
import fireboyWatergirl2Cover from '../assets/fireboy-watergirl-2.png';
import fireboyWatergirl3Cover from '../assets/fireboy-watergirl-3.png';
import fireboyWatergirl4Cover from '../assets/fireboy-watergirl-4.jpeg';
import fireboyWatergirl5Cover from '../assets/fireboy-watergirl-5.jpeg';
import fireboyWatergirl6Cover from '../assets/fireboy-watergirl-6.jpeg';
import volleyRandomCover from '../assets/volley-random.jpeg';
import cookieClickerCover from '../assets/cookie-clicker.png';
import rooftopSnipersCover from '../assets/rooftop-snipers.jpeg';
import tubeJumpersCover from '../assets/tube-jumpers.jpeg';
import wrasslingCover from '../assets/wrassling.jpeg';
import rowdyWrestlingCover from '../assets/rowdy-wrestling.jpeg';
import templeOfBoomCover from '../assets/temple-of-boom.png';
import gtaViceCityCover from '../assets/gta-vice-city.jpeg';
import superSmashBrosCover from '../assets/super-smash-bros.jpeg';
import superMarioBrosCover from '../assets/super-mario-bros.jpeg';
import superMarioBros2Cover from '../assets/super-mario-bros-2.jpeg';
import superMarioBros3Cover from '../assets/super-mario-bros-3.jpeg';
import streetFighter2TurboCover from '../assets/street-fighter-2-turbo.jpeg';
import streetsOfRageCover from '../assets/streets-of-rage.jpeg';
import mortalKombat4Cover from '../assets/mortal-kombat-4.jpeg';
import minecraftCover from '../assets/minecraft.jpeg';
import run3Cover from '../assets/run-3.jpeg';
import crossyRoadCover from '../assets/crossy-road.jpeg';
import melonPlaygroundCover from '../assets/melon-playground.jpeg';
import happyWheelsCover from '../assets/happy-wheels.jpeg';
import jetpackJoyrideCover from '../assets/jetpack-joyride.jpeg';
import bigShotBoxingCover from '../assets/big-shot-boxing.webp';
import vex7Cover from '../assets/vex-7.jpeg';
import burritoBisonCover from '../assets/burrito-bison.jpeg';
import gunMayhem2Cover from '../assets/gun-mayhem-2.jpg';
import papasFreezeriaCover from '../assets/papas-freezeria.jpeg';
import papasPizzeriaCover from '../assets/papas-pizzeria.jpeg';
import papasBurgeriaCover from '../assets/papas-burgeria.jpeg';
import basketballStarsCover from '../assets/basketballstars.jpeg';
import smashKartsCover from '../assets/smashkarts.jpeg';
import snowRider3dCover from '../assets/snowrider3d.jpeg';
import vex6Cover from '../assets/vex6.jpeg';
import solitaireCover from '../assets/solitaire.jpeg';
import basketBrosCover from '../assets/basketbros.jpeg';
import stickmanHookCover from '../assets/stickmanhook.jpeg';
import ovoCover from '../assets/ovo.jpeg';
import bloonsTd5Cover from '../assets/bloonstowerdefense5.jpeg';
import madalinStuntCars3Cover from '../assets/madalinstuntcars3.jpeg';
import tinyFishingCover from '../assets/tinyfishing.jpeg';
import slitherioCover from '../assets/slitherio.jpeg';
import krunkerCover from '../assets/krunker.jpeg';
import paperIo2Cover from '../assets/paperio2.jpeg';
import infiniteCraftCover from '../assets/infinitecraft.jpeg';
import timeShooter2Cover from '../assets/timeshooter2.jpeg';
import escapeRoad3Cover from '../assets/escaperoad3.jpeg';
import duckLife1Cover from '../assets/ducklife1.jpeg';
import duckLife2Cover from '../assets/ducklife2.jpeg';
import monkeyMartCover from '../assets/monkeymart.png';
import timeShooter3Cover from '../assets/timeshooter3.jpeg';
import vex1Cover from '../assets/vex1.jpeg';
import vex2Cover from '../assets/vex2.jpeg';
import vex3Cover from '../assets/vex3.jpeg';
import vex4Cover from '../assets/vex4.jpeg';
import vex5Cover from '../assets/vex5.jpeg';
import learnToFly2Cover from '../assets/learntofly2.jpeg';
import papasSushiriaCover from '../assets/papassushiria.jpeg';
import papasHotDoggeriaCover from '../assets/papas-hotdoggeria.jpeg';
import papasPancakeriaCover from '../assets/papas-pancakeria-logo.jpeg';
import papasWingeriaCover from '../assets/papas-wingeria.jpeg';
import portalCover from '../assets/portal.jpeg';
import portal2Cover from '../assets/portal2.jpeg';
import tetrisCover from '../assets/tetris.jpeg';
import theSims3Cover from '../assets/thesims3.jpeg';
import doodleJumpCover from '../assets/doodlejump.png';
import escapingThePrisonCover from '../assets/escapingtheprison.jpeg';
import stealingTheDiamondCover from '../assets/stealingthediamond.jpeg';
import infiltratingTheAirshipCover from '../assets/infiltratingtheairship.webp';
import themeHotelCover from '../assets/themehotel.jpeg';
import driftHuntersCover from '../assets/drifthunters.jpeg';
import getawayShootoutCover from '../assets/getawayshootout.jpeg';
import johnnyUpgradeCover from '../assets/johnny-upgrade.jpeg';
import tagCover from '../assets/tag.jpeg';
import duckLife7BattleCover from '../assets/duck-life-7-battle.jpeg';
import achievementUnlocked1Cover from '../assets/ach1.jpeg';
import achievementUnlocked2Cover from '../assets/ach2.jpeg';
import achievementUnlocked3Cover from '../assets/ach3.jpeg';
import bobTheRobber4Cover from '../assets/bob-the-robber-4.jpeg';
import { ACHIEVEMENT_UNLOCKED_1_HTML, ACHIEVEMENT_UNLOCKED_2_HTML, ACHIEVEMENT_UNLOCKED_3_HTML } from './achievementUnlockedHtml';
import { BOB_THE_ROBBER_4_HTML } from './bobTheRobber4Html';
import { INFINITE_CRAFT_HTML } from './infiniteCraftHtml';
import { JOHNNY_UPGRADE_HTML } from './johnnyUpgradeHtml';
import { TAG_HTML } from './tagHtml';
import { DUCK_LIFE_7_BATTLE_HTML } from './duckLife7BattleHtml';
import { GTA_VICE_CITY_HTML } from './gtaViceCityHtml';
import { ONE_V_ONE_LOL_HTML } from './oneVOneLolHtml';
import { PAPAS_SUSHIRIA_HTML } from './papasSushiriaHtml';
import { SUBWAY_SURFERS_TOKYO_HTML } from './subwaySurfersTokyoHtml';
import { SUBWAY_SURFERS_NEW_YORK_HTML } from './subwaySurfersNewYorkHtml';
import { COOKIE_CLICKER_HTML } from './cookieClickerHtml';
import {
  PORTAL_HTML,
  PORTAL2_HTML,
  TETRIS_HTML,
  THESIMS3_HTML,
  DOODLEJUMP_HTML,
  ESCAPINGTHEPRISON_HTML,
  STEALINGTHEDIAMOND_HTML,
  INFILTRATINGTHEAIRSHIP_HTML,
  THEMEHOTEL_HTML,
  DRIFTHUNTERS_HTML,
  GETAWAYSHOOTOUT_HTML,
} from './seraphGamesHtml';

/**
 * Initial unblocked games for Frostbite.
 */
export const DEFAULT_GAMES: GameItem[] = [
  {
    id: 'temple-run-2-holiday-havoc',
    name: 'Temple Run 2: Holiday Havoc',
    iframeSrc: 'https://tataedu23.github.io/g8/class-123',
    coverUrl: templeRun2HolidayHavocCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123700000,
  },
  {
    id: 'temple-run-2-frozen-shadows',
    name: 'Temple Run 2: Frozen Shadows',
    iframeSrc: 'https://tataedu23.github.io/g8/class-134',
    coverUrl: templeRun2FrozenShadowsCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123600000,
  },
  {
    id: 'ragdoll-hit',
    name: 'Ragdoll Hit',
    iframeSrc: 'https://tataedu23.github.io/g50/class-12',
    coverUrl: ragdollHitCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123500000,
  },
  {
    id: 'achievement-unlocked',
    name: 'Achievement Unlocked',
    iframeSrc: ACHIEVEMENT_UNLOCKED_1_HTML,
    isHtmlDoc: true,
    coverUrl: achievementUnlocked1Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123400000,
  },
  {
    id: 'achievement-unlocked-2',
    name: 'Achievement Unlocked 2',
    iframeSrc: ACHIEVEMENT_UNLOCKED_2_HTML,
    isHtmlDoc: true,
    coverUrl: achievementUnlocked2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123300000,
  },
  {
    id: 'achievement-unlocked-3',
    name: 'Achievement Unlocked 3',
    iframeSrc: ACHIEVEMENT_UNLOCKED_3_HTML,
    isHtmlDoc: true,
    coverUrl: achievementUnlocked3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123200000,
  },
  {
    id: 'bob-the-robber-4',
    name: 'Bob the Robber 4',
    iframeSrc: BOB_THE_ROBBER_4_HTML,
    isHtmlDoc: true,
    coverUrl: bobTheRobber4Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123100000,
  },
  {
    id: 'johnny-upgrade',
    name: 'Johnny Upgrade',
    iframeSrc: JOHNNY_UPGRADE_HTML,
    isHtmlDoc: true,
    coverUrl: johnnyUpgradeCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726123000000,
  },
  {
    id: 'tag',
    name: 'Tag',
    iframeSrc: TAG_HTML,
    isHtmlDoc: true,
    coverUrl: tagCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726122900000,
  },
  {
    id: 'duck-life-7-battle',
    name: 'Duck Life 7: Battle',
    iframeSrc: DUCK_LIFE_7_BATTLE_HTML,
    isHtmlDoc: true,
    coverUrl: duckLife7BattleCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726122800000,
  },
  {
    id: 'gta-vice-city',
    name: 'GTA Vice City',
    iframeSrc: GTA_VICE_CITY_HTML,
    isHtmlDoc: true,
    coverUrl: gtaViceCityCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726122700000,
  },
  {
    id: 'temple-of-boom',
    name: 'Temple of Boom',
    iframeSrc: 'https://tataedu23.github.io/g69/class-411',
    coverUrl: templeOfBoomCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726122600000,
  },
  {
    id: 'wrassling',
    name: 'Wrassling',
    iframeSrc: 'https://tataedu23.github.io/g69/class-651',
    coverUrl: wrasslingCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726122500000,
  },
  {
    id: 'rowdy-wrestling',
    name: 'Rowdy Wrestling',
    iframeSrc: 'https://tataedu23.github.io/g2/class-666',
    coverUrl: rowdyWrestlingCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726122400000,
  },
  {
    id: 'cookie-clicker',
    name: 'Cookie Clicker',
    iframeSrc: COOKIE_CLICKER_HTML,
    isHtmlDoc: true,
    coverUrl: cookieClickerCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726120000000,
  },
  {
    id: 'rooftop-snipers',
    name: 'Rooftop Snipers',
    iframeSrc: 'https://3kh0.github.io/projects/rooftop-snipers/index.html',
    coverUrl: rooftopSnipersCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726119000000,
  },
  {
    id: 'tube-jumpers',
    name: 'Tube Jumpers',
    iframeSrc: 'https://1kh0.github.io/projects/tube-jumpers/index.html',
    coverUrl: tubeJumpersCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726118000000,
  },
  {
    id: 'soccer-random',
    name: 'Soccer Random',
    iframeSrc: 'https://unblokedgames.github.io/projects/soccer-random/frame.html',
    coverUrl: soccerRandomCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726117000000,
  },
  {
    id: 'volley-random',
    name: 'Volley Random',
    iframeSrc: 'https://unblokedgames.github.io/projects/volley-random/frame.html',
    coverUrl: volleyRandomCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726116000000,
  },
  {
    id: 'tomb-of-the-mask',
    name: 'Tomb of the Mask',
    iframeSrc: 'https://unblokedgames.github.io/projects/totm/index.html',
    coverUrl: tombOfTheMaskCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726115000000,
  },
  {
    id: 'fireboy-and-watergirl-1',
    name: 'Fireboy & Watergirl 1: Forest Temple',
    iframeSrc: 'https://unblokedgames.github.io/projects/fireboy-and-watergirl-1/index.html',
    coverUrl: fireboyWatergirl1Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726114000000,
  },
  {
    id: 'fireboy-and-watergirl-2',
    name: 'Fireboy & Watergirl 2: Light Temple',
    iframeSrc: 'https://unblokedgames.github.io/projects/fireboy-and-watergirl-2/index.html',
    coverUrl: fireboyWatergirl2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726113000000,
  },
  {
    id: 'fireboy-and-watergirl-3',
    name: 'Fireboy & Watergirl 3: Ice Temple',
    iframeSrc: 'https://unblokedgames.github.io/projects/fireboy-and-watergirl-3/index.html',
    coverUrl: fireboyWatergirl3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726112000000,
  },
  {
    id: 'fireboy-and-watergirl-4',
    name: 'Fireboy & Watergirl 4: Crystal Temple',
    iframeSrc: 'https://unblokedgames.github.io/projects/fireboy-and-watergirl-4/index.html',
    coverUrl: fireboyWatergirl4Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726111000000,
  },
  {
    id: 'fireboy-and-watergirl-5',
    name: 'Fireboy & Watergirl 5: Elements',
    iframeSrc: 'https://unblokedgames.github.io/projects/fireboy-and-watergirl-5/index.html',
    coverUrl: fireboyWatergirl5Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726110000000,
  },
  {
    id: 'fireboy-and-watergirl-6',
    name: 'Fireboy & Watergirl 6: Fairy Tales',
    iframeSrc: 'https://unblokedgames.github.io/projects/fireboy-and-watergirl-6/index.html',
    coverUrl: fireboyWatergirl6Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726109000000,
  },
  {
    id: '2048',
    name: '2048',
    iframeSrc: 'https://unblokedgames.github.io/projects/2048/index.html',
    coverUrl: game2048Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726107000000,
  },
  {
    id: 'basket-random',
    name: 'Basket Random',
    iframeSrc: 'https://unblokedgames.github.io/projects/basket-random/frame.html',
    coverUrl: basketRandomCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726106000000,
  },
  {
    id: 'moto-x3m',
    name: 'Moto X3M',
    iframeSrc: 'https://unblokedgames.github.io/projects/moto-x3m/index.html',
    coverUrl: motox3mCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726105000000,
  },
  {
    id: 'moto-x3m-2',
    name: 'Moto X3M 2',
    iframeSrc: 'https://unblokedgames.github.io/projects/moto-x3m-2/index.html',
    coverUrl: motox3m2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726104000000,
  },
  {
    id: 'moto-x3m-3',
    name: 'Moto X3M 3',
    iframeSrc: 'https://motox3m2.io/moto-x3m-3.embed',
    coverUrl: motox3m3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726103000000,
  },
  {
    id: 'moto-x3m-winter',
    name: 'Moto X3M 4: Winter',
    iframeSrc: 'https://unblokedgames.github.io/projects/moto-x3m-winter/index.html',
    coverUrl: motox3mWinterCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726102000000,
  },
  {
    id: 'moto-x3m-pool-party',
    name: 'Moto X3M 5: Pool Party',
    iframeSrc: 'https://unblokedgames.github.io/projects/moto-x3m-pool-party/index.html',
    coverUrl: motox3mPoolPartyCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726101000000,
  },
  {
    id: 'moto-x3m-spooky-land',
    name: 'Moto X3M 6: Spooky Land',
    iframeSrc: 'https://unblokedgames.github.io/projects/moto-x3m-spooky-land/index.html',
    coverUrl: motox3mSpookyLandCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726100000000,
  },
  {
    id: 'subway-surfers-barcelona',
    name: 'Subway Surfers: Barcelona',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/barcelona.html',
    coverUrl: subwaySurfersBarcelonaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726099000000,
  },
  {
    id: 'subway-surfers-beijing',
    name: 'Subway Surfers: Beijing',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/beijing.html',
    coverUrl: subwaySurfersBeijingCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726098000000,
  },
  {
    id: 'subway-surfers-berlin',
    name: 'Subway Surfers: Berlin',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/berlin.html',
    coverUrl: subwaySurfersBerlinCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726097000000,
  },
  {
    id: 'subway-surfers-houston',
    name: 'Subway Surfers: Houston',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/houston.html',
    coverUrl: subwaySurfersHoustonCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726096000000,
  },
  {
    id: 'subway-surfers-iceland',
    name: 'Subway Surfers: Iceland',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/iceland.html',
    coverUrl: subwaySurfersIcelandCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726095000000,
  },
  {
    id: 'subway-surfers-mexico',
    name: 'Subway Surfers: Mexico',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/mexico.html',
    coverUrl: subwaySurfersMexicoCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726094000000,
  },
  {
    id: 'subway-surfers-miami',
    name: 'Subway Surfers: Miami',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/miami.html',
    coverUrl: subwaySurfersMiamiCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726093000000,
  },
  {
    id: 'subway-surfers-winter-holiday',
    name: 'Subway Surfers: Winter Holiday',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/winterholiday.html',
    coverUrl: subwaySurfersWinterHolidayCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726092000000,
  },
  {
    id: 'subway-surfers-buenos',
    name: 'Subway Surfers: Buenos Aires',
    iframeSrc: 'https://html5.gamemonetize.games/60iqc76rla56c0zz5n8c8563j6caguek/',
    coverUrl: subwaySurfersBuenosCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726091000000,
  },
  {
    id: 'subway-surfers-zurich',
    name: 'Subway Surfers: Zurich',
    iframeSrc: 'https://staticquasar931.github.io/SubwaySurfersZurich/',
    coverUrl: subwaySurfersZurichCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726090000000,
  },
  {
    id: 'subway-surfers-new-york',
    name: 'Subway Surfers: New York',
    iframeSrc: SUBWAY_SURFERS_NEW_YORK_HTML,
    isHtmlDoc: true,
    coverUrl: subwaySurfersNewYorkCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089800000,
  },
  {
    id: 'subway-surfers-monaco',
    name: 'Subway Surfers: Monaco',
    iframeSrc: 'https://szhong.4399.com/4399swf//upload_swf/ftp36/liuxinyu/20210611/jj11/index.html',
    coverUrl: subwaySurfersMonacoCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089600000,
  },
  {
    id: 'subway-surfers-hollywood',
    name: 'Subway Surfers: Hollywood (2026)',
    iframeSrc: 'https://g.igroutka.ru/games/164/WhLjoPkSbAKgrn8R/13/subway_surfers_hollywood_2026/',
    coverUrl: subwaySurfersHollywoodCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089400000,
  },
  {
    id: 'subway-surfers-tokyo',
    name: 'Subway Surfers: Tokyo',
    iframeSrc: 'https://unblokedgames.github.io/projects/subway-surfers-unity/tokyo.html',
    coverUrl: subwaySurfersTokyoCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089300000,
  },
  {
    id: 'temple-run-2',
    name: 'Temple Run 2',
    iframeSrc: 'https://77pen.github.io/p8/temple-run-2/',
    coverUrl: templeRun2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089200000,
  },
  {
    id: 'temple-run-2-jungle-fall',
    name: 'Temple Run 2: Jungle Fall',
    iframeSrc: 'https://g.igroutka.ru/games/164/15Lwc9ZQAKP68TIO/temple_run_2_jungle_fall/',
    coverUrl: templeRun2JungleFallCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089100000,
  },
  {
    id: 'temple-run-2-spooky-summit',
    name: 'Temple Run 2: Spooky Summit',
    iframeSrc: 'https://f.igry.pro/games/164/VJYtd6ApThscCS5u/2/temple_run_2_spooky_summit/',
    coverUrl: templeRun2SpookySummitCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089050000,
  },
  {
    id: 'temple-run-2-holi-festival',
    name: 'Temple Run 2: Holi Festival',
    iframeSrc: 'https://sda.4399.com/4399swf//upload_swf/ftp36/liuxinyu/20210628/jjjj1/index.html',
    coverUrl: templeRun2HoliFestivalCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089020000,
  },
  {
    id: 'bitlife',
    name: 'BitLife',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/bitlife/index.html',
    coverUrl: bitlifeCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726089000000,
  },
  {
    id: 'subway-surfers',
    name: 'Subway Surfers San Francisco',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/subwaysurfers/index.html',
    coverUrl: subwaySurfersCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726088000000,
  },
  {
    id: 'retro-bowl',
    name: 'Retro Bowl',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/retrobowl/index.html',
    coverUrl: retroBowlCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726087000000,
  },
  {
    id: 'fruit-ninja',
    name: 'Fruit Ninja',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/fruitninja/index.html',
    coverUrl: fruitNinjaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726086000000,
  },
  {
    id: 'sm64',
    name: 'Super Mario 64',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/sm64/index.html',
    coverUrl: sm64Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726085000000,
  },
  {
    id: 'slope',
    name: 'Slope',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/slope/index.html',
    coverUrl: slopeCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726084000000,
  },
  {
    id: '1v1-lol',
    name: '1v1.lol',
    iframeSrc: ONE_V_ONE_LOL_HTML,
    isHtmlDoc: true,
    coverUrl: oneVOneCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726083000000,
  },
  {
    id: 'boxing-random',
    name: 'Boxing Random',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/boxingrandom/index.html',
    coverUrl: boxingRandomCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726082000000,
  },
  {
    id: 'boxing-physics-2',
    name: 'Boxing Physics 2',
    iframeSrc: 'https://23azostore.github.io/s2/boxing-physics-2/',
    coverUrl: boxingCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726081000000,
  },
  {
    id: 'madalin-stunt-cars-2',
    name: 'Madalin Stunt Cars 2',
    iframeSrc: 'https://genizymath.github.io/iframe/278.html',
    coverUrl: madalinCover,
    sandboxMode: 'standard',
    createdAt: 1726080000000,
  },
  {
    id: 'super-smash-bros',
    name: 'Super Smash Bros',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/supersmashbros/index.html',
    coverUrl: superSmashBrosCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726135000000,
  },
  {
    id: 'super-mario-bros',
    name: 'Super Mario Bros',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/supermariobros/index.html',
    coverUrl: superMarioBrosCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726134000000,
  },
  {
    id: 'super-mario-bros-2',
    name: 'Super Mario Bros 2',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/supermariobros2/index.html',
    coverUrl: superMarioBros2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726133000000,
  },
  {
    id: 'super-mario-bros-3',
    name: 'Super Mario Bros 3',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/supermariobros3/index.html',
    coverUrl: superMarioBros3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726132000000,
  },
  {
    id: 'street-fighter-2-turbo',
    name: 'Street Fighter 2 Turbo',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/streetfighter2/index.html',
    coverUrl: streetFighter2TurboCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726131000000,
  },
  {
    id: 'streets-of-rage',
    name: 'Streets of Rage',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/streetsofrage/index.html',
    coverUrl: streetsOfRageCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726130000000,
  },
  {
    id: 'mortal-kombat-4',
    name: 'Mortal Kombat 4',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/mortalkombat4/index.html',
    coverUrl: mortalKombat4Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726129000000,
  },
  {
    id: 'minecraft',
    name: 'Minecraft',
    iframeSrc: 'https://eaglercraftnoa.github.io/version/Eaglercraft%201.21.11%20WASM.html',
    coverUrl: minecraftCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726140000000,
  },
  {
    id: 'run-3',
    name: 'Run 3',
    iframeSrc: 'https://jamestore214.github.io/g11/run-3//',
    coverUrl: run3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726139000000,
  },
  {
    id: 'melon-playground',
    name: 'Melon Playground',
    iframeSrc: 'https://play.1gdata.com/6c9cn2uj/index.html',
    coverUrl: melonPlaygroundCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726138500000,
  },
  {
    id: 'happy-wheels',
    name: 'Happy Wheels',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/happywheels/index.html',
    coverUrl: happyWheelsCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726138400000,
  },
  {
    id: 'crossy-road',
    name: 'Crossy Road',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/crossy/index.html',
    coverUrl: crossyRoadCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726138000000,
  },
  {
    id: 'jetpack-joyride',
    name: 'Jetpack Joyride',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/jetpackjoyride/index.html',
    coverUrl: jetpackJoyrideCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726137000000,
  },
  {
    id: 'big-shot-boxing',
    name: 'Big Shot Boxing',
    iframeSrc: 'https://tataedu23.github.io/g16/class-529',
    coverUrl: bigShotBoxingCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726136000000,
  },
  {
    id: 'vex-7',
    name: 'Vex 7',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/vex7/index.html',
    coverUrl: vex7Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726145000000,
  },
  {
    id: 'burrito-bison',
    name: 'Burrito Bison: Launcha Libre',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/burritobison/index.html',
    coverUrl: burritoBisonCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726144000000,
  },
  {
    id: 'gun-mayhem-2',
    name: 'Gun Mayhem 2',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/gunmayhem2/index.html',
    coverUrl: gunMayhem2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726143000000,
  },
  {
    id: 'papas-freezeria',
    name: "Papa's Freezeria",
    iframeSrc: 'https://ijnfem.github.io/seraph/games/papasfreezeria/index.html',
    coverUrl: papasFreezeriaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726142000000,
  },
  {
    id: 'papas-pizzeria',
    name: "Papa's Pizzeria",
    iframeSrc: 'https://ijnfem.github.io/seraph/games/papaspizzaria/index.html',
    coverUrl: papasPizzeriaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726141000000,
  },
  {
    id: 'papas-burgeria',
    name: "Papa's Burgeria",
    iframeSrc: 'https://ijnfem.github.io/seraph/games/papasburgeria/index.html',
    coverUrl: papasBurgeriaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726140500000,
  },
  {
    id: 'papas-hot-doggeria',
    name: "Papa's Hot Doggeria",
    iframeSrc: 'https://ijnfem.github.io/seraph/games/papashotdoggeria/index.html',
    coverUrl: papasHotDoggeriaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726140400000,
  },
  {
    id: 'papas-pancakeria',
    name: "Papa's Pancakeria",
    iframeSrc: 'https://ijnfem.github.io/seraph/games/papaspancakeria/index.html',
    coverUrl: papasPancakeriaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726140300000,
  },
  {
    id: 'papas-wingeria',
    name: "Papa's Wingeria",
    iframeSrc: 'https://ijnfem.github.io/seraph/games/papaswingeria/index.html',
    coverUrl: papasWingeriaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726140200000,
  },
  {
    id: 'basketball-stars',
    name: 'Basketball Stars',
    iframeSrc: 'https://hfmanor.com/basketball-stars',
    coverUrl: basketballStarsCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150000000,
  },
  {
    id: 'smash-karts',
    name: 'Smash Karts',
    iframeSrc: 'https://hfmanor.com/Smash%20Karts',
    coverUrl: smashKartsCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150100000,
  },
  {
    id: 'snow-rider-3d',
    name: 'Snow Rider 3D',
    iframeSrc: 'https://hfmanor.com/Snow-Rider-3D',
    coverUrl: snowRider3dCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150200000,
  },
  {
    id: 'vex-6',
    name: 'Vex 6',
    iframeSrc: 'https://hfmanor.com/vex6',
    coverUrl: vex6Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150300000,
  },
  {
    id: 'solitaire',
    name: 'Solitaire',
    iframeSrc: 'https://hfmanor.com/solitaire',
    coverUrl: solitaireCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150400000,
  },
  {
    id: 'basketbros-io',
    name: 'Basket Bros',
    iframeSrc: 'https://hfmanor.com/basketbros-io',
    coverUrl: basketBrosCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150500000,
  },
  {
    id: 'stickman-hook',
    name: 'Stickman Hook',
    iframeSrc: 'https://hfmanor.com/stickman-hook',
    coverUrl: stickmanHookCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150600000,
  },
  {
    id: 'ovo',
    name: 'OvO',
    iframeSrc: 'https://hfmanor.com/ovo',
    coverUrl: ovoCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150700000,
  },
  {
    id: 'bloons-tower-defense-5',
    name: 'Bloons Tower Defense 5',
    iframeSrc: 'https://hfmanor.com/Bloons%20Tower%20Defense%205',
    coverUrl: bloonsTd5Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150800000,
  },
  {
    id: 'madalin-stunt-cars-3',
    name: 'Madalin Stunt Cars 3',
    iframeSrc: 'https://hfmanor.com/madalin-stunt-cars-3',
    coverUrl: madalinStuntCars3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726150900000,
  },
  {
    id: 'tiny-fishing',
    name: 'Tiny Fishing',
    iframeSrc: 'https://hfmanor.com/tiny-fishing',
    coverUrl: tinyFishingCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151000000,
  },
  {
    id: 'slitherio',
    name: 'Slither.io',
    iframeSrc: 'https://hfmanor.com/slitherio',
    coverUrl: slitherioCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151100000,
  },
  {
    id: 'krunker',
    name: 'Krunker.io',
    iframeSrc: 'https://hfmanor.com/krunker',
    coverUrl: krunkerCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151200000,
  },
  {
    id: 'paper-io-2',
    name: 'Paper.io 2',
    iframeSrc: 'https://hfmanor.com/Paper.io%202',
    coverUrl: paperIo2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151300000,
  },
  {
    id: 'infinite-craft',
    name: 'Infinite Craft',
    iframeSrc: INFINITE_CRAFT_HTML,
    isHtmlDoc: true,
    coverUrl: infiniteCraftCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151400000,
  },
  {
    id: 'time-shooter-2',
    name: 'Time Shooter 2',
    iframeSrc: 'https://hfmanor.com/time-shooter-2',
    coverUrl: timeShooter2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726151500000,
  },
  {
    id: 'time-shooter-3',
    name: 'Time Shooter 3',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/timeshooter3/index.html',
    coverUrl: timeShooter3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155000000,
  },
  {
    id: 'escape-road-3',
    name: 'Escape Road 3',
    iframeSrc: 'https://gamea.azgame.io/escape-road-3/',
    coverUrl: escapeRoad3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155100000,
  },
  {
    id: 'duck-life-1',
    name: 'Duck Life',
    iframeSrc: 'https://kdata1.com/2019/09/ducklife1/webgl/',
    coverUrl: duckLife1Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155200000,
  },
  {
    id: 'duck-life-2',
    name: 'Duck Life 2',
    iframeSrc: 'https://kdata1.com/2019/09/ducklife2/webgl/',
    coverUrl: duckLife2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155300000,
  },
  {
    id: 'monkey-mart',
    name: 'Monkey Mart',
    iframeSrc: 'https://hfmanor.com/Monkey%20Mart',
    coverUrl: monkeyMartCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155400000,
  },
  {
    id: 'learn-to-fly-2',
    name: 'Learn To Fly 2',
    iframeSrc: 'https://hfmanor.com/learntofly2',
    coverUrl: learnToFly2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155500000,
  },
  {
    id: 'vex-5',
    name: 'Vex 5',
    iframeSrc: 'https://hfmanor.com/vex5',
    coverUrl: vex5Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155600000,
  },
  {
    id: 'vex-4',
    name: 'Vex 4',
    iframeSrc: 'https://hfmanor.com/vex4',
    coverUrl: vex4Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155700000,
  },
  {
    id: 'vex-3',
    name: 'Vex 3',
    iframeSrc: 'https://hfmanor.com/vex3',
    coverUrl: vex3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155800000,
  },
  {
    id: 'vex-2',
    name: 'Vex 2',
    iframeSrc: 'https://hfmanor.com/vex2',
    coverUrl: vex2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726155900000,
  },
  {
    id: 'vex',
    name: 'Vex',
    iframeSrc: 'https://ijnfem.github.io/seraph/games/vex/index.html',
    coverUrl: vex1Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156000000,
  },
  {
    id: 'papas-sushiria',
    name: "Papa's Sushiria",
    iframeSrc: PAPAS_SUSHIRIA_HTML,
    isHtmlDoc: true,
    coverUrl: papasSushiriaCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156100000,
  },
  {
    id: 'portal',
    name: 'Portal',
    iframeSrc: PORTAL_HTML,
    isHtmlDoc: true,
    coverUrl: portalCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156200000,
  },
  {
    id: 'portal-2',
    name: 'Portal 2',
    iframeSrc: PORTAL2_HTML,
    isHtmlDoc: true,
    coverUrl: portal2Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156300000,
  },
  {
    id: 'tetris',
    name: 'Tetris',
    iframeSrc: TETRIS_HTML,
    isHtmlDoc: true,
    coverUrl: tetrisCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156400000,
  },
  {
    id: 'the-sims-3',
    name: 'The Sims 3',
    iframeSrc: THESIMS3_HTML,
    isHtmlDoc: true,
    coverUrl: theSims3Cover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156500000,
  },
  {
    id: 'doodle-jump',
    name: 'Doodle Jump',
    iframeSrc: DOODLEJUMP_HTML,
    isHtmlDoc: true,
    coverUrl: doodleJumpCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156600000,
  },
  {
    id: 'escaping-the-prison',
    name: 'Escaping the Prison',
    iframeSrc: ESCAPINGTHEPRISON_HTML,
    isHtmlDoc: true,
    coverUrl: escapingThePrisonCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156700000,
  },
  {
    id: 'stealing-the-diamond',
    name: 'Stealing the Diamond',
    iframeSrc: STEALINGTHEDIAMOND_HTML,
    isHtmlDoc: true,
    coverUrl: stealingTheDiamondCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156800000,
  },
  {
    id: 'infiltrating-the-airship',
    name: 'Infiltrating the Airship',
    iframeSrc: INFILTRATINGTHEAIRSHIP_HTML,
    isHtmlDoc: true,
    coverUrl: infiltratingTheAirshipCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726156900000,
  },
  {
    id: 'theme-hotel',
    name: 'Theme Hotel',
    iframeSrc: THEMEHOTEL_HTML,
    isHtmlDoc: true,
    coverUrl: themeHotelCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726157000000,
  },
  {
    id: 'drift-hunters',
    name: 'Drift Hunters',
    iframeSrc: DRIFTHUNTERS_HTML,
    isHtmlDoc: true,
    coverUrl: driftHuntersCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726157100000,
  },
  {
    id: 'getaway-shootout',
    name: 'Getaway Shootout',
    iframeSrc: GETAWAYSHOOTOUT_HTML,
    isHtmlDoc: true,
    coverUrl: getawayShootoutCover,
    sandboxMode: 'unrestricted',
    createdAt: 1726157200000,
  },
];
